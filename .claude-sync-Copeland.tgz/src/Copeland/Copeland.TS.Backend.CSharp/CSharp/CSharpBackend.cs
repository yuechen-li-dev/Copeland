using Copeland.TS.Mir;
using System.Security.Cryptography;
using System.Text;

namespace Copeland.TS.Backend.CSharp;

public static partial class CSharpBackend
{
    public static string GeneratedRecordTypeName(MirRecordTypeId id) => RecordTypeName(id);

    public static string GeneratedRecordFieldName(MirRecordFieldId id) => RecordFieldName(id);

    public static string GeneratedFunctionName(string name) => CSharpNameMangler.Mangle(name);

    private enum AsyncStateKind
    {
        Statement,
        Return,
        Branch,
        Jump,
        Await,
        Evaluate,
        Propagate,
    }

    private sealed class HandlerTransfer(string errorTemporary, string label)
    {
        public string ErrorTemporary { get; } = errorTemporary;
        public string Label { get; } = label;
    }

    private sealed class AsyncState(
        int id,
        AsyncStateKind kind,
        MirStatement? statement,
        int nextState,
        int thenState = -1,
        int elseState = -1,
        MirFrameSlotId? awaitedComputationSlot = null,
        MirExpression? condition = null,
        MirFrameSlotId? valueSlot = null,
        MirExpression? expression = null,
        MirPropagationTarget? propagationTarget = null,
        int handlerState = -1,
        MirFrameSlotId? handlerErrorSlot = null)
    {
        public int Id { get; } = id;
        public AsyncStateKind Kind { get; } = kind;
        public MirStatement? Statement { get; } = statement;
        public int NextState { get; } = nextState;
        public int ThenState { get; } = thenState;
        public int ElseState { get; } = elseState;
        public MirFrameSlotId? AwaitedComputationSlot { get; } = awaitedComputationSlot;
        public MirExpression? Condition { get; } = condition;
        public MirFrameSlotId? ValueSlot { get; } = valueSlot;
        public MirExpression? Expression { get; } = expression;
        public MirPropagationTarget? PropagationTarget { get; } = propagationTarget;
        public int HandlerState { get; } = handlerState;
        public MirFrameSlotId? HandlerErrorSlot { get; } = handlerErrorSlot;
    }

    private sealed class CSharpEmissionState(IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        public Dictionary<MirHandlerId, HandlerTransfer> Handlers { get; } = [];
        public Stack<MirExpression?> ContinueIncrements { get; } = new();
        public IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> Records { get; } = records;
        public int TryIndex { get; set; }
    }

    private static readonly AsyncLocal<CSharpEmissionState?> CurrentEmissionState = new();
    private static readonly AsyncLocal<string?> CurrentSourcePath = new();
    private static readonly AsyncLocal<CSharpEmissionOptions?> CurrentOptions = new();
    private static readonly AsyncLocal<bool> UsesNativeStrings = new();
    private static readonly AsyncLocal<bool> UsesIntegerRuntime = new();

    /// <summary>The module class name used when no host-specific name is requested.</summary>
    public const string DefaultModuleClassName = "CopelandModule";

    public static CSharpCompilation Emit(MirProgram program)
        => Emit(program, new CSharpEmissionOptions());

    /// <summary>
    /// Emits the module class under <paramref name="moduleClassName"/>. Every
    /// generated reference to module members (captured-callable environments,
    /// flows) uses the same name, so hosts must not rename the class textually
    /// after emission.
    /// </summary>
    public static CSharpCompilation Emit(MirProgram program, string moduleClassName)
    {
        return Emit(program, new CSharpEmissionOptions { ModuleClassName = moduleClassName });
    }

    public static CSharpCompilation Emit(MirProgram program, CSharpEmissionOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);
        if (!IsValidModuleClassName(options.ModuleClassName))
        {
            throw new ArgumentException("Invalid generated module class name.", nameof(options));
        }
        if (string.IsNullOrEmpty(options.Namespace) || !options.Namespace.Split('.').All(IsValidModuleClassName))
        {
            throw new ArgumentException("Invalid generated namespace.", nameof(options));
        }
        if (options.RecordCarrierScope is not null && !IsValidModuleClassName(options.RecordCarrierScope))
        {
            throw new ArgumentException("Invalid record carrier scope.", nameof(options));
        }
        return EmitCore(program, null, options);
    }

    private static bool IsValidModuleClassName(string name)
    {
        if (string.IsNullOrEmpty(name))
        {
            return false;
        }

        if (!(char.IsLetter(name[0]) || name[0] == '_'))
        {
            return false;
        }

        foreach (char character in name)
        {
            if (!(char.IsLetterOrDigit(character) || character == '_'))
            {
                return false;
            }
        }

        return Microsoft.CodeAnalysis.CSharp.SyntaxFacts.GetKeywordKind(name) == Microsoft.CodeAnalysis.CSharp.SyntaxKind.None;
    }

    private static CSharpEmissionOptions EmissionOptions => CurrentOptions.Value ?? new CSharpEmissionOptions();
    private static string ModuleClassName => EmissionOptions.ModuleClassName;
    private static string FunctionAccessibility(MirFunction function)
        => EmissionOptions.PublicFunctionNames is null || EmissionOptions.PublicFunctionNames.Contains(function.Name) ? "public" : "internal";

    /// <summary>
    /// Emits a root application and binds targetless tsonCall to the one
    /// manifest-declared default sidecar. This is the production emission seam.
    /// </summary>
    public static CSharpCompilation EmitForRootManifest(MirProgram program, Copeland.TS.Manifest.CopelandManifest manifest)
    {
        CSharpSidecarContract? contract = null;
        if (ProgramUsesTsonTransport(program)
            && !CSharpSidecarContracts.TryCreate(program, manifest, out contract, out CSharpDiagnostic? diagnostic))
        {
            return new CSharpCompilation(string.Empty, [diagnostic!]);
        }

        return EmitCore(program, ProgramUsesTsonTransport(program) ? contract : null, new CSharpEmissionOptions());
    }

    private static CSharpCompilation EmitCore(MirProgram program, CSharpSidecarContract? sidecarContract, CSharpEmissionOptions options)
    {
        if (program.Functions.Any(function => function.ComponentState is not null))
        {
            return new CSharpCompilation(string.Empty,
                [new CSharpDiagnostic("COPE-CS-COMPONENT-ON-0001", "Instance-bound React endpoints require the JavaScript React adapter.")]);
        }
        var diagnostics = MirValidator.Validate(program)
            .Select(diagnostic => new CSharpDiagnostic("COPE-CS-0002", $"Invalid MIR: {diagnostic.Message}"))
            .ToList();
        if (diagnostics.Count > 0)
        {
            return new CSharpCompilation(string.Empty, diagnostics);
        }
        foreach (MirNpmImport import in program.NpmImports.Where(import => !import.IsAvailableToClrSidecar))
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-0001", $"npm import '{import.LocalBinding}' is unavailable for the CLR sidecar backend."));
        }
        if (program.JavaScriptHostImports.Count > 0)
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-BROWSER-0001", "JavaScript host contracts are available only to the Browser JavaScript runtime target."));
        }
        if (diagnostics.Count > 0)
        {
            return new CSharpCompilation(string.Empty, diagnostics);
        }
        var writer = new CSharpTextWriter();
        string? previousSourcePath = CurrentSourcePath.Value;
        CurrentSourcePath.Value = program.CSharpSourcePath;
        CSharpEmissionOptions? previousOptions = CurrentOptions.Value;
        CurrentOptions.Value = options;
        bool previousNativeStrings = UsesNativeStrings.Value;
        UsesNativeStrings.Value = false;
        bool previousIntegerRuntime = UsesIntegerRuntime.Value;
        UsesIntegerRuntime.Value = false;
        try
        {
            var enumNames = program.Enums.Select(@enum => @enum.Name).ToHashSet(StringComparer.Ordinal);
            var recordsById = program.Records.ToDictionary(record => record.Id);
            var tablesById = program.Tables.ToDictionary(table => table.Id);
            var tsonTableIds = program.TsonEncodingPlans
                .Where(plan => plan.TablePlan is not null)
                .Select(plan => plan.TablePlan!.TableId)
                .ToHashSet();
            var usesResult = ProgramUsesResult(program) || program.Tables.Count > 0;
            var usesUnwrap = ProgramUsesUnwrap(program);
            var needsUnit = EnumerateTypes(program).Any(ContainsVoidResult);
            var errorTypes = CollectErrorNominalTypes(program, enumNames);
            var usesAsync = program.Functions.Any(function => function.IsAsync);
            var usesGenerators = program.Functions.Any(function => function.IsGenerator);
            var usesTsonTransport = ProgramUsesTsonTransport(program);
            var usesSystemTextJson = ProgramUsesSystemTextJson(program);
            var usesBatch = ProgramUsesBatch(program);
            var usesArrayElementAccess = ProgramUsesArrayElementAccess(program);
            var usesTableWith = program.Functions.Any(function => function.Body.Any(StatementUsesTableWith));
            var usesTextDocuments = EnumerateTypes(program).Any(type => type.Identifier == "Document");

            writer.WriteLine("// <auto-generated />"); writer.WriteLine("#nullable enable"); writer.WriteLine();
            foreach (string @namespace in program.CSharpUsings)
            {
                writer.WriteLine($"using {@namespace};");
            }
            if (program.CSharpUsings.Count > 0)
            {
                writer.WriteLine();
            }
            writer.WriteLine($"namespace {EmissionOptions.Namespace};"); writer.WriteLine();
            if (usesTextDocuments) EmitTextDocumentRuntime(writer);
            if (needsUnit) EmitUnit(writer);
            if (usesArrayElementAccess) EmitArraySupport(writer);
            if (usesResult) EmitResult(writer);
            if (usesAsync) EmitAsyncRuntime(writer);
            if (usesGenerators) EmitGeneratorRuntime(writer);
            if (usesTsonTransport) EmitTsonTransportRuntime(writer, sidecarContract);
            foreach (var errorType in errorTypes) writer.WriteLine($"public readonly record struct {CSharpNameMangler.Mangle(errorType)};");
            if (errorTypes.Count > 0) writer.WriteLine();
            foreach (var record in program.Records) EmitRecord(writer, record, usesSystemTextJson);
            if (program.Records.Count > 0) writer.WriteLine();
            foreach (var mirEnum in program.Enums) EmitEnum(writer, mirEnum);
            if (program.Enums.Count > 0) writer.WriteLine();
            foreach (MirFlowDefinition flow in program.Flows)
            {
                EmitFlow(writer, flow, enumNames, diagnostics);
                writer.WriteLine();
            }
            EmitCallableDelegates(writer, program);
            EmitCapturedCallableEnvironments(writer, program);
            if (program.Tables.Count > 0)
            {
                EmitColumnSupport(writer);
                foreach (var table in program.Tables)
                {
                    EmitTable(writer, table, recordsById, tablesById, tsonTableIds.Contains(table.Id), usesTableWith, enumNames);
                }
            }
            writer.WriteLine($"public static class {ModuleClassName}"); writer.WriteLine("{"); writer.Indent();
            foreach (var table in program.Tables)
            {
                string createExpression = table.DerivedPlan is null
                    ? $"{TableTypeName(table.Id)}.Create()"
                    : $"{TableTypeName(table.Id)}.Create({string.Join(", ", new[] { TableSingletonName(table.DerivedPlan.SourceTableId) }.Concat(table.DerivedPlan.Joins.Select(join => TableSingletonName(join.JoinedTableId))))})";
                writer.WriteLine($"private static readonly {TableTypeName(table.Id)} {TableSingletonName(table.Id)} = {createExpression};");
                if (program.ExecutableArtifacts.OfType<MirTableQueryArtifact>().Any(query => query.SourceRelationId == table.Id))
                {
                    writer.WriteLine($"internal static {TableTypeName(table.Id)} __CopelandQueryTable_{EncodeStableIdentity(table.Id.Value)} => {TableSingletonName(table.Id)};");
                }
                if (table.IsExported)
                {
                    writer.WriteLine($"public static {TableTypeName(table.Id)} {CSharpNameMangler.Mangle(table.Name)} => {TableSingletonName(table.Id)};");
                }
            }
            if (program.Tables.Count > 0)
            {
                writer.WriteLine();
            }
            if (usesUnwrap)
            {
                EmitUnwrapPanic(writer);
            }
            if (usesBatch)
            {
                EmitBatchTestSeam(writer);
            }
            if (program.TsonEncodingPlans.Count > 0)
            {
                EmitTsonEncodingRuntime(writer, program.TsonEncodingPlans, recordsById, usesTsonTransport);
            }
            foreach (var function in program.Functions)
            {
                if (function.IsAsync)
                {
                    EmitAsyncFrame(writer, function);
                }
            }
            foreach (var function in program.Functions) EmitFunction(writer, function, enumNames, recordsById, diagnostics);
            foreach (MirModuleValue value in program.ModuleValues)
            {
                writer.WriteLine($"private static readonly {MapType(value.Type)} {CSharpNameMangler.Mangle(value.Name)} = {CSharpNameMangler.Mangle(value.InitializerFunction)}();");
            }
            if (UsesNativeStrings.Value) NativeStringRuntime.Emit(writer);
            if (UsesIntegerRuntime.Value) IntegerRuntime.Emit(writer);
            writer.Unindent(); writer.WriteLine("}");
            return diagnostics.Count == 0
                ? new CSharpCompilation(writer.ToString(), diagnostics, sidecarContract)
                : new CSharpCompilation(string.Empty, diagnostics);
        }
        finally
        {
            CurrentSourcePath.Value = previousSourcePath;
            CurrentOptions.Value = previousOptions;
            UsesNativeStrings.Value = previousNativeStrings;
            UsesIntegerRuntime.Value = previousIntegerRuntime;
        }
    }

    private static void EmitFlow(CSharpTextWriter writer, MirFlowDefinition flow, IReadOnlySet<string> enumNames, List<CSharpDiagnostic> diagnostics)
    {
        if (flow.Execution is { } execution)
        {
            string frameType = MapValueStorageType(execution.FrameType);
            string parameters = string.Join(", ", execution.Parameters.Select(parameter => MapValueStorageType(parameter.Type) + " " + CSharpNameMangler.Mangle(parameter.Name)));
            string arguments = string.Join(", ", execution.Parameters.Select(parameter => CSharpNameMangler.Mangle(parameter.Name)));
            writer.WriteLine($"public static class {CSharpNameMangler.Mangle(flow.Name)}");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"public static {frameType} Start({parameters}) => {ModuleClassName}.{CSharpNameMangler.Mangle(execution.StartFunction)}({arguments});");
            writer.WriteLine($"public static {frameType} Step({frameType} frame) => {ModuleClassName}.{CSharpNameMangler.Mangle(execution.StepFunction)}(frame);");
            writer.Unindent();
            writer.WriteLine("}");
            return;
        }
        string flowName = CSharpNameMangler.Mangle(flow.Name);
        string boardType = RecordTypeName(flow.BoardType.RecordTypeId);
        string resultType = flowName + "TransitionResult";
        var expressionContext = new MirFunction("<flow>", [], new MirNamedType("void"), [], []);
        writer.WriteLine($"public readonly record struct {resultType}(string Kind, string FromState, string? ToState, string Event, long Revision, bool IsTerminal, object? Value, object? Error);");
        writer.WriteLine($"public static class {flowName}");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"public static Session Start() => new Session();");
        writer.WriteLine("public sealed class Session");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"private {boardType} board;");
        writer.WriteLine($"private string state = {CSharpLiteralWriter.Write(flow.InitialState)};");
        writer.WriteLine("private bool terminal;");
        writer.WriteLine("private bool sending;");
        writer.WriteLine("private long revision;");
        int initializerTempIndex = 0;
        string initializers = string.Join(", ", flow.BoardFields.Select(field => EmitExpression(writer, field.Initializer, expressionContext, enumNames, ref initializerTempIndex, diagnostics)));
        writer.WriteLine($"internal Session() {{ board = new {boardType}({initializers}); }}");
        writer.WriteLine($"public {boardType} Board => board;");
        writer.WriteLine("public string State => state;");
        writer.WriteLine("public bool IsTerminal => terminal;");
        writer.WriteLine("public long Revision => revision;");
        foreach (MirFlowEvent @event in flow.Events)
        {
            EmitFlowSend(writer, flow, @event, resultType, expressionContext, enumNames, diagnostics);
        }
        foreach (MirFlowState state in flow.States.Where(state => state.Terminal is not null))
        {
            EmitFlowTerminal(writer, flow, state, resultType, expressionContext, enumNames, diagnostics);
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitFlowSend(CSharpTextWriter writer, MirFlowDefinition flow, MirFlowEvent @event, string resultType, MirFunction expressionContext, IReadOnlySet<string> enumNames, List<CSharpDiagnostic> diagnostics)
    {
        string parameters = string.Join(", ", @event.Payloads.Select(parameter => MapValueStorageType(parameter.Type) + " " + CSharpNameMangler.Mangle(parameter.Name)));
        writer.WriteLine($"public {resultType} Send{CSharpNameMangler.Mangle(@event.Name)}({parameters})");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (sending) throw new global::System.InvalidOperationException(\"A Copeland flow session cannot receive a reentrant event.\");");
        writer.WriteLine("if (terminal) return new(" + CSharpLiteralWriter.Write("Terminal") + ", state, null, " + CSharpLiteralWriter.Write(@event.Name) + ", revision, true, null, null);");
        writer.WriteLine("sending = true;");
        writer.WriteLine("try");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("switch (state)");
        writer.WriteLine("{");
        writer.Indent();
        foreach (MirFlowState state in flow.States)
        {
            MirFlowTransition? transition = state.Transitions.SingleOrDefault(candidate => candidate.EventName == @event.Name);
            if (transition is null) continue;
            writer.WriteLine($"case {CSharpLiteralWriter.Write(state.Name)}:");
            writer.Indent();
            int tempIndex = 0;
            if (transition.Guard is not null)
            {
                string guard = EmitExpression(writer, transition.Guard, expressionContext, enumNames, ref tempIndex, diagnostics);
                writer.WriteLine($"if (!({guard})) return new({CSharpLiteralWriter.Write("Unhandled")}, state, null, {CSharpLiteralWriter.Write(@event.Name)}, revision, false, null, null);");
            }
            writer.WriteLine($"{RecordTypeName(flow.BoardType.RecordTypeId)} nextBoard = this.board;");
            writer.WriteLine($"{RecordTypeName(flow.BoardType.RecordTypeId)} board = nextBoard;");
            foreach (MirFlowBoardUpdate update in transition.Updates)
            {
                string value = EmitExpression(writer, update.Value, expressionContext, enumNames, ref tempIndex, diagnostics);
                string constructorArguments = string.Join(", ", flow.BoardFields.Select(field =>
                    field.Id == update.FieldId
                        ? value
                        : "nextBoard." + RecordFieldName(field.Id)));
                writer.WriteLine($"nextBoard = new {RecordTypeName(flow.BoardType.RecordTypeId)}({constructorArguments});");
                writer.WriteLine("board = nextBoard;");
            }
            writer.WriteLine("string fromState = state;");
            writer.WriteLine("this.board = nextBoard;");
            writer.WriteLine($"state = {CSharpLiteralWriter.Write(transition.TargetState)};");
            writer.WriteLine("revision++;");
            MirFlowState target = flow.States.Single(state => state.Name == transition.TargetState);
            if (target.Terminal is not null)
            {
                writer.WriteLine($"return Enter{CSharpNameMangler.Mangle(target.Name)}(fromState, {CSharpLiteralWriter.Write(@event.Name)});");
            }
            else
            {
                writer.WriteLine($"return new({CSharpLiteralWriter.Write("Transitioned")}, fromState, state, {CSharpLiteralWriter.Write(@event.Name)}, revision, false, null, null);");
            }
            writer.Unindent();
        }
        writer.WriteLine("default:");
        writer.Indent();
        writer.WriteLine($"return new({CSharpLiteralWriter.Write("Unhandled")}, state, null, {CSharpLiteralWriter.Write(@event.Name)}, revision, false, null, null);");
        writer.Unindent();
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("finally");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("sending = false;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitFlowTerminal(CSharpTextWriter writer, MirFlowDefinition flow, MirFlowState state, string resultType, MirFunction expressionContext, IReadOnlySet<string> enumNames, List<CSharpDiagnostic> diagnostics)
    {
        MirFlowTerminal terminal = state.Terminal!;
        int tempIndex = 0;
        string? error = terminal.IsFailure && terminal.Expression is not null
            ? EmitExpression(writer, terminal.Expression, expressionContext, enumNames, ref tempIndex, diagnostics)
            : terminal.IsFailure ? CSharpLiteralWriter.Write("Flow failed.") : "null";
        string? value = !terminal.IsFailure && terminal.Expression is not null
            ? EmitExpression(writer, terminal.Expression, expressionContext, enumNames, ref tempIndex, diagnostics)
            : "null";
        writer.WriteLine($"private {resultType} Enter{CSharpNameMangler.Mangle(state.Name)}(string fromState, string eventName)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"{RecordTypeName(flow.BoardType.RecordTypeId)} board = this.board;");
        writer.WriteLine("terminal = true;");
        string kind = terminal.IsFailure ? "Failed" : "Completed";
        writer.WriteLine($"return new({CSharpLiteralWriter.Write(kind)}, fromState, state, eventName, revision, true, {value}, {error});");
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitBatchTestSeam(CSharpTextWriter writer)
    {
        writer.WriteLine("// Private test seam: never reachable from authored Copeland code.");
        writer.WriteLine("private static global::System.Action? __cope_batch_item_entered_for_testing = null;");
        writer.WriteLine("private static int __cope_batch_max_degree_for_testing = 0;");
        BatchRuntime.Emit(writer);
        writer.WriteLine();
    }

    private static void EmitAsyncRuntime(CSharpTextWriter writer)
    {
        writer.WriteLine("public sealed class CopeAsync<T>");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("private readonly global::System.Collections.Generic.List<(global::System.Action Success, global::System.Action Cancelled, global::System.Action Failed, global::System.Action Panicked)> continuations = []; ");
        writer.WriteLine("private int terminalState;");
        writer.WriteLine("public bool IsCompleted => terminalState != 0;");
        writer.WriteLine("public bool IsCancelled => terminalState == 2;");
        writer.WriteLine("public bool IsPanicked => terminalState == 3;");
        writer.WriteLine("public bool IsTransportFailed => terminalState == 4;");
        writer.WriteLine("public T Value { get; private set; } = default!;");
        writer.WriteLine("public bool Subscribe(global::System.Action success, global::System.Action cancelled, global::System.Action panicked) => SubscribeTransport(success, cancelled, panicked, panicked);");
        writer.WriteLine("public bool SubscribeTransport(global::System.Action success, global::System.Action cancelled, global::System.Action failed, global::System.Action panicked)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (IsCompleted) return true;");
        writer.WriteLine("continuations.Add((success, cancelled, failed, panicked));");
        writer.WriteLine("return false;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Resolve(T value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (terminalState != 0) return;");
        writer.WriteLine("terminalState = 1;");
        writer.WriteLine("Value = value;");
        writer.WriteLine("var pending = continuations.ToArray();");
        writer.WriteLine("continuations.Clear();");
        writer.WriteLine("foreach (var continuation in pending) continuation.Success();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Cancel()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (terminalState != 0) return;");
        writer.WriteLine("terminalState = 2;");
        writer.WriteLine("var pending = continuations.ToArray();");
        writer.WriteLine("continuations.Clear();");
        writer.WriteLine("foreach (var continuation in pending) continuation.Cancelled();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Fail()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (terminalState != 0) return;");
        writer.WriteLine("terminalState = 4;");
        writer.WriteLine("var pending = continuations.ToArray();");
        writer.WriteLine("continuations.Clear();");
        writer.WriteLine("foreach (var continuation in pending) continuation.Failed();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Panic()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (terminalState != 0) return;");
        writer.WriteLine("terminalState = 3;");
        writer.WriteLine("var pending = continuations.ToArray();");
        writer.WriteLine("continuations.Clear();");
        writer.WriteLine("foreach (var continuation in pending) continuation.Panicked();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("internal static class CopeAsyncPending");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("internal static CopeAsync<T> Create<T>() => new CopeAsync<T>();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitGeneratorRuntime(CSharpTextWriter writer)
    {
        writer.WriteLine("internal sealed class CopeGeneratorEnumerable<T>(global::System.Func<global::System.Collections.Generic.IEnumerator<T>> create) : global::System.Collections.Generic.IEnumerable<T>");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("public global::System.Collections.Generic.IEnumerator<T> GetEnumerator() => new CopeGeneratorEnumerator<T>(create());");
        writer.WriteLine("global::System.Collections.IEnumerator global::System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("internal sealed class CopeGeneratorEnumerator<T>(global::System.Collections.Generic.IEnumerator<T> inner) : global::System.Collections.Generic.IEnumerator<T>");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("private bool disposed;");
        writer.WriteLine("private bool running;");
        writer.WriteLine("public T Current => inner.Current;");
        writer.WriteLine("object global::System.Collections.IEnumerator.Current => Current!;");
        writer.WriteLine("public bool MoveNext()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (disposed) return false;");
        writer.WriteLine("if (running) throw new global::System.InvalidOperationException(\"A Copeland generator cannot be resumed while it is already running.\");");
        writer.WriteLine("running = true;");
        writer.WriteLine("try { return inner.MoveNext(); }");
        writer.WriteLine("finally { running = false; }");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Reset() => throw new global::System.NotSupportedException();");
        writer.WriteLine("public void Dispose() { if (disposed) return; disposed = true; inner.Dispose(); }");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitTsonTransportRuntime(CSharpTextWriter writer, CSharpSidecarContract? sidecarContract)
    {
        writer.WriteLine("internal static class CopeTsonTransport");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"internal const string BindingId = {CSharpLiteralWriter.Write(sidecarContract?.LogicalBindingId ?? string.Empty)};");
        writer.WriteLine($"internal const string ProtocolVersion = {CSharpLiteralWriter.Write(sidecarContract?.ProtocolVersion ?? CSharpSidecarContracts.ProtocolVersion)};");
        writer.WriteLine($"internal const string ExpectedDigest = {CSharpLiteralWriter.Write(sidecarContract?.ExpectedDigest ?? string.Empty)};");
        writer.WriteLine("private static readonly object Gate = new();");
        writer.WriteLine("private interface IPending { void Receive(string kind, string payload); void Fail(); }");
        writer.WriteLine("private sealed class Pending<T>(CopeAsync<T> computation, global::System.Func<string, string, T> decode) : IPending");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("public void Receive(string kind, string payload)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (kind == \"cancel\") { computation.Cancel(); return; }");
        writer.WriteLine("if (kind == \"failure\") { computation.Fail(); return; }");
        writer.WriteLine("if (kind != \"ok\" && kind != \"remote-error\") { computation.Fail(); return; }");
        writer.WriteLine("try { computation.Resolve(decode(kind, payload)); } catch { computation.Fail(); }");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public void Fail() => computation.Fail();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("private static readonly global::System.Collections.Generic.Dictionary<string, IPending> PendingByCorrelation = new(global::System.StringComparer.Ordinal);");
        writer.WriteLine("private static long nextCorrelation;");
        writer.WriteLine("internal static global::System.Action<string>? Dispatch = null;");
        writer.WriteLine("internal static CopeAsync<T> Start<T>(string operation, string request, global::System.Func<string, string, T> decode)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("string correlation = (++nextCorrelation).ToString(global::System.Globalization.CultureInfo.InvariantCulture);");
        writer.WriteLine("var computation = CopeAsyncPending.Create<T>();");
        writer.WriteLine("lock (Gate) { PendingByCorrelation.Add(correlation, new Pending<T>(computation, decode)); }");
        writer.WriteLine("try { Dispatch?.Invoke(Envelope(correlation, \"request\", operation, request)); } catch { FailCorrelation(correlation); }");
        writer.WriteLine("return computation;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("internal static bool Receive(string envelope)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (!TryReadEnvelope(envelope, out string correlation, out string kind, out _, out string payload)) return false;");
        writer.WriteLine("IPending? pending;");
        writer.WriteLine("lock (Gate) { if (!PendingByCorrelation.Remove(correlation, out pending)) return false; }");
        writer.WriteLine("pending.Receive(kind, payload);");
        writer.WriteLine("return true;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("internal static void ConnectionLost()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("global::System.Collections.Generic.List<IPending> pending;");
        writer.WriteLine("lock (Gate) { pending = new global::System.Collections.Generic.List<IPending>(PendingByCorrelation.Values); PendingByCorrelation.Clear(); }");
        writer.WriteLine("foreach (IPending item in pending) item.Fail();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("private static void FailCorrelation(string correlation)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("IPending? pending;");
        writer.WriteLine("lock (Gate) { if (!PendingByCorrelation.Remove(correlation, out pending)) return; }");
        writer.WriteLine("pending.Fail();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("internal static string Envelope(string correlation, string kind, string operation, string payload)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return \"const $schema: string = \\\"copeland://interop/transport/v1\\\"; record Envelope { correlation: string; kind: string; operation: string; payload: string; } const $value = $record.Envelope({\\\"correlation\\\":\\\"\" + Escape(correlation) + \"\\\",\\\"kind\\\":\\\"\" + Escape(kind) + \"\\\",\\\"operation\\\":\\\"\" + Escape(operation) + \"\\\",\\\"payload\\\":\\\"\" + Escape(payload) + \"\\\",});\";");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("""
            private static bool TryReadEnvelope(string value, out string correlation, out string kind, out string operation, out string payload)
            {
                const string prefix = "const $schema: string = \"copeland://interop/transport/v1\"; record Envelope { correlation: string; kind: string; operation: string; payload: string; } const $value = $record.Envelope({";
                int position = 0;
                if (!value.StartsWith(prefix, global::System.StringComparison.Ordinal)
                    || !ReadField(value, ref position, prefix, "\"correlation\":", out correlation)
                    || !ReadField(value, ref position, string.Empty, "\"kind\":", out kind)
                    || !ReadField(value, ref position, string.Empty, "\"operation\":", out operation)
                    || !ReadField(value, ref position, string.Empty, "\"payload\":", out payload)
                    || position > value.Length - 3
                    || string.CompareOrdinal(value, position, "});", 0, 3) != 0
                    || position + 3 != value.Length)
                {
                    correlation = kind = operation = payload = string.Empty;
                    return false;
                }
                return true;
            }

            private static bool ReadField(string value, ref int position, string prefix, string label, out string result)
            {
                result = string.Empty;
                if (prefix.Length > 0) position = prefix.Length;
                if (position > value.Length - label.Length || string.CompareOrdinal(value, position, label, 0, label.Length) != 0) return false;
                position += label.Length;
                if (position >= value.Length || value[position++] != '"') return false;
                var builder = new global::System.Text.StringBuilder();
                while (position < value.Length)
                {
                    char current = value[position++];
                    if (current == '"')
                    {
                        if (position >= value.Length || value[position++] != ',') return false;
                        result = builder.ToString();
                        return true;
                    }
                    if (current != '\\') { builder.Append(current); continue; }
                    if (position >= value.Length) return false;
                    char escape = value[position++];
                    if (escape == 'n') builder.Append('\n');
                    else if (escape == 'r') builder.Append('\r');
                    else if (escape == 't') builder.Append('\t');
                    else if (escape == '"' || escape == '\\') builder.Append(escape);
                    else return false;
                }
                return false;
            }

            private static string Escape(string value) => value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
            """);
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitAsyncFrame(CSharpTextWriter writer, MirFunction function)
    {
        writer.WriteLine($"private sealed class __CopeAsyncFrame_{CSharpNameMangler.Mangle(function.Name)}");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("public int State;");
        foreach (MirParameter parameter in function.Parameters)
        {
            writer.WriteLine($"public {MapValueStorageType(parameter.Type)} {CSharpNameMangler.Mangle(parameter.Name)} = default!;");
        }
        foreach (MirLocal local in function.Locals)
        {
            writer.WriteLine($"public {MapValueStorageType(local.Type)} {CSharpNameMangler.Mangle(local.Name)} = default!;");
        }
        if (function.SuspensionAutomaton is not null)
        {
            foreach (MirFrameSlot slot in function.SuspensionAutomaton.FrameSlots.Where(slot =>
                         slot.Id.Value.StartsWith("await_", StringComparison.Ordinal)
                         || slot.Id.Value.StartsWith("expression_", StringComparison.Ordinal)))
            {
                writer.WriteLine($"public {MapValueStorageType(slot.Type)} __{slot.Id.Value} = default!;");
            }
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitRecord(CSharpTextWriter writer, MirRecordDefinition record, bool usesSystemTextJson)
    {
        string typeName = RecordTypeName(record.Id);
        string parameters = string.Join(
            ", ",
            record.Fields.Select((field, index) => $"{MapType(field.Type)} value{index}"));

        writer.WriteLine($"public sealed class {typeName}");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"internal {typeName}({parameters})");
        writer.WriteLine("{");
        writer.Indent();
        for (int index = 0; index < record.Fields.Count; index++)
        {
            writer.WriteLine($"{RecordFieldName(record.Fields[index].Id)} = value{index};");
        }
        writer.Unindent();
        writer.WriteLine("}");

        foreach (var field in record.Fields)
        {
            writer.WriteLine();
            if (usesSystemTextJson)
            {
                writer.WriteLine("[global::System.Text.Json.Serialization.JsonInclude]");
                writer.WriteLine($"[global::System.Text.Json.Serialization.JsonPropertyName({CSharpLiteralWriter.Write(field.Name)})]");
            }
            string visibility = usesSystemTextJson || (record.IsClass && field.IsPublic) ? "public" : "internal";
            writer.WriteLine($"{visibility} {MapType(field.Type)} {RecordFieldName(field.Id)} {{ get; }}");
        }

        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitUnit(CSharpTextWriter writer)
    {
        writer.WriteLine("public readonly record struct CopeUnit"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("public static readonly CopeUnit Value = new();"); writer.Unindent(); writer.WriteLine("}"); writer.WriteLine();
    }

    private static void EmitArraySupport(CSharpTextWriter writer)
    {
        writer.WriteLine("internal static class CopeArray"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("public static T[] Create<T>(int length)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("if (length < 0)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("throw new global::System.ArgumentOutOfRangeException(nameof(length), \"Copeland mutable array length cannot be negative.\");"); writer.Unindent(); writer.WriteLine("}");
        writer.WriteLine("return new T[length];"); writer.Unindent(); writer.WriteLine("}");
        writer.WriteLine("public static T Get<T>(T[] values, int index)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("if (index < 0 || index >= values.Length)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("throw new global::System.IndexOutOfRangeException(\"Copeland array index is out of bounds.\");"); writer.Unindent(); writer.WriteLine("}");
        writer.WriteLine("return values[index];"); writer.Unindent(); writer.WriteLine("}");
        writer.WriteLine("public static T Set<T>(T[] values, int index, T value)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("if (index < 0 || index >= values.Length)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("throw new global::System.IndexOutOfRangeException(\"Copeland array index is out of bounds.\");"); writer.Unindent(); writer.WriteLine("}");
        writer.WriteLine("values[index] = value;");
        writer.WriteLine("return value;"); writer.Unindent(); writer.WriteLine("}"); writer.Unindent(); writer.WriteLine("}"); writer.WriteLine();
    }

    private static void EmitCallableDelegates(CSharpTextWriter writer, MirProgram program)
    {
        var callables = EnumerateTypes(program)
            .SelectMany(EnumerateCallableTypes)
            .GroupBy(CallableTypeIdentity, StringComparer.Ordinal)
            .OrderBy(group => group.Key, StringComparer.Ordinal)
            .Select(group => group.First())
            .ToArray();
        foreach (var callable in callables)
        {
            string parameters = string.Join(", ", callable.Parameters.Select((parameter, index) => $"{MapValueStorageType(parameter.Type)} value{index}"));
            writer.WriteLine($"public delegate {MapValueStorageType(callable.ReturnType)} {CallableDelegateName(callable)}({parameters});");
        }
        if (callables.Length > 0) writer.WriteLine();
    }

    private static void EmitCapturedCallableEnvironments(CSharpTextWriter writer, MirProgram program)
    {
        var functions = program.Functions.ToDictionary(function => function.Name, StringComparer.Ordinal);
        var constructions = EnumerateCallableConstructions(program)
            .Where(construction => construction.Captures.Count > 0)
            .GroupBy(construction => construction.CodeFunctionName, StringComparer.Ordinal)
            .OrderBy(group => group.Key, StringComparer.Ordinal);

        foreach (var group in constructions)
        {
            MirCallableConstructionExpression construction = group.First();
            if (!functions.TryGetValue(construction.CodeFunctionName, out MirFunction? code))
            {
                continue;
            }

            string environmentName = CapturedCallableEnvironmentName(code.Name);
            writer.WriteLine($"internal sealed class {environmentName}");
            writer.WriteLine("{");
            writer.Indent();
            for (int index = 0; index < construction.Captures.Count; index++)
            {
                writer.WriteLine($"private readonly {MapValueStorageType(code.Parameters[index].Type)} _capture{index};");
            }
            writer.WriteLine();
            string constructorParameters = string.Join(", ", construction.Captures.Select((capture, index) => $"{MapValueStorageType(capture.Type)} capture{index}"));
            writer.WriteLine($"internal {environmentName}({constructorParameters})");
            writer.WriteLine("{");
            writer.Indent();
            for (int index = 0; index < construction.Captures.Count; index++)
            {
                writer.WriteLine($"_capture{index} = capture{index};");
            }
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine();
            string invokeParameters = string.Join(", ", code.Parameters.Skip(construction.Captures.Count)
                .Select((parameter, index) => $"{MapValueStorageType(parameter.Type)} value{index}"));
            string arguments = string.Join(", ", Enumerable.Range(0, construction.Captures.Count).Select(index => $"_capture{index}")
                .Concat(Enumerable.Range(0, code.Parameters.Count - construction.Captures.Count).Select(index => $"value{index}")));
            writer.WriteLine($"internal {MapValueStorageType(code.ReturnType)} Invoke({invokeParameters}) => {ModuleClassName}.{CSharpNameMangler.Mangle(code.Name)}({arguments});");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine();
        }
    }

    private static void EmitResult(CSharpTextWriter writer)
    {
        writer.WriteLine("public readonly struct CopeResult<TValue, TError>"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("private readonly TValue _value;"); writer.WriteLine("private readonly TError _error;"); writer.WriteLine("public bool IsOk { get; }"); writer.WriteLine();
        writer.WriteLine("public TValue Value => IsOk ? _value : throw new global::System.InvalidOperationException(\"Result has no value.\");");
        writer.WriteLine("public TError Error => !IsOk ? _error : throw new global::System.InvalidOperationException(\"Result has no error.\");"); writer.WriteLine();
        writer.WriteLine("private CopeResult(bool isOk, TValue value, TError error)"); writer.WriteLine("{"); writer.Indent();
        writer.WriteLine("IsOk = isOk;"); writer.WriteLine("_value = value;"); writer.WriteLine("_error = error;"); writer.Unindent(); writer.WriteLine("}"); writer.WriteLine();
        writer.WriteLine("public static CopeResult<TValue, TError> Ok(TValue value) => new(true, value, default!);");
        writer.WriteLine("public static CopeResult<TValue, TError> Err(TError error) => new(false, default!, error);");
        writer.Unindent(); writer.WriteLine("}"); writer.WriteLine();
    }

    private static void EmitUnwrapPanic(CSharpTextWriter writer)
    {
        writer.WriteLine("private sealed class CopeUnwrapPanicException : global::System.Exception");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("public object? Error { get; }");
        writer.WriteLine();
        writer.WriteLine("public CopeUnwrapPanicException(object? error)");
        writer.WriteLine("    : base(\"COPE-PANIC-UNWRAP: Result unwrap encountered err\")");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("Error = error;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitEnum(CSharpTextWriter writer, MirEnum mirEnum)
    {
        var enumName = CSharpNameMangler.Mangle(mirEnum.Name); writer.WriteLine($"public abstract record {enumName}"); writer.WriteLine("{"); writer.Indent(); writer.WriteLine($"protected {enumName}()"); writer.WriteLine("{"); writer.WriteLine("}"); writer.WriteLine();
        foreach (var @case in mirEnum.Cases)
        {
            var caseName = CSharpNameMangler.Mangle(@case.Name);
            if (@case.PayloadFields.Count == 0)
            {
                writer.WriteLine($"public sealed record {caseName} : {enumName}");
                writer.WriteLine("{");
                writer.Indent();
                writer.WriteLine($"internal static {caseName} __Singleton {{ get; }} = new();");
                writer.Unindent();
                writer.WriteLine("}");
            }
            else
            {
                writer.WriteLine($"public sealed record {caseName}({string.Join(", ", @case.PayloadFields.Select(field => $"{MapType(field.Type)} {CSharpNameMangler.Mangle(field.Name)}"))}) : {enumName};");
            }
            writer.WriteLine();
        }
        writer.Unindent(); writer.WriteLine("}");
    }

    private static void EmitColumnSupport(CSharpTextWriter writer)
    {
        writer.WriteLine("public abstract class CopeColumn<T>");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("internal abstract int Count { get; }");
        writer.WriteLine("internal abstract CopeResult<T, TableBoundsError> Get(double index);");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitTable(
        CSharpTextWriter writer,
        MirTableDefinition table,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records,
        IReadOnlyDictionary<MirTableId, MirTableDefinition> tables,
        bool emitsTsonAccessors,
        bool supportsTableWith,
        IReadOnlySet<string> enumNames)
    {
        string tableType = TableTypeName(table.Id);
        string rowType = TableRowTypeName(table.RowTypeId);

        foreach (var column in table.Columns)
        {
            writer.WriteLine($"public sealed class {TableColumnTypeName(column.Id)} : CopeColumn<{MapType(column.ElementType)}>");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"private readonly {MapType(column.ElementType)}[] _values;");
            writer.WriteLine($"internal override int Count => _values.Length;");
            writer.WriteLine();
            writer.WriteLine($"internal {TableColumnTypeName(column.Id)}({MapType(column.ElementType)}[] values)");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine("_values = values;");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine();
            EmitBoundsCheckedElementAccess(writer, column.ElementType, "_values", table.RowCount);
            if (table.IsExported)
            {
                writer.WriteLine();
                writer.WriteLine($"public CopeResult<{MapType(column.ElementType)}, TableBoundsError> At(double index) => Get(index);");
            }
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine();
        }

        writer.WriteLine($"public sealed class {rowType}");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"private readonly {tableType} _table;");
        writer.WriteLine("private readonly int _index;");
        writer.WriteLine();
        writer.WriteLine($"internal {rowType}({tableType} table, int index)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("_table = table;");
        writer.WriteLine("_index = index;");
        writer.Unindent();
        writer.WriteLine("}");
        foreach (var column in table.Columns)
        {
            writer.WriteLine();
            if (table.IsExported)
            {
                writer.WriteLine($"public {MapType(column.ElementType)} {CSharpNameMangler.Mangle(column.Name)} => _table.{TableReadMethodName(column.Id)}(_index);");
                writer.WriteLine($"internal {MapType(column.ElementType)} {TableRowFieldName(column.Id)} => {CSharpNameMangler.Mangle(column.Name)};");
            }
            else
            {
                writer.WriteLine($"internal {MapType(column.ElementType)} {TableRowFieldName(column.Id)} => _table.{TableReadMethodName(column.Id)}(_index);");
            }
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();

        writer.WriteLine($"public sealed class {tableType}");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"internal int Count => {table.RowCount};");
        writer.WriteLine();
        foreach (var column in table.Columns)
        {
            writer.WriteLine($"private readonly {MapType(column.ElementType)}[] {TableStorageName(column.Id)};");
        }
        writer.WriteLine();
        writer.WriteLine($"private {tableType}({string.Join(", ", table.Columns.Select((column, index) => $"{MapType(column.ElementType)}[] values{index}"))})");
        writer.WriteLine("{");
        writer.Indent();
        for (int index = 0; index < table.Columns.Count; index++)
        {
            MirTableColumnDefinition column = table.Columns[index];
            writer.WriteLine($"{TableStorageName(column.Id)} = values{index};");
            writer.WriteLine($"{TableColumnPropertyName(column.Id)} = new {TableColumnTypeName(column.Id)}(values{index});");
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        string createParameters = table.DerivedPlan is null
            ? string.Empty
            : string.Join(", ", new[] { TableTypeName(table.DerivedPlan.SourceTableId) + " source" }
                .Concat(table.DerivedPlan.Joins.Select(join => TableTypeName(join.JoinedTableId) + " " + DerivedJoinParameterName(join))));
        writer.WriteLine($"internal static {tableType} Create({createParameters})");
        writer.WriteLine("{");
        writer.Indent();
        if (table.DerivedPlan is null)
        {
            for (int index = 0; index < table.Columns.Count; index++)
            {
                MirTableColumnDefinition column = table.Columns[index];
                if (column.Constants is not InitializerSequence<MirTableConstant> sequence)
                {
                    continue;
                }
                writer.WriteLine($"var values{index} = {ArrayAllocation(column.ElementType, sequence.Count)};");
                if (sequence.Count > 0)
                {
                    writer.WriteLine($"int offset{index} = 0;");
                }
                for (int segment = 0; segment < sequence.Values.Count; segment++)
                {
                    if (sequence.Counts[segment] == 0)
                    {
                        continue;
                    }
                    writer.WriteLine($"for (int turn = 0; turn < {sequence.Counts[segment]}; turn++)");
                    writer.WriteLine("{");
                    writer.Indent();
                    writer.WriteLine($"values{index}[offset{index}++] = {EmitTableConstant(sequence.Values[segment], records)};");
                    writer.Unindent();
                    writer.WriteLine("}");
                }
            }
            writer.WriteLine($"return new {tableType}(");
            writer.Indent();
            for (int index = 0; index < table.Columns.Count; index++)
            {
                MirTableColumnDefinition column = table.Columns[index];
                string comma = index == table.Columns.Count - 1 ? string.Empty : ",";
                if (column.Constants is InitializerSequence<MirTableConstant>)
                {
                    writer.WriteLine($"values{index}{comma}");
                }
                else
                {
                    string values = string.Join(", ", column.Constants.Select(constant => EmitTableConstant(constant, records)));
                    writer.WriteLine($"new {MapType(column.ElementType)}[] {{ {values} }}{comma}");
                }
            }
            writer.Unindent();
            writer.WriteLine(");");
        }
        else
        {
            MirDerivedTablePlan plan = table.DerivedPlan;
            for (int index = 0; index < table.Columns.Count; index++)
            {
                MirTableColumnDefinition column = table.Columns[index];
                writer.WriteLine($"var values{index} = new {MapType(column.ElementType)}[source.Count];");
            }
            foreach (MirRelationJoin join in plan.Joins)
            {
                MirTableDefinition joinedTable = tables[join.JoinedTableId];
                MirTableColumnDefinition joinedLookup = joinedTable.Columns.Single(column => column.Id == join.JoinedLookupColumnId);
                string parameter = DerivedJoinParameterName(join);
                string indexName = CSharpNameMangler.Mangle(join.Alias) + "Index";
                string rowIndexName = CSharpNameMangler.Mangle(join.Alias) + "IndexRow";
                writer.WriteLine($"var {indexName} = new global::System.Collections.Generic.Dictionary<{MapType(joinedLookup.ElementType)}, int>();");
                writer.WriteLine($"for (int {rowIndexName} = 0; {rowIndexName} < {parameter}.Count; {rowIndexName}++)");
                writer.WriteLine("{");
                writer.Indent();
                writer.WriteLine($"if (!{indexName}.TryAdd({parameter}.{TableReadMethodName(join.JoinedLookupColumnId)}({rowIndexName}), {rowIndexName}))");
                writer.WriteLine($"throw new global::System.InvalidOperationException(\"Derived join '{join.Alias}' requires unique lookup values.\");");
                writer.Unindent();
                writer.WriteLine("}");
            }
            writer.WriteLine("for (int index = 0; index < source.Count; index++)");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"var {CSharpNameMangler.Mangle(plan.SourceAlias)} = source.GetRow(index).Value;");
            foreach (MirRelationJoin join in plan.Joins)
            {
                string parameter = DerivedJoinParameterName(join);
                string indexName = CSharpNameMangler.Mangle(join.Alias) + "Index";
                string joinedRowIndex = CSharpNameMangler.Mangle(join.Alias) + "RowIndex";
                string lookupAlias = CSharpNameMangler.Mangle(join.LookupAlias);
                writer.WriteLine($"if (!{indexName}.TryGetValue({lookupAlias}.{TableRowFieldName(join.LookupColumnId)}, out int {joinedRowIndex}))");
                writer.WriteLine($"throw new global::System.InvalidOperationException(\"Derived join '{join.Alias}' could not resolve its declared reference.\");");
                writer.WriteLine($"var {CSharpNameMangler.Mangle(join.Alias)} = {parameter}.GetRow({joinedRowIndex}).Value;");
            }
            var executionContext = new MirFunction("__derived_table", [], new MirNamedType("void"), [], []);
            int temporaryIndex = 0;
            foreach (MirDerivedTableLocal local in plan.Locals)
            {
                string expression = EmitExpression(writer, local.Expression, executionContext, enumNames, ref temporaryIndex, diagnostics: []);
                writer.WriteLine($"{MapType(local.Type)} {CSharpNameMangler.Mangle(local.RuntimeName)} = {expression};");
            }
            foreach (MirDerivedTableColumnPlan projection in plan.Columns)
            {
                int outputIndex = table.Columns.ToList().FindIndex(column => column.Id == projection.ColumnId);
                string expression = EmitExpression(writer, projection.Expression, executionContext, enumNames, ref temporaryIndex, diagnostics: []);
                writer.WriteLine($"values{outputIndex}[index] = {expression};");
            }
            writer.Unindent();
            writer.WriteLine("}");
            string lengthCheck = string.Join(" || ", table.Columns.Select((_, index) => $"values{index}.Length != source.Count"));
            writer.WriteLine($"if ({lengthCheck})");
            writer.WriteLine($"throw new global::System.InvalidOperationException(\"Derived table '{table.Name}' produced misaligned column lengths.\");");
            writer.WriteLine($"return new {tableType}({string.Join(", ", table.Columns.Select((_, index) => "values" + index))});");
        }
        writer.Unindent();
        writer.WriteLine("}");
        if (supportsTableWith && table.DerivedPlan is null)
        {
            writer.WriteLine();
            foreach (MirTableColumnDefinition replacementColumn in table.Columns)
            {
                writer.WriteLine($"internal {tableType} {TableWithColumnMethodName(replacementColumn.Id)}({MapType(replacementColumn.ElementType)}[] values)");
                writer.WriteLine("{");
                writer.Indent();
                writer.WriteLine($"return new {tableType}(");
                writer.Indent();
                for (int index = 0; index < table.Columns.Count; index++)
                {
                    MirTableColumnDefinition column = table.Columns[index];
                    string argument = column.Id == replacementColumn.Id
                        ? "values"
                        : TableStorageName(column.Id);
                    string comma = index == table.Columns.Count - 1 ? string.Empty : ",";
                    writer.WriteLine($"{argument}{comma}");
                }
                writer.Unindent();
                writer.WriteLine(");");
                writer.Unindent();
                writer.WriteLine("}");
                writer.WriteLine();
            }
        }
        if (table.IsExported)
        {
            writer.WriteLine($"public int RowCount => {table.RowCount};");
        }
        foreach (var column in table.Columns)
        {
            writer.WriteLine();
            if (table.IsExported)
            {
                writer.WriteLine($"public {TableColumnTypeName(column.Id)} {CSharpNameMangler.Mangle(column.Name)} => {TableColumnPropertyName(column.Id)};");
            }
            writer.WriteLine($"internal {TableColumnTypeName(column.Id)} {TableColumnPropertyName(column.Id)} {{ get; }}");
            writer.WriteLine();
            writer.WriteLine($"internal {MapType(column.ElementType)} {TableReadMethodName(column.Id)}(int index) => {TableStorageName(column.Id)}[index];");
            if (emitsTsonAccessors)
            {
                writer.WriteLine($"internal {MapType(column.ElementType)}[] {TableTsonStorageAccessName(column.Id)}() => {TableStorageName(column.Id)};");
            }
        }
        writer.WriteLine();
        writer.WriteLine($"internal CopeResult<{rowType}, TableBoundsError> GetRow(double index)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (double.IsNaN(index) || double.IsInfinity(index) || index != global::System.Math.Truncate(index))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return CopeResult<" + rowType + ", TableBoundsError>.Err(new TableBoundsError.InvalidIndex(index));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"if (index < 0 || index >= {table.RowCount.ToString(global::System.Globalization.CultureInfo.InvariantCulture)})");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return CopeResult<" + rowType + ", TableBoundsError>.Err(new TableBoundsError.OutOfBounds(index, " + table.RowCount.ToString(global::System.Globalization.CultureInfo.InvariantCulture) + ".0));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("return CopeResult<" + rowType + ", TableBoundsError>.Ok(new " + rowType + "(this, (int)index));");
        writer.Unindent();
        writer.WriteLine("}");
        if (table.IsExported)
        {
            writer.WriteLine();
            writer.WriteLine($"public CopeResult<{rowType}, TableBoundsError> At(double index) => GetRow(index);");
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitBoundsCheckedElementAccess(
        CSharpTextWriter writer,
        MirType elementType,
        string storage,
        int rowCount,
        string accessibility = "internal override")
    {
        string elementTypeName = MapType(elementType);
        writer.WriteLine($"{accessibility} CopeResult<{elementTypeName}, TableBoundsError> Get(double index)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (double.IsNaN(index) || double.IsInfinity(index) || index != global::System.Math.Truncate(index))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"return CopeResult<{elementTypeName}, TableBoundsError>.Err(new TableBoundsError.InvalidIndex(index));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"if (index < 0 || index >= {rowCount.ToString(global::System.Globalization.CultureInfo.InvariantCulture)})");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"return CopeResult<{elementTypeName}, TableBoundsError>.Err(new TableBoundsError.OutOfBounds(index, {rowCount.ToString(global::System.Globalization.CultureInfo.InvariantCulture)}.0));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"return CopeResult<{elementTypeName}, TableBoundsError>.Ok({storage}[(int)index]);");
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static string ArrayAllocation(MirType elementType, int length)
    {
        string nestedRanks = string.Empty;
        while (elementType is MirArrayType nested)
        {
            nestedRanks += "[]";
            elementType = nested.ElementType;
        }
        return $"new {MapType(elementType)}[{length}]{nestedRanks}";
    }

    private static string EmitTableConstant(MirTableConstant constant, IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        return constant switch
        {
            MirTableLiteralConstant literal => CSharpLiteralWriter.Write(literal.Value),
            MirTableArrayConstant array => $"new {MapType(array.ArrayType.ElementType)}[] {{ {string.Join(", ", array.Elements.Select(element => EmitTableConstant(element, records)))} }}",
            MirTableRecordConstant record => EmitTableRecordConstant(record, records),
            MirTableEnumConstant value when value.Payloads.Count == 0 => $"{CSharpNameMangler.Mangle(value.EnumName)}.{CSharpNameMangler.Mangle(value.CaseName)}.__Singleton",
            MirTableEnumConstant value => $"new {CSharpNameMangler.Mangle(value.EnumName)}.{CSharpNameMangler.Mangle(value.CaseName)}({string.Join(", ", value.Payloads.Select(payload => EmitTableConstant(payload, records)))})",
            MirTableResultConstant result => EmitTableResultConstant(result, records),
            _ => throw new InvalidOperationException($"Unsupported validated table constant {constant.GetType().Name}."),
        };
    }

    private static string EmitTableRecordConstant(MirTableRecordConstant constant, IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        MirRecordDefinition definition = records[constant.RecordTypeId];
        var values = constant.Fields.ToDictionary(field => field.FieldId, field => field.Value);
        return $"new {RecordTypeName(constant.RecordTypeId)}({string.Join(", ", definition.Fields.Select(field => EmitTableConstant(values[field.Id], records)))})";
    }

    private static string EmitTableResultConstant(MirTableResultConstant constant, IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        string successType = MapResultComponentType(constant.Type.SuccessType);
        string errorType = MapType(constant.Type.ErrorType);
        string factory = constant.IsOk ? "Ok" : "Err";
        return $"CopeResult<{successType}, {errorType}>.{factory}({EmitTableConstant(constant.Payload, records)})";
    }

    private static void EmitFunction(
        CSharpTextWriter writer,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records,
        List<CSharpDiagnostic> diagnostics)
    {
        if (function.IsAsync)
        {
            var asyncPreviousState = CurrentEmissionState.Value;
            CurrentEmissionState.Value = new CSharpEmissionState(records);
            try
            {
                EmitAsyncFunction(writer, function, diagnostics);
            }
            finally
            {
                CurrentEmissionState.Value = asyncPreviousState;
            }
            return;
        }
        if (function.IsGenerator)
        {
            EmitGeneratorFunction(writer, function, enumNames, records, diagnostics);
            return;
        }
        var returnType = MapType(function.ReturnType); var parameters = string.Join(", ", function.Parameters.Select(parameter => $"{MapType(parameter.Type)} {CSharpNameMangler.Mangle(parameter.Name)}"));
        writer.WriteLine($"{FunctionAccessibility(function)} static {returnType} {CSharpNameMangler.Mangle(function.Name)}({parameters})"); writer.WriteLine("{"); writer.Indent();
        var tempIndex = 0;
        var previousState = CurrentEmissionState.Value;
        CurrentEmissionState.Value = new CSharpEmissionState(records);
        try
        {
            foreach (var statement in function.Body) EmitStatement(writer, statement, function, enumNames, ref tempIndex, diagnostics);
        }
        finally
        {
            CurrentEmissionState.Value = previousState;
        }
        writer.Unindent(); writer.WriteLine("}"); writer.WriteLine();
    }

    private static void EmitGeneratorFunction(
        CSharpTextWriter writer,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records,
        List<CSharpDiagnostic> diagnostics)
    {
        var iterable = (MirIterableType)function.ReturnType;
        string elementType = MapValueStorageType(iterable.ElementType);
        string returnType = MapType(function.ReturnType);
        string parameters = string.Join(", ", function.Parameters.Select(parameter => $"{MapType(parameter.Type)} {CSharpNameMangler.Mangle(parameter.Name)}"));
        string arguments = string.Join(", ", function.Parameters.Select(parameter => CSharpNameMangler.Mangle(parameter.Name)));
        string publicName = CSharpNameMangler.Mangle(function.Name);
        string rawName = "__cope_generator_" + publicName;

        writer.WriteLine($"{FunctionAccessibility(function)} static {returnType} {publicName}({parameters}) => new CopeGeneratorEnumerable<{elementType}>(() => {rawName}({arguments}).GetEnumerator());");
        writer.WriteLine($"private static {returnType} {rawName}({parameters})");
        writer.WriteLine("{");
        writer.Indent();
        var tempIndex = 0;
        var previousState = CurrentEmissionState.Value;
        CurrentEmissionState.Value = new CSharpEmissionState(records);
        try
        {
            foreach (MirStatement statement in function.Body)
            {
                EmitStatement(writer, statement, function, enumNames, ref tempIndex, diagnostics);
            }
            if (!ContainsYield(function.Body))
            {
                writer.WriteLine("yield break;");
            }
        }
        finally
        {
            CurrentEmissionState.Value = previousState;
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static bool ContainsYield(IEnumerable<MirStatement> statements)
        => statements.Any(statement => statement switch
        {
            MirYieldStatement => true,
            MirIfStatement conditional => ContainsYield(conditional.ThenStatements)
                || conditional.ElseStatements is not null && ContainsYield(conditional.ElseStatements),
            MirWhileStatement loop => ContainsYield(loop.BodyStatements),
            MirForStatement loop => loop.Initializer is not null && ContainsYield([loop.Initializer]) || ContainsYield(loop.BodyStatements),
            MirForOfStatement loop => ContainsYield(loop.BodyStatements),
            _ => false,
        });

    private static void EmitAsyncFunction(CSharpTextWriter writer, MirFunction function, List<CSharpDiagnostic> diagnostics)
    {
        if (!TryGetAsyncStates(function.SuspensionAutomaton?.ExecutionPlan, out List<AsyncState> states, out int entryState))
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-ASYNC-0001", $"Async function '{function.Name}' requires structured suspension lowering before it can emit control flow."));
            return;
        }

        string resultType = MapValueStorageType(function.ReturnType);
        string parameters = string.Join(", ", function.Parameters.Select(parameter => $"{MapType(parameter.Type)} {CSharpNameMangler.Mangle(parameter.Name)}"));
        string frameType = "__CopeAsyncFrame_" + CSharpNameMangler.Mangle(function.Name);
        writer.WriteLine($"{FunctionAccessibility(function)} static CopeAsync<{resultType}> {CSharpNameMangler.Mangle(function.Name)}({parameters})");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"var frame = new {frameType}();");
        foreach (MirParameter parameter in function.Parameters)
        {
            string name = CSharpNameMangler.Mangle(parameter.Name);
            writer.WriteLine($"frame.{name} = {name};");
        }
        writer.WriteLine($"var computation = new CopeAsync<{resultType}>();");
        writer.WriteLine($"frame.State = {entryState};");
        writer.WriteLine("void Step()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (computation.IsCompleted) return;");
        writer.WriteLine("while (true)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("switch (frame.State)");
        writer.WriteLine("{");
        writer.Indent();
        foreach (AsyncState state in states.OrderBy(state => state.Id))
        {
            writer.WriteLine($"case {state.Id}:");
            writer.Indent();
            if (state.Kind == AsyncStateKind.Branch)
            {
                writer.WriteLine($"frame.State = {EmitAsyncExpression(state.Condition!, function)} ? {state.ThenState} : {state.ElseState};");
                writer.WriteLine("continue;");
                writer.Unindent();
                continue;
            }
            if (state.Kind == AsyncStateKind.Jump)
            {
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine("continue;");
                writer.Unindent();
                continue;
            }
            if (state.Kind == AsyncStateKind.Await)
            {
                string pending = "frame.__" + state.AwaitedComputationSlot!.Value.Value;
                string resumed = "frame.__" + state.ValueSlot!.Value.Value;
                writer.WriteLine($"{pending} = {EmitAsyncExpression(state.Expression!, function)};");
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine($"if (!{pending}.SubscribeTransport(() => {{ {resumed} = {pending}.Value; Step(); }}, computation.Cancel, computation.Fail, computation.Panic)) return;");
                writer.WriteLine($"if ({pending}.IsCancelled) {{ computation.Cancel(); return; }}");
                writer.WriteLine($"if ({pending}.IsTransportFailed) {{ computation.Fail(); return; }}");
                writer.WriteLine($"if ({pending}.IsPanicked) {{ computation.Panic(); return; }}");
                writer.WriteLine($"{resumed} = {pending}.Value;");
                writer.WriteLine("continue;");
                writer.Unindent();
                continue;
            }
            if (state.Kind == AsyncStateKind.Evaluate)
            {
                writer.WriteLine($"frame.__{state.ValueSlot!.Value.Value} = {EmitAsyncExpression(state.Expression!, function)};");
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine("continue;");
                writer.Unindent();
                continue;
            }
            if (state.Kind == AsyncStateKind.Propagate)
            {
                string result = "__cope_propagate_" + state.Id;
                string success = "frame.__" + state.ValueSlot!.Value.Value;
                writer.WriteLine($"var {result} = {EmitAsyncExpression(state.Expression!, function)};");
                if (state.PropagationTarget is MirPropagationTarget.LexicalExcept)
                {
                    if (state.HandlerState < 0 || state.HandlerErrorSlot is null)
                    {
                        diagnostics.Add(new CSharpDiagnostic("COPE-CS-ASYNC-0003", $"Async function '{function.Name}' has a lexical Result propagation target without a validated handler state."));
                        writer.WriteLine("computation.Panic();");
                        writer.WriteLine("return;");
                    }
                    else
                    {
                        writer.WriteLine($"if (!{result}.IsOk) {{ frame.__{state.HandlerErrorSlot.Value.Value} = {result}.Error; frame.State = {state.HandlerState}; continue; }}");
                        writer.WriteLine($"{success} = {result}.Value;");
                        writer.WriteLine($"frame.State = {state.NextState};");
                        writer.WriteLine("continue;");
                    }
                    writer.Unindent();
                    continue;
                }

                if (state.PropagationTarget is not MirPropagationTarget.FunctionReturn
                    || function.ReturnType is not MirResultType propagatedFunctionResult)
                {
                    diagnostics.Add(new CSharpDiagnostic("COPE-CS-ASYNC-0003", $"Async function '{function.Name}' has an unsupported Result propagation target."));
                    writer.WriteLine("computation.Panic();");
                    writer.WriteLine("return;");
                    writer.Unindent();
                    continue;
                }

                string errorResult = $"CopeResult<{MapResultComponentType(propagatedFunctionResult.SuccessType)}, {MapType(propagatedFunctionResult.ErrorType)}>.Err({result}.Error)";
                writer.WriteLine($"if (!{result}.IsOk) {{ computation.Resolve({errorResult}); return; }}");
                writer.WriteLine($"{success} = {result}.Value;");
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine("continue;");
                writer.Unindent();
                continue;
            }
            MirStatement statement = state.Statement!;
            if (statement is MirVariableDeclarationStatement plainDeclaration)
            {
                writer.WriteLine($"frame.{CSharpNameMangler.Mangle(plainDeclaration.Local.Name)} = {EmitAsyncExpression(plainDeclaration.Initializer, function)};");
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine("continue;");
            }
            else if (statement is MirReturnStatement { Expression: not null } returned)
            {
                writer.WriteLine($"computation.Resolve({EmitAsyncExpression(returned.Expression, function)});");
                writer.WriteLine("return;");
            }
            else if (statement is MirReturnStatement)
            {
                writer.WriteLine("computation.Resolve(default!);");
                writer.WriteLine("return;");
            }
            else if (statement is MirExpressionStatement expression)
            {
                writer.WriteLine($"{EmitAsyncExpression(expression.Expression, function)};");
                writer.WriteLine($"frame.State = {state.NextState};");
                writer.WriteLine("continue;");
            }
            else
            {
                diagnostics.Add(new CSharpDiagnostic("COPE-CS-ASYNC-0002", $"Async function '{function.Name}' contains an unsupported straight-line statement '{statement.GetType().Name}'."));
                writer.WriteLine("return;");
            }
            writer.Unindent();
        }
        writer.WriteLine("default:");
        writer.Indent();
        writer.WriteLine("return;");
        writer.Unindent();
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("Step();");
        writer.WriteLine("return computation;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static bool TryGetAsyncStates(MirAsyncExecutionPlan? plan, out List<AsyncState> states, out int entryState)
    {
        states = [];
        entryState = -1;
        if (plan is null)
        {
            return false;
        }

        var numbers = plan.States.Select((state, index) => (state.Id, index)).ToDictionary(pair => pair.Id, pair => pair.index);
        if (!numbers.TryGetValue(plan.EntryStateId, out entryState))
        {
            return false;
        }

        foreach (MirAsyncExecutionState state in plan.States)
        {
            int id = numbers[state.Id];
            switch (state)
            {
                case MirAsyncStatementExecutionState statement when numbers.TryGetValue(statement.NextStateId, out int next):
                    states.Add(new AsyncState(id, AsyncStateKind.Statement, statement.Statement, next));
                    break;
                case MirAsyncReturnExecutionState returned:
                    states.Add(new AsyncState(id, AsyncStateKind.Return, returned.Statement, -1));
                    break;
                case MirAsyncBranchExecutionState branch
                    when numbers.TryGetValue(branch.ThenStateId, out int thenState)
                    && numbers.TryGetValue(branch.ElseStateId, out int elseState):
                    states.Add(new AsyncState(id, AsyncStateKind.Branch, null, -1, thenState, elseState, condition: branch.Condition));
                    break;
                case MirAsyncJumpExecutionState jump when numbers.TryGetValue(jump.TargetStateId, out int target):
                    states.Add(new AsyncState(id, AsyncStateKind.Jump, null, target));
                    break;
                case MirAsyncAwaitExecutionState awaitState when numbers.TryGetValue(awaitState.NextStateId, out int awaitNext):
                    states.Add(new AsyncState(id, AsyncStateKind.Await, null, awaitNext, awaitedComputationSlot: awaitState.AwaitedComputationSlot, valueSlot: awaitState.ResumedValueSlot, expression: awaitState.AwaitedComputation));
                    break;
                case MirAsyncEvaluateExpressionState evaluation when numbers.TryGetValue(evaluation.NextStateId, out int evaluationNext):
                    states.Add(new AsyncState(id, AsyncStateKind.Evaluate, null, evaluationNext, valueSlot: evaluation.TargetSlot, expression: evaluation.Expression));
                    break;
                case MirAsyncPropagateExecutionState propagation
                    when numbers.TryGetValue(propagation.NextStateId, out int propagationNext)
                    && (propagation.HandlerStateId is null || numbers.TryGetValue(propagation.HandlerStateId.Value, out _)):
                    int handlerState = propagation.HandlerStateId is { } handlerStateId
                        ? numbers[handlerStateId]
                        : -1;
                    states.Add(new AsyncState(id, AsyncStateKind.Propagate, null, propagationNext, valueSlot: propagation.SuccessValueSlot, expression: propagation.ResultExpression, propagationTarget: propagation.Target, handlerState: handlerState, handlerErrorSlot: propagation.HandlerErrorSlot));
                    break;
                default:
                    return false;
            }
        }

        return true;
    }

    private static string EmitAsyncExpression(MirExpression expression, MirFunction function)
    {
        return expression switch
        {
            MirLiteralExpression literal => CSharpLiteralWriter.Write(literal.Value),
            MirTextDocumentExpression document => "throw new global::System.InvalidOperationException(\"Text values are not supported in async functions in M0.\")",
            MirUnitExpression => "CopeUnit.Value",
            MirVariableExpression variable => "frame." + CSharpNameMangler.Mangle(variable.Name),
            MirAsyncFrameSlotExpression slot => "frame.__" + slot.SlotId.Value,
            MirMutableArrayConstructionExpression construction => $"CopeArray.Create<{MapType(construction.MutableArrayType.ElementType)}>({EmitAsyncExpression(construction.Length, function)})",
            MirMutableArrayElementAssignmentExpression assignment => $"CopeArray.Set({EmitAsyncExpression(assignment.Receiver, function)}, {EmitAsyncExpression(assignment.Index, function)}, {EmitAsyncExpression(assignment.Value, function)})",
            MirMutableArrayFreezeExpression freeze => $"({MapType(freeze.ArrayType)}){EmitAsyncExpression(freeze.Receiver, function)}.Clone()",
            MirAssignmentExpression assignment => AssignmentText(assignment, "frame." + CSharpNameMangler.Mangle(assignment.Name), EmitAsyncExpression(assignment.Expression, function)),
            MirBinaryExpression binary => BinaryText(binary, EmitAsyncExpression(binary.Left, function), EmitAsyncExpression(binary.Right, function)),
            MirUnaryExpression unary => UnaryText(unary, EmitAsyncExpression(unary.Operand, function)),
            MirCallExpression call => $"{NativeCallName(call) ?? CSharpNameMangler.Mangle(call.FunctionName)}({string.Join(", ", call.Arguments.Select(argument => EmitAsyncExpression(argument, function)))})",
            MirRecordConstructionExpression construction => EmitAsyncRecordConstruction(construction, function),
            MirRecordFieldAccessExpression access => $"({EmitAsyncExpression(access.Receiver, function)}).{RecordFieldName(access.FieldId)}",
            MirTsonTransportExpression transport => EmitAsyncTsonTransport(transport, function),
            MirNpmCallExpression npm => EmitAsyncNpmCall(npm, function),
            MirClrInvocationExpression invocation => EmitClrInvocation(invocation, function),
            MirClrPropertyAccessExpression property => EmitClrProperty(property, function),
            MirOkExpression ok => $"CopeResult<{MapResultComponentType(((MirResultType)ok.Type).SuccessType)}, {MapType(((MirResultType)ok.Type).ErrorType)}>.Ok({EmitAsyncExpression(ok.Payload, function)})",
            MirErrExpression err => $"CopeResult<{MapResultComponentType(((MirResultType)err.Type).SuccessType)}, {MapType(((MirResultType)err.Type).ErrorType)}>.Err({EmitAsyncExpression(err.Payload, function)})",
            _ => throw new InvalidOperationException($"Async function '{function.Name}' uses expression '{expression.GetType().Name}' which has not been lowered into an explicit state expression."),
        };
    }

    private static string EmitAsyncRecordConstruction(MirRecordConstructionExpression construction, MirFunction function)
    {
        MirRecordDefinition record = GetRecordDefinition(construction.RecordTypeId);
        IReadOnlyDictionary<MirRecordFieldId, MirExpression> valuesByField = construction.Initializers
            .ToDictionary(initializer => initializer.FieldId, initializer => initializer.Value);
        string arguments = string.Join(", ", record.Fields.Select(field => EmitAsyncExpression(valuesByField[field.Id], function)));
        return $"new {RecordTypeName(record.Id)}({arguments})";
    }

    private static string EmitAsyncTsonTransport(MirTsonTransportExpression transport, MirFunction function)
    {
        var result = (MirResultType)transport.AsyncType.EventualType;
        string resultType = $"CopeResult<{MapResultComponentType(result.SuccessType)}, {MapType(result.ErrorType)}>";
        string operation = EmitAsyncExpression(transport.Operation, function);
        string request = EmitAsyncExpression(transport.Request, function);
        string encodedRequest = $"{TsonEncodeMethodName(transport.RequestPlanId)}({request})";
        string decodedResponse = $"{TsonDecodeMethodName(transport.ResponsePlanId)}(payload)";
        string decodedError = $"{TsonDecodeMethodName(transport.RemoteErrorPlanId)}(payload)";
        return $"CopeTsonTransport.Start<{resultType}>({operation}, {encodedRequest}.Value, (kind, payload) => kind == \"ok\" ? {resultType}.Ok({decodedResponse}) : {resultType}.Err({decodedError}))";
    }

    private static string EmitAsyncNpmCall(MirNpmCallExpression npm, MirFunction function)
    {
        var result = (MirResultType)npm.AsyncType.EventualType;
        string resultType = $"CopeResult<{MapResultComponentType(result.SuccessType)}, {MapType(result.ErrorType)}>";
        string request = npm.ArgumentTuple is MirRecordConstructionExpression tuple
            ? $"new {RecordTypeName(tuple.RecordTypeId)}({string.Join(", ", tuple.Initializers.Select(initializer => EmitAsyncExpression(initializer.Value, function)))})"
            : EmitAsyncExpression(npm.ArgumentTuple, function);
        string operation = CSharpLiteralWriter.Write("npm:" + npm.PackageName + "@" + npm.PackageVersion + ":" + npm.ExportName);
        string response = $"{TsonDecodeMethodName(npm.ResponsePlanId)}(payload).{RecordFieldName(npm.ResponseValueFieldId)}";
        string error = $"{TsonDecodeMethodName(npm.RemoteErrorPlanId)}(payload).{RecordFieldName(npm.RemoteErrorValueFieldId)}";
        return $"CopeTsonTransport.Start<{resultType}>({operation}, {TsonEncodeMethodName(npm.RequestPlanId)}({request}).Value, (kind, payload) => kind == \"ok\" ? {resultType}.Ok({response}) : {resultType}.Err({error}))";
    }

    private static string EmitClrInvocation(MirClrInvocationExpression invocation, MirFunction function)
    {
        string[] arguments = invocation.Arguments.Select(argument => EmitAsyncExpression(argument, function)).ToArray();
        return EmitClrInvocationCore(invocation.Member, invocation.Receiver is null ? null : EmitAsyncExpression(invocation.Receiver, function), arguments);
    }

    private static string EmitClrProperty(MirClrPropertyAccessExpression property, MirFunction function)
        => EmitClrPropertyCore(property.Property, property.Receiver is null ? null : EmitAsyncExpression(property.Receiver, function));

    private static string EmitClrInvocation(CSharpTextWriter writer, MirClrInvocationExpression invocation, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        string[] arguments = EmitArguments(invocation.Arguments, writer, function, enumNames, ref tempIndex, diagnostics).ToArray();
        string? receiver = invocation.Receiver is null ? null : EmitExpression(writer, invocation.Receiver, function, enumNames, ref tempIndex, diagnostics);
        return EmitClrInvocationCore(invocation.Member, receiver, arguments);
    }

    private static string EmitClrProperty(CSharpTextWriter writer, MirClrPropertyAccessExpression property, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        string? receiver = property.Receiver is null ? null : EmitExpression(writer, property.Receiver, function, enumNames, ref tempIndex, diagnostics);
        return EmitClrPropertyCore(property.Property, receiver);
    }

    private static string EmitClrInvocationCore(MirClrMemberIdentity member, string? receiver, IReadOnlyList<string> argumentValues)
    {
        string arguments = string.Join(", ", argumentValues);
        string declaringType = member.DeclaringTypeIdentity is null ? "global::" + member.DeclaringType : MapClrType(member.DeclaringTypeIdentity);
        if (member.IsConstructor) return $"new {declaringType}({arguments})";
        string target = member.IsStatic ? declaringType : receiver ?? throw new InvalidOperationException("CLR instance invocation has no receiver.");
        if (member.IsIndexerGetter) return $"({target})[{string.Join(", ", argumentValues)}]";
        if (member.IsIndexerSetter) return $"({target})[{string.Join(", ", argumentValues.Take(argumentValues.Count - 1))}] = {argumentValues[^1]}";
        string genericSuffix = member.GenericArguments.Count == 0 ? string.Empty : "<" + string.Join(", ", member.GenericArguments.Select(MapType)) + ">";
        return $"{target}.{member.MemberName}{genericSuffix}({arguments})";
    }

    private static string EmitClrPropertyCore(MirClrMemberIdentity property, string? receiver)
    {
        string target = property.IsStatic ? (property.DeclaringTypeIdentity is null ? "global::" + property.DeclaringType : MapClrType(property.DeclaringTypeIdentity)) : receiver ?? throw new InvalidOperationException("CLR instance property has no receiver.");
        return $"{target}.{property.MemberName}";
    }

    private static void EmitStatement(CSharpTextWriter writer, MirStatement statement, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        switch (statement)
        {
            case MirVariableDeclarationStatement declaration:
                writer.WriteLine($"{MapValueStorageType(declaration.Local.Type)} {CSharpNameMangler.Mangle(declaration.Local.Name)} = {EmitExpression(writer, declaration.Initializer, function, enumNames, ref tempIndex, diagnostics)};"); break;
            case MirResourceUsingDeclarationStatement declaration:
                writer.WriteLine($"using var {CSharpNameMangler.Mangle(declaration.Local.Name)} = {EmitExpression(writer, declaration.Initializer, function, enumNames, ref tempIndex, diagnostics)};");
                break;
            case MirCSharpBlockStatement block:
                EmitCSharpBlock(writer, block, CurrentSourcePath.Value);
                break;
            case MirExpressionStatement expression:
                writer.WriteLine($"{EmitExpression(writer, expression.Expression, function, enumNames, ref tempIndex, diagnostics)};"); break;
            case MirReturnStatement { Expression: null } when function.IsGenerator:
                writer.WriteLine("yield break;"); break;
            case MirReturnStatement { Expression: null }:
                writer.WriteLine("return;"); break;
            case MirReturnStatement returnStatement:
                if (function.ReturnType.Identifier == "void")
                {
                    writer.WriteLine($"{EmitExpression(writer, returnStatement.Expression!, function, enumNames, ref tempIndex, diagnostics)};");
                    writer.WriteLine("return;");
                }
                else
                {
                    writer.WriteLine($"return {EmitExpression(writer, returnStatement.Expression!, function, enumNames, ref tempIndex, diagnostics)};");
                }
                break;
            case MirIfStatement conditional:
                writer.WriteLine($"if ({EmitExpression(writer, conditional.Condition, function, enumNames, ref tempIndex, diagnostics)})"); writer.WriteLine("{"); writer.Indent(); foreach (var nested in conditional.ThenStatements) EmitStatement(writer, nested, function, enumNames, ref tempIndex, diagnostics); writer.Unindent(); writer.WriteLine("}");
                if (conditional.ElseStatements is not null) { writer.WriteLine("else"); writer.WriteLine("{"); writer.Indent(); foreach (var nested in conditional.ElseStatements) EmitStatement(writer, nested, function, enumNames, ref tempIndex, diagnostics); writer.Unindent(); writer.WriteLine("}"); } break;
            case MirWhileStatement loop:
                EmitWhileStatement(writer, loop, function, enumNames, ref tempIndex, diagnostics);
                break;
            case MirForStatement loop:
                EmitForStatement(writer, loop, function, enumNames, ref tempIndex, diagnostics);
                break;
            case MirForOfStatement loop:
                if (loop.Iterable is MirTableRowsExpression or MirTableWhereExpression)
                {
                    EmitTableForOf(writer, loop, function, enumNames, ref tempIndex, diagnostics);
                }
                else
                {
                    writer.WriteLine($"foreach ({MapValueStorageType(loop.Local.Type)} {CSharpNameMangler.Mangle(loop.Local.Name)} in {EmitExpression(writer, loop.Iterable, function, enumNames, ref tempIndex, diagnostics)})");
                    EmitStatementBlock(writer, loop.BodyStatements, function, enumNames, ref tempIndex, diagnostics);
                }
                break;
            case MirBreakStatement:
                writer.WriteLine("break;");
                break;
            case MirContinueStatement:
                MirExpression? increment = CurrentEmissionState.Value?.ContinueIncrements.TryPeek(out MirExpression? currentIncrement) == true
                    ? currentIncrement
                    : null;
                if (increment is not null)
                {
                    writer.WriteLine($"{EmitExpression(writer, increment, function, enumNames, ref tempIndex, diagnostics)};");
                }
                writer.WriteLine("continue;");
                break;
            case MirYieldStatement { Expression: null }:
                writer.WriteLine("yield break;");
                break;
            case MirYieldStatement yield:
                string yielded = EmitExpression(writer, yield.Expression!, function, enumNames, ref tempIndex, diagnostics);
                writer.WriteLine(yield.IsDelegating ? $"foreach (var __cope_delegated in {yielded}) yield return __cope_delegated;" : $"yield return {yielded};");
                break;
            default: diagnostics.Add(new CSharpDiagnostic("COPE-CS-0001", $"Unsupported MIR statement: {statement.GetType().Name}")); break;
        }
    }

    private static void EmitCSharpBlock(CSharpTextWriter writer, MirCSharpBlockStatement block, string? sourcePath)
    {
        writer.WriteLine("// Copeland inline C# block");
        if (!string.IsNullOrWhiteSpace(sourcePath))
        {
            writer.WriteLine($"#line {block.SourceLine} \"{sourcePath.Replace("\\", "\\\\", StringComparison.Ordinal)}\"");
        }
        using var reader = new StringReader(block.BodyText.Replace("\r\n", "\n", StringComparison.Ordinal));
        while (reader.ReadLine() is { } line)
        {
            writer.WriteLine(line);
        }
        if (!string.IsNullOrWhiteSpace(sourcePath)) writer.WriteLine("#line default");
    }

    private static void EmitWhileStatement(
        CSharpTextWriter writer,
        MirWhileStatement loop,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        if (!ExpressionRequiresStatements(loop.Condition))
        {
            writer.WriteLine($"while ({EmitExpression(writer, loop.Condition, function, enumNames, ref tempIndex, diagnostics)})");
            EmitStatementBlock(writer, loop.BodyStatements, function, enumNames, ref tempIndex, diagnostics);
            return;
        }

        writer.WriteLine("while (true)");
        writer.WriteLine("{");
        writer.Indent();
        string condition = EmitExpression(writer, loop.Condition, function, enumNames, ref tempIndex, diagnostics);
        writer.WriteLine($"if (!({condition}))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("break;");
        writer.Unindent();
        writer.WriteLine("}");
        EmitLoopBody(writer, loop.BodyStatements, null, function, enumNames, ref tempIndex, diagnostics);
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitForStatement(
        CSharpTextWriter writer,
        MirForStatement loop,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        writer.WriteLine("{");
        writer.Indent();
        if (loop.Initializer is not null)
        {
            EmitStatement(writer, loop.Initializer, function, enumNames, ref tempIndex, diagnostics);
        }

        bool requiresStaging = (loop.Condition is not null && ExpressionRequiresStatements(loop.Condition))
            || (loop.Increment is not null && ExpressionRequiresStatements(loop.Increment));
        if (!requiresStaging)
        {
            string condition = loop.Condition is null
                ? string.Empty
                : EmitExpression(writer, loop.Condition, function, enumNames, ref tempIndex, diagnostics);
            string increment = loop.Increment is null
                ? string.Empty
                : EmitExpression(writer, loop.Increment, function, enumNames, ref tempIndex, diagnostics);
            writer.WriteLine($"for (; {condition}; {increment})");
            EmitLoopBodyBlock(writer, loop.BodyStatements, null, function, enumNames, ref tempIndex, diagnostics);
        }
        else
        {
            writer.WriteLine("while (true)");
            writer.WriteLine("{");
            writer.Indent();
            if (loop.Condition is not null)
            {
                string condition = EmitExpression(writer, loop.Condition, function, enumNames, ref tempIndex, diagnostics);
                writer.WriteLine($"if (!({condition}))");
                writer.WriteLine("{");
                writer.Indent();
                writer.WriteLine("break;");
                writer.Unindent();
                writer.WriteLine("}");
            }
            EmitLoopBody(writer, loop.BodyStatements, loop.Increment, function, enumNames, ref tempIndex, diagnostics);
            if (loop.Increment is not null)
            {
                writer.WriteLine($"{EmitExpression(writer, loop.Increment, function, enumNames, ref tempIndex, diagnostics)};");
            }
            writer.Unindent();
            writer.WriteLine("}");
        }
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitStatementBlock(
        CSharpTextWriter writer,
        IReadOnlyList<MirStatement> statements,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        writer.WriteLine("{");
        writer.Indent();
        foreach (MirStatement nested in statements)
        {
            EmitStatement(writer, nested, function, enumNames, ref tempIndex, diagnostics);
        }
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitLoopBodyBlock(
        CSharpTextWriter writer,
        IReadOnlyList<MirStatement> statements,
        MirExpression? continueIncrement,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        writer.WriteLine("{");
        writer.Indent();
        EmitLoopBody(writer, statements, continueIncrement, function, enumNames, ref tempIndex, diagnostics);
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static void EmitLoopBody(
        CSharpTextWriter writer,
        IReadOnlyList<MirStatement> statements,
        MirExpression? continueIncrement,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        CSharpEmissionState state = CurrentEmissionState.Value
            ?? throw new InvalidOperationException("C# loop emission requires function emission state.");
        state.ContinueIncrements.Push(continueIncrement);
        try
        {
            foreach (MirStatement nested in statements)
            {
                EmitStatement(writer, nested, function, enumNames, ref tempIndex, diagnostics);
            }
        }
        finally
        {
            state.ContinueIncrements.Pop();
        }
    }

    private static string EmitExpression(CSharpTextWriter writer, MirExpression expression, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
        => expression switch
        {
            MirLiteralExpression literal => CSharpLiteralWriter.Write(literal.Value),
            MirTextDocumentExpression document => EmitTextDocument(writer, document, function, enumNames, ref tempIndex, diagnostics),
            MirUnitExpression => "CopeUnit.Value",
            MirVariableExpression variable => CSharpNameMangler.Mangle(variable.Name),
            MirAssignmentExpression assignment => AssignmentText(assignment, CSharpNameMangler.Mangle(assignment.Name), EmitExpression(writer, assignment.Expression, function, enumNames, ref tempIndex, diagnostics)),
            MirUnaryExpression unary => UnaryText(unary, ParenthesizeAssignmentOperand(unary.Operand, EmitExpression(writer, unary.Operand, function, enumNames, ref tempIndex, diagnostics))),
            MirBinaryExpression binary => EmitBinary(writer, binary, function, enumNames, ref tempIndex, diagnostics),
            MirNumericConversionExpression conversion => EmitNumericConversion(writer, conversion, function, enumNames, ref tempIndex, diagnostics),
            MirCallExpression call => EmitCall(writer, call, function, enumNames, ref tempIndex, diagnostics),
            MirClrInvocationExpression invocation => EmitClrInvocation(writer, invocation, function, enumNames, ref tempIndex, diagnostics),
            MirClrPropertyAccessExpression property => EmitClrProperty(writer, property, function, enumNames, ref tempIndex, diagnostics),
            MirFunctionReferenceExpression reference => $"({MapType(reference.CallableType)}){CSharpNameMangler.Mangle(reference.FunctionName)}",
            MirCallableConstructionExpression construction => EmitCallableConstruction(writer, construction, function, enumNames, ref tempIndex, diagnostics),
            MirInvokeExpression invoke => EmitInvokeExpression(writer, invoke, function, enumNames, ref tempIndex, diagnostics),
            MirArrayExpression array => EmitArrayInitializer(writer, array, function, enumNames, ref tempIndex, diagnostics),
            MirArrayLengthExpression length => $"{ParenthesizeAssignmentOperand(length.Receiver, EmitExpression(writer, length.Receiver, function, enumNames, ref tempIndex, diagnostics))}.Length",
            MirArrayElementAccessExpression access => $"CopeArray.Get({EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}, {EmitExpression(writer, access.Index, function, enumNames, ref tempIndex, diagnostics)})",
            MirArrayIterableExpression iterable => EmitExpression(writer, iterable.Receiver, function, enumNames, ref tempIndex, diagnostics),
            MirMutableArrayConstructionExpression construction => $"CopeArray.Create<{MapType(construction.MutableArrayType.ElementType)}>({EmitExpression(writer, construction.Length, function, enumNames, ref tempIndex, diagnostics)})",
            MirMutableArrayLengthExpression length => $"{ParenthesizeAssignmentOperand(length.Receiver, EmitExpression(writer, length.Receiver, function, enumNames, ref tempIndex, diagnostics))}.Length",
            MirMutableArrayElementAccessExpression access => $"CopeArray.Get({EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}, {EmitExpression(writer, access.Index, function, enumNames, ref tempIndex, diagnostics)})",
            MirMutableArrayElementAssignmentExpression assignment => $"CopeArray.Set({EmitExpression(writer, assignment.Receiver, function, enumNames, ref tempIndex, diagnostics)}, {EmitExpression(writer, assignment.Index, function, enumNames, ref tempIndex, diagnostics)}, {EmitExpression(writer, assignment.Value, function, enumNames, ref tempIndex, diagnostics)})",
            MirMutableArrayIterableExpression iterable => EmitExpression(writer, iterable.Receiver, function, enumNames, ref tempIndex, diagnostics),
            MirMutableArrayFreezeExpression freeze => $"({MapType(freeze.ArrayType)}){EmitExpression(writer, freeze.Receiver, function, enumNames, ref tempIndex, diagnostics)}.Clone()",
            MirBatchExpression batch => EmitBatchExpression(writer, batch, function, enumNames, ref tempIndex, diagnostics),
            MirRecordConstructionExpression construction => EmitRecordConstruction(writer, construction, function, enumNames, ref tempIndex, diagnostics),
            MirRecordFieldAccessExpression access => EmitRecordFieldAccess(writer, access, function, enumNames, ref tempIndex, diagnostics),
            MirTableWithExpression withExpression => EmitTableWith(writer, withExpression, function, enumNames, ref tempIndex, diagnostics),
            MirRecordWithExpression withExpression => EmitRecordWith(writer, withExpression, function, enumNames, ref tempIndex, diagnostics),
            MirTableReferenceExpression reference => TableSingletonName(reference.TableId),
            MirTableColumnAccessExpression access => $"{EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}.{TableColumnPropertyName(access.ColumnId)}",
            MirTableRowAccessExpression access => $"{EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}.GetRow({EmitExpression(writer, access.Index, function, enumNames, ref tempIndex, diagnostics)})",
            MirColumnElementAccessExpression access => $"{EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}.Get({EmitExpression(writer, access.Index, function, enumNames, ref tempIndex, diagnostics)})",
            MirTableRowFieldAccessExpression access => $"{EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics)}.{TableRowFieldName(access.FieldId)}",
            MirTableRowsExpression rows => EmitExpression(writer, rows.Table, function, enumNames, ref tempIndex, diagnostics),
            MirTableWhereExpression where => EmitExpression(writer, where.Source, function, enumNames, ref tempIndex, diagnostics),
            MirTableSelectExpression select => EmitTableSelect(writer, select, function, enumNames, ref tempIndex, diagnostics),
            MirTableSummaryExpression summary => EmitTableSummary(writer, summary, function, enumNames, ref tempIndex, diagnostics),
            MirTableRecalculationExpression recalculation => EmitTableRecalculation(writer, recalculation, function, enumNames, ref tempIndex, diagnostics),
            MirTableAggregateExpression aggregate => EmitTableAggregate(writer, aggregate, function, enumNames, ref tempIndex, diagnostics),
            MirEnumValueExpression value => value.Arguments.Count == 0
                ? $"{CSharpNameMangler.Mangle(value.EnumName)}.{CSharpNameMangler.Mangle(value.CaseName)}.__Singleton"
                : $"new {CSharpNameMangler.Mangle(value.EnumName)}.{CSharpNameMangler.Mangle(value.CaseName)}({string.Join(", ", EmitArguments(value.Arguments, writer, function, enumNames, ref tempIndex, diagnostics))})",
            MirMatchExpression match => EmitEnumMatch(writer, match, function, enumNames, ref tempIndex, diagnostics),
            MirIfExpression conditional => EmitIfExpression(writer, conditional, function, enumNames, ref tempIndex, diagnostics),
            MirTsonEncodeExpression encode => $"{TsonEncodeMethodName(encode.PlanId)}({EmitExpression(writer, encode.Operand, function, enumNames, ref tempIndex, diagnostics)})",
            MirOkExpression ok => $"CopeResult<{MapResultComponentType(((MirResultType)ok.Type).SuccessType)}, {MapType(((MirResultType)ok.Type).ErrorType)}>.Ok({EmitExpression(writer, ok.Payload, function, enumNames, ref tempIndex, diagnostics)})",
            MirErrExpression err => $"CopeResult<{MapResultComponentType(((MirResultType)err.Type).SuccessType)}, {MapType(((MirResultType)err.Type).ErrorType)}>.Err({EmitExpression(writer, err.Payload, function, enumNames, ref tempIndex, diagnostics)})",
            MirResultMatchExpression match => EmitResultMatch(writer, match, function, enumNames, ref tempIndex, diagnostics),
            MirPropagateExpression propagate => EmitPropagation(writer, propagate, function, enumNames, ref tempIndex, diagnostics),
            MirUnwrapExpression unwrap => EmitUnwrap(writer, unwrap, function, enumNames, ref tempIndex, diagnostics),
            MirTryExpression tryExpression => EmitTryExcept(writer, tryExpression, function, enumNames, ref tempIndex, diagnostics),
            _ => UnsupportedExpression(expression, diagnostics)
        };

    private static string UnaryText(MirUnaryExpression unary, string operand)
    {
        string value = $"({unary.Operator}{operand})";
        return unary.Type.Identifier == "int" && unary.Operator == "-" ? $"unchecked({value})" : value;
    }

    private static string AssignmentText(MirAssignmentExpression assignment, string target, string value)
    {
        if (!assignment.ReturnsPreviousValue) return target + " = " + value;
        UsesIntegerRuntime.Value = true;
        return $"__cope_AssignPrevious(ref {target}, {value})";
    }

    private static string BinaryText(MirBinaryExpression binary, string left, string right, bool flow = false)
    {
        string expression = $"({left} {binary.Operator} {right})";
        if (binary.Type.Identifier != "int") return expression;
        if (binary.Operator is "/" or "%")
        {
            UsesIntegerRuntime.Value = true;
            string operation = binary.Operator == "/" ? "Divide" : "Remainder";
            string owner = flow ? ModuleClassName + "." : string.Empty;
            return $"{owner}__cope_int_{operation}({left}, {right})";
        }
        return binary.Operator is "+" or "-" or "*" ? $"unchecked({expression})" : expression;
    }

    private static string? NativeCallName(MirCallExpression call)
    {
        if (call.NativeOperation is null) return null;
        UsesNativeStrings.Value = true;
        return "__cope_native_" + call.NativeOperation.Value;
    }

    private static string EmitCall(
        CSharpTextWriter writer,
        MirCallExpression call,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string owner = function.Name == "<flow>" ? ModuleClassName + "." : string.Empty;
        string functionName = NativeCallName(call) ?? CSharpNameMangler.Mangle(call.FunctionName);
        string arguments = string.Join(", ", EmitArguments(
            call.Arguments,
            writer,
            function,
            enumNames,
            ref tempIndex,
            diagnostics));
        return owner + functionName + "(" + arguments + ")";
    }

    private static string EmitInvokeExpression(
        CSharpTextWriter writer,
        MirInvokeExpression invoke,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string callee = EmitExpression(writer, invoke.Callee, function, enumNames, ref tempIndex, diagnostics);
        string arguments = string.Join(", ", EmitArguments(invoke.Arguments, writer, function, enumNames, ref tempIndex, diagnostics));
        return invoke.Callee is MirFunctionReferenceExpression or MirCallableConstructionExpression
            ? $"({callee})({arguments})"
            : $"{ParenthesizeAssignmentOperand(invoke.Callee, callee)}({arguments})";
    }

    private static string EmitTableSelect(
        CSharpTextWriter writer,
        MirTableSelectExpression select,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        (MirExpression table, IReadOnlyList<MirExpression> predicates) = UnwrapTableSelection(select.Source);
        int id = tempIndex++;
        string tableName = "__cope_table_" + id;
        string outputName = "__cope_table_output_" + id;
        string indexName = "__cope_table_index_" + id;
        string rowName = "__cope_table_row_" + id;
        string outputType = MapType(select.ArrayType.ElementType);
        string rowType = TableRowTypeName(select.TableId.Value + ".row");
        string tableExpression = EmitExpression(writer, table, function, enumNames, ref tempIndex, diagnostics);

        writer.WriteLine($"var {tableName} = {tableExpression};");
        writer.WriteLine($"var {outputName} = new global::System.Collections.Generic.List<{outputType}>();");
        writer.WriteLine($"for (int {indexName} = 0; {indexName} < {tableName}.Count; {indexName}++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"var {rowName} = new {rowType}({tableName}, {indexName});");
        foreach (MirExpression predicate in predicates)
        {
            var invoke = new MirInvokeExpression(
                predicate,
                [new MirVariableExpression(rowName, new MirTableRowType(select.TableId.Value + ".row", string.Empty))],
                new MirNamedType("boolean"));
            string condition = EmitExpression(writer, invoke, function, enumNames, ref tempIndex, diagnostics);
            writer.WriteLine($"if (!{condition}) continue;");
        }
        var project = new MirInvokeExpression(
            select.Projector,
            [new MirVariableExpression(rowName, new MirTableRowType(select.TableId.Value + ".row", string.Empty))],
            select.ArrayType.ElementType);
        writer.WriteLine($"{outputName}.Add({EmitExpression(writer, project, function, enumNames, ref tempIndex, diagnostics)});");
        writer.Unindent();
        writer.WriteLine("}");
        return outputName + ".ToArray()";
    }

    private static void EmitTableForOf(
        CSharpTextWriter writer,
        MirForOfStatement loop,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        (MirExpression table, IReadOnlyList<MirExpression> predicates) = UnwrapTableSelection(loop.Iterable);
        int id = tempIndex++;
        string tableName = "__cope_table_" + id;
        string indexName = "__cope_table_index_" + id;
        string rowName = CSharpNameMangler.Mangle(loop.Local.Name);
        string rowType = TableRowTypeName(((MirTableRowType)loop.Local.Type).RowTypeId);
        writer.WriteLine($"var {tableName} = {EmitExpression(writer, table, function, enumNames, ref tempIndex, diagnostics)};");
        writer.WriteLine($"for (int {indexName} = 0; {indexName} < {tableName}.Count; {indexName}++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"{rowType} {rowName} = new {rowType}({tableName}, {indexName});");
        foreach (MirExpression predicate in predicates)
        {
            var invoke = new MirInvokeExpression(predicate, [new MirVariableExpression(rowName, loop.Local.Type)], new MirNamedType("boolean"));
            writer.WriteLine($"if (!{EmitExpression(writer, invoke, function, enumNames, ref tempIndex, diagnostics)}) continue;");
        }
        foreach (MirStatement statement in loop.BodyStatements)
        {
            EmitStatement(writer, statement, function, enumNames, ref tempIndex, diagnostics);
        }
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static string EmitTableAggregate(
        CSharpTextWriter writer,
        MirTableAggregateExpression aggregate,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        int id = tempIndex++;
        string column = "__cope_column_" + id;
        string index = "__cope_column_index_" + id;
        string receiver = EmitExpression(writer, aggregate.Receiver, function, enumNames, ref tempIndex, diagnostics);
        writer.WriteLine($"var {column} = {receiver};");
        if (aggregate.Kind == MirTableAggregateKind.Count)
        {
            return $"{column}.Count";
        }

        string valueType = MapType(aggregate.Type);
        string value = "__cope_column_value_" + id;
        string result = "__cope_column_result_" + id;
        string initializer = aggregate.Kind is MirTableAggregateKind.Sum or MirTableAggregateKind.Average
            ? "default"
            : $"{column}.Get(0).Value";
        writer.WriteLine($"{valueType} {result} = {initializer};");
        int start = (aggregate.Kind is MirTableAggregateKind.Min or MirTableAggregateKind.Max) ? 1 : 0;
        writer.WriteLine($"for (int {index} = {start}; {index} < {column}.Count; {index}++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"{valueType} {value} = {column}.Get({index}).Value;");
        switch (aggregate.Kind)
        {
            case MirTableAggregateKind.Sum:
            case MirTableAggregateKind.Average:
                writer.WriteLine($"{result} += {value};");
                break;
            case MirTableAggregateKind.Min:
                writer.WriteLine($"if ({value} < {result}) {result} = {value};");
                break;
            case MirTableAggregateKind.Max:
                writer.WriteLine($"if ({value} > {result}) {result} = {value};");
                break;
        }
        writer.Unindent();
        writer.WriteLine("}");
        return aggregate.Kind == MirTableAggregateKind.Average
            ? $"{result} / {column}.Count"
            : result;
    }

    private static (MirExpression Table, IReadOnlyList<MirExpression> Predicates) UnwrapTableSelection(MirExpression source)
    {
        return source switch
        {
            MirTableRowsExpression rows => (rows.Table, []),
            MirTableWhereExpression where => (where.Source, where.Predicates),
            _ => throw new InvalidOperationException($"Unsupported table selection source {source.GetType().Name}."),
        };
    }

    private static string EmitNumericConversion(
        CSharpTextWriter writer,
        MirNumericConversionExpression conversion,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string operand = EmitExpression(writer, conversion.Operand, function, enumNames, ref tempIndex, diagnostics);
        return conversion.Kind switch
        {
            MirNumericConversionKind.StringFrom when conversion.Operand.Type is MirType { Identifier: "boolean" }
                => $"({operand} ? \"true\" : \"false\")",
            MirNumericConversionKind.StringFrom when conversion.Operand.Type is MirType { Identifier: "int" }
                => $"{operand}.ToString(global::System.Globalization.CultureInfo.InvariantCulture)",
            MirNumericConversionKind.StringFrom
                => $"{operand}.ToString(\"R\", global::System.Globalization.CultureInfo.InvariantCulture)",
            MirNumericConversionKind.IntToFloat => $"((double){operand})",
            MirNumericConversionKind.IntFloor => $"checked((int)global::System.Math.Floor({operand}))",
            MirNumericConversionKind.IntCeil => $"checked((int)global::System.Math.Ceiling({operand}))",
            MirNumericConversionKind.IntTruncate => $"checked((int)global::System.Math.Truncate({operand}))",
            MirNumericConversionKind.IntRound => $"checked((int)({operand} < 0.0 ? global::System.Math.Ceiling({operand} - 0.5) : global::System.Math.Floor({operand} + 0.5)))",
            _ => UnsupportedExpression(conversion, diagnostics),
        };
    }

    private static string EmitArrayInitializer(
        CSharpTextWriter writer,
        MirArrayExpression array,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        if (array.Counts is null)
        {
            return $"new {MapType(array.Type)} {{ {string.Join(", ", EmitArguments(array.Elements, writer, function, enumNames, ref tempIndex, diagnostics))} }}";
        }
        string output = "__cope_initializer_" + tempIndex++;
        string offset = output + "_offset";
        writer.WriteLine($"var {output} = {ArrayAllocation(((MirArrayType)array.Type).ElementType, array.Length)};");
        if (array.Length == 0)
        {
            return output;
        }
        writer.WriteLine($"int {offset} = 0;");
        for (int segment = 0; segment < array.Elements.Count; segment++)
        {
            int count = array.Counts[segment];
            if (count == 0)
            {
                continue;
            }
            string turn = "__cope_initializer_turn_" + tempIndex++;
            writer.WriteLine($"for (int {turn} = 0; {turn} < {count}; {turn}++)");
            writer.WriteLine("{");
            writer.Indent();
            string value = EmitExpression(writer, array.Elements[segment], function, enumNames, ref tempIndex, diagnostics);
            writer.WriteLine($"{output}[{offset}++] = {value};");
            writer.Unindent();
            writer.WriteLine("}");
        }
        return output;
    }

    private static string EmitBatchExpression(
        CSharpTextWriter writer,
        MirBatchExpression batch,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        int batchId = tempIndex++;
        string input = "__cope_batch_input_" + batchId;
        string output = "__cope_batch_output_" + batchId;
        writer.WriteLine($"{MapType(batch.Input.Type)} {input} = {EmitExpression(writer, batch.Input, function, enumNames, ref tempIndex, diagnostics)};");
        writer.WriteLine($"{MapType(batch.ArrayType)} {output} = __cope_batch_map({input}, {CSharpNameMangler.Mangle(batch.Item.Name)} =>");
        writer.WriteLine("{");
        writer.Indent();
        foreach (MirStatement statement in batch.Body.PrefixStatements)
        {
            EmitStatement(writer, statement, function, enumNames, ref tempIndex, diagnostics);
        }
        writer.WriteLine($"return {EmitExpression(writer, batch.Body.ValueExpression, function, enumNames, ref tempIndex, diagnostics)};");
        writer.Unindent();
        writer.WriteLine("});");
        return output;
    }

    private static string EmitCallableConstruction(
        CSharpTextWriter writer,
        MirCallableConstructionExpression construction,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string environmentName = CapturedCallableEnvironmentName(construction.CodeFunctionName);
        string captures = string.Join(", ", EmitArguments(construction.Captures, writer, function, enumNames, ref tempIndex, diagnostics));
        return $"({MapType(construction.CallableType)})new {environmentName}({captures}).Invoke";
    }

    private static string CapturedCallableEnvironmentName(string codeFunctionName)
        => "__CopeCapturedCallableEnvironment_" + CSharpNameMangler.Mangle(codeFunctionName);

    private static IEnumerable<MirCallableConstructionExpression> EnumerateCallableConstructions(MirProgram program)
    {
        foreach (MirFunction function in program.Functions)
        {
            foreach (MirStatement statement in function.Body)
            {
                foreach (MirCallableConstructionExpression construction in EnumerateCallableConstructions(statement))
                {
                    yield return construction;
                }
            }
        }
    }

    private static IEnumerable<MirCallableConstructionExpression> EnumerateCallableConstructions(MirStatement statement)
    {
        switch (statement)
        {
            case MirVariableDeclarationStatement declaration:
                return EnumerateCallableConstructions(declaration.Initializer);
            case MirExpressionStatement expression:
                return EnumerateCallableConstructions(expression.Expression);
            case MirReturnStatement { Expression: not null } returned:
                return EnumerateCallableConstructions(returned.Expression);
            case MirIfStatement conditional:
                return EnumerateCallableConstructions(conditional.Condition)
                    .Concat(conditional.ThenStatements.SelectMany(EnumerateCallableConstructions))
                    .Concat(conditional.ElseStatements?.SelectMany(EnumerateCallableConstructions) ?? []);
            case MirWhileStatement loop:
                return EnumerateCallableConstructions(loop.Condition).Concat(loop.BodyStatements.SelectMany(EnumerateCallableConstructions));
            case MirForStatement loop:
                return (loop.Initializer is null ? [] : EnumerateCallableConstructions(loop.Initializer))
                    .Concat(loop.Condition is null ? [] : EnumerateCallableConstructions(loop.Condition))
                    .Concat(loop.Increment is null ? [] : EnumerateCallableConstructions(loop.Increment))
                    .Concat(loop.BodyStatements.SelectMany(EnumerateCallableConstructions));
            default:
                return [];
        }
    }

    private static IEnumerable<MirCallableConstructionExpression> EnumerateCallableConstructions(MirExpression expression)
    {
        IEnumerable<MirCallableConstructionExpression> Children(IEnumerable<MirExpression> expressions)
            => expressions.SelectMany(EnumerateCallableConstructions);

        return expression switch
        {
            MirTableSummaryExpression summary => EnumerateCallableConstructions(summary.Source),
            MirTableRecalculationExpression recalculation => Children(recalculation.Inputs.Select(input => input.Value)),
            MirTableRowsExpression rows => EnumerateCallableConstructions(rows.Table),
            MirTableWhereExpression where => Children(where.Predicates.Prepend(where.Source)),
            MirCallableConstructionExpression construction => [construction, .. Children(construction.Captures)],
            MirInvokeExpression invoke => Children([invoke.Callee, .. invoke.Arguments]),
            MirAssignmentExpression assignment => EnumerateCallableConstructions(assignment.Expression),
            MirUnaryExpression unary => EnumerateCallableConstructions(unary.Operand),
            MirBinaryExpression binary => Children([binary.Left, binary.Right]),
            MirCallExpression call => Children(call.Arguments),
            MirArrayExpression array => Children(array.Elements),
            MirArrayLengthExpression length => EnumerateCallableConstructions(length.Receiver),
            MirArrayElementAccessExpression access => Children([access.Receiver, access.Index]),
            MirTableSelectExpression select => Children([select.Source, select.Projector]),
            MirRecordConstructionExpression record => Children(record.Initializers.Select(initializer => initializer.Value)),
            MirRecordFieldAccessExpression access => EnumerateCallableConstructions(access.Receiver),
            MirTableWithExpression update => Children([update.Source, .. update.Replacements.Select(replacement => (MirExpression)replacement.Value)]),
            MirRecordWithExpression update => Children([update.Source, .. update.Replacements.Select(replacement => replacement.Value)]),
            MirEnumValueExpression value => Children(value.Arguments),
            MirMatchExpression match => Children([match.Scrutinee, .. match.Arms.Select(arm => arm.Expression)]),
            MirResultMatchExpression match => Children([match.Scrutinee, match.OkExpression, match.ErrExpression]),
            MirIfExpression conditional => Children([conditional.Condition, conditional.ThenExpression, conditional.ElseExpression]),
            MirOkExpression ok => EnumerateCallableConstructions(ok.Payload),
            MirErrExpression err => EnumerateCallableConstructions(err.Payload),
            MirPropagateExpression propagate => EnumerateCallableConstructions(propagate.Operand),
            MirUnwrapExpression unwrap => EnumerateCallableConstructions(unwrap.Operand),
            MirTryExpression attempt => attempt.Protected.PrefixStatements.SelectMany(EnumerateCallableConstructions)
                .Concat(EnumerateCallableConstructions(attempt.Protected.ValueExpression))
                .Concat(attempt.Handler.PrefixStatements.SelectMany(EnumerateCallableConstructions))
                .Concat(EnumerateCallableConstructions(attempt.Handler.ValueExpression)),
            _ => [],
        };
    }

    private static string EmitBinary(
        CSharpTextWriter writer,
        MirBinaryExpression binary,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string binaryOperator = binary.Operator switch
        {
            "===" => "==",
            "!==" => "!=",
            _ => binary.Operator,
        };

        if (binaryOperator is "&&" or "||"
            && (ExpressionRequiresStatements(binary.Left) || ExpressionRequiresStatements(binary.Right)))
        {
            return EmitStatementfulLogicalBinary(
                writer,
                binary,
                function,
                enumNames,
                ref tempIndex,
                diagnostics,
                binaryOperator);
        }

        if (!ExpressionRequiresStatements(binary.Left) && !ExpressionRequiresStatements(binary.Right))
        {
            string simpleLeft = ParenthesizeAssignmentOperand(binary.Left, EmitExpression(writer, binary.Left, function, enumNames, ref tempIndex, diagnostics));
            string simpleRight = ParenthesizeAssignmentOperand(binary.Right, EmitExpression(writer, binary.Right, function, enumNames, ref tempIndex, diagnostics));
            return BinaryText(binary, simpleLeft, simpleRight, function.Name == "<flow>");
        }

        string left = ParenthesizeAssignmentOperand(binary.Left, EmitExpression(writer, binary.Left, function, enumNames, ref tempIndex, diagnostics));
        string leftTemporary = $"__cope_operand_{tempIndex++}";
        writer.WriteLine($"var {leftTemporary} = {left};");
        string right = ParenthesizeAssignmentOperand(binary.Right, EmitExpression(writer, binary.Right, function, enumNames, ref tempIndex, diagnostics));
        string rightTemporary = $"__cope_operand_{tempIndex++}";
        writer.WriteLine($"var {rightTemporary} = {right};");
        return BinaryText(binary, leftTemporary, rightTemporary, function.Name == "<flow>");
    }

    private static string EmitStatementfulLogicalBinary(
        CSharpTextWriter writer,
        MirBinaryExpression binary,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics,
        string binaryOperator)
    {
        string left = ParenthesizeAssignmentOperand(binary.Left, EmitExpression(writer, binary.Left, function, enumNames, ref tempIndex, diagnostics));
        string resultTemporary = $"__cope_logical_result_{tempIndex++}";
        writer.WriteLine($"bool {resultTemporary};");
        string branchCondition = binaryOperator == "&&" ? left : $"!({left})";
        writer.WriteLine($"if ({branchCondition})");
        writer.WriteLine("{");
        writer.Indent();
        string right = ParenthesizeAssignmentOperand(binary.Right, EmitExpression(writer, binary.Right, function, enumNames, ref tempIndex, diagnostics));
        writer.WriteLine($"{resultTemporary} = {right};");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("else");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"{resultTemporary} = {(binaryOperator == "&&" ? "false" : "true")};");
        writer.Unindent();
        writer.WriteLine("}");
        return resultTemporary;
    }

    private static string ParenthesizeAssignmentOperand(MirExpression expression, string emitted)
        => expression is MirAssignmentExpression ? $"({emitted})" : emitted;

    private static string EmitIfExpression(
        CSharpTextWriter writer,
        MirIfExpression conditional,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        if (!ExpressionRequiresStatements(conditional.ThenExpression)
            && !ExpressionRequiresStatements(conditional.ElseExpression))
        {
            string condition = EmitExpression(writer, conditional.Condition, function, enumNames, ref tempIndex, diagnostics);
            string thenExpression = EmitExpression(writer, conditional.ThenExpression, function, enumNames, ref tempIndex, diagnostics);
            string elseExpression = EmitExpression(writer, conditional.ElseExpression, function, enumNames, ref tempIndex, diagnostics);
            return $"({condition} ? {thenExpression} : {elseExpression})";
        }

        string conditionValue = EmitExpression(writer, conditional.Condition, function, enumNames, ref tempIndex, diagnostics);
        string resultTemporary = $"__cope_if_result_{tempIndex++}";
        writer.WriteLine($"{MapValueStorageType(conditional.Type)} {resultTemporary};");
        writer.WriteLine($"if ({conditionValue})");
        writer.WriteLine("{");
        writer.Indent();
        string thenValue = EmitExpression(writer, conditional.ThenExpression, function, enumNames, ref tempIndex, diagnostics);
        writer.WriteLine($"{resultTemporary} = {thenValue};");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("else");
        writer.WriteLine("{");
        writer.Indent();
        string elseValue = EmitExpression(writer, conditional.ElseExpression, function, enumNames, ref tempIndex, diagnostics);
        writer.WriteLine($"{resultTemporary} = {elseValue};");
        writer.Unindent();
        writer.WriteLine("}");
        return resultTemporary;
    }

    private static string EmitRecordConstruction(
        CSharpTextWriter writer,
        MirRecordConstructionExpression construction,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        MirRecordDefinition record = GetRecordDefinition(construction.RecordTypeId);
        var valuesByField = new Dictionary<MirRecordFieldId, string>();

        foreach (var initializer in construction.Initializers)
        {
            string value = EmitExpression(writer, initializer.Value, function, enumNames, ref tempIndex, diagnostics);
            string temporary = $"__cope_record_init_{tempIndex++}";
            writer.WriteLine($"var {temporary} = {value};");
            valuesByField.Add(initializer.FieldId, temporary);
        }

        string arguments = string.Join(", ", record.Fields.Select(field => valuesByField[field.Id]));
        return $"new {RecordTypeName(record.Id)}({arguments})";
    }

    private static string EmitRecordFieldAccess(
        CSharpTextWriter writer,
        MirRecordFieldAccessExpression access,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string receiver = EmitExpression(writer, access.Receiver, function, enumNames, ref tempIndex, diagnostics);
        return $"({receiver}).{RecordFieldName(access.FieldId)}";
    }

    private static string EmitTableWith(
        CSharpTextWriter writer,
        MirTableWithExpression withExpression,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        string value = EmitExpression(
            writer,
            withExpression.Source,
            function,
            enumNames,
            ref tempIndex,
            diagnostics);
        foreach (MirTableColumnReplacement replacement in withExpression.Replacements)
        {
            string replacementValue = EmitExpression(
                writer,
                replacement.Value,
                function,
                enumNames,
                ref tempIndex,
                diagnostics);
            value = $"{value}.{TableWithColumnMethodName(replacement.ColumnId)}({replacementValue})";
        }
        return value;
    }

    private static string EmitRecordWith(
        CSharpTextWriter writer,
        MirRecordWithExpression withExpression,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        MirRecordDefinition record = GetRecordDefinition(withExpression.RecordTypeId);
        string sourceValue = EmitExpression(writer, withExpression.Source, function, enumNames, ref tempIndex, diagnostics);
        string sourceTemporary = $"__cope_record_source_{tempIndex++}";
        writer.WriteLine($"var {sourceTemporary} = {sourceValue};");

        var replacementsByField = new Dictionary<MirRecordFieldId, string>();
        foreach (var replacement in withExpression.Replacements)
        {
            string replacementValue = EmitExpression(writer, replacement.Value, function, enumNames, ref tempIndex, diagnostics);
            string replacementTemporary = $"__cope_record_replacement_{tempIndex++}";
            writer.WriteLine($"var {replacementTemporary} = {replacementValue};");
            replacementsByField.Add(replacement.FieldId, replacementTemporary);
        }

        var arguments = new List<string>(record.Fields.Count);
        foreach (var field in record.Fields)
        {
            if (replacementsByField.TryGetValue(field.Id, out string? replacement))
            {
                arguments.Add(replacement);
            }
            else
            {
                arguments.Add($"{sourceTemporary}.{RecordFieldName(field.Id)}");
            }
        }

        return $"new {RecordTypeName(record.Id)}({string.Join(", ", arguments)})";
    }

    private static MirRecordDefinition GetRecordDefinition(MirRecordTypeId id)
    {
        CSharpEmissionState state = CurrentEmissionState.Value
            ?? throw new InvalidOperationException("Record emission requires function-local state.");
        return state.Records[id];
    }

    private static string EmitPropagation(CSharpTextWriter writer, MirPropagateExpression propagation, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        if (propagation.Target is MirPropagationTarget.LexicalExcept lexical)
        {
            var state = CurrentEmissionState.Value;
            if (state is null || !state.Handlers.TryGetValue(lexical.HandlerId, out var handler))
            {
                diagnostics.Add(new CSharpDiagnostic("COPE-CS-0002", $"Lexical except propagation target '{lexical.HandlerId}' is not active."));
                return "default!";
            }

            var temporary = $"__cope_tmp{tempIndex++}";
            writer.WriteLine($"var {temporary} = {EmitExpression(writer, propagation.Operand, function, enumNames, ref tempIndex, diagnostics)};");
            writer.WriteLine($"if (!{temporary}.IsOk)");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"{handler.ErrorTemporary} = {temporary}.Error;");
            writer.WriteLine($"goto {handler.Label};");
            writer.Unindent();
            writer.WriteLine("}");
            return $"{temporary}.Value";
        }

        if (function.ReturnType is not MirResultType functionResult || propagation.Operand.Type is not MirResultType operandResult || !MirTypeFacts.AreEquivalent(functionResult.ErrorType, operandResult.ErrorType))
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-0002", "Function-return propagation requires compatible Result error types.")); return "default!";
        }
        var functionTemporary = $"__cope_tmp{tempIndex++}"; writer.WriteLine($"var {functionTemporary} = {EmitExpression(writer, propagation.Operand, function, enumNames, ref tempIndex, diagnostics)};"); writer.WriteLine($"if (!{functionTemporary}.IsOk)"); writer.WriteLine("{"); writer.Indent(); writer.WriteLine($"return CopeResult<{MapResultComponentType(functionResult.SuccessType)}, {MapType(functionResult.ErrorType)}>.Err({functionTemporary}.Error);"); writer.Unindent(); writer.WriteLine("}"); return $"{functionTemporary}.Value";
    }

    private static string EmitUnwrap(CSharpTextWriter writer, MirUnwrapExpression unwrap, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        if (unwrap.Operand.Type is not MirResultType resultType || !MirTypeFacts.AreEquivalent(unwrap.Type, resultType.SuccessType))
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-0002", "Result unwrap requires a Result operand and its success type."));
            return "default!";
        }

        string temporary = $"__cope_tmp{tempIndex++}";
        writer.WriteLine($"var {temporary} = {EmitExpression(writer, unwrap.Operand, function, enumNames, ref tempIndex, diagnostics)};");
        writer.WriteLine($"if (!{temporary}.IsOk)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"throw new CopeUnwrapPanicException({temporary}.Error);");
        writer.Unindent();
        writer.WriteLine("}");
        return $"{temporary}.Value";
    }

    private static string EmitTryExcept(CSharpTextWriter writer, MirTryExpression tryExpression, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        var state = CurrentEmissionState.Value;
        if (state is null)
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-0002", "Try/except emission requires a function-local emission state."));
            return "default!";
        }

        if (state.Handlers.ContainsKey(tryExpression.HandlerId))
        {
            diagnostics.Add(new CSharpDiagnostic("COPE-CS-0002", $"Duplicate active try handler identity '{tryExpression.HandlerId}'."));
            return "default!";
        }

        var index = state.TryIndex++;
        var suffix = $"h{tryExpression.HandlerId.Value}_{index}";
        var resultTemporary = $"__cope_try_result_{suffix}";
        var errorTemporary = $"__cope_try_error_{suffix}";
        var handlerLabel = $"__cope_try_handler_{suffix}";
        var joinLabel = $"__cope_try_join_{suffix}";

        writer.WriteLine($"{MapValueStorageType(tryExpression.Type)} {resultTemporary};");
        writer.WriteLine($"{MapType(tryExpression.HandledErrorType)} {errorTemporary} = default!;");
        state.Handlers.Add(tryExpression.HandlerId, new HandlerTransfer(errorTemporary, handlerLabel));
        EmitTryValueBlock(writer, tryExpression.Protected, resultTemporary, joinLabel, function, enumNames, ref tempIndex, diagnostics);
        state.Handlers.Remove(tryExpression.HandlerId);
        writer.WriteLine($"{handlerLabel}:");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"var {CSharpNameMangler.Mangle(tryExpression.HandlerBinding.Name)} = {errorTemporary};");
        EmitTryValueBlock(writer, tryExpression.Handler, resultTemporary, joinLabel, function, enumNames, ref tempIndex, diagnostics);
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"{joinLabel}:");
        return resultTemporary;
    }

    private static void EmitTryValueBlock(CSharpTextWriter writer, MirValueBlock block, string resultTemporary, string joinLabel, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        writer.WriteLine("{");
        writer.Indent();
        foreach (var statement in block.PrefixStatements)
        {
            if (statement is MirExpressionStatement expressionStatement)
            {
                writer.WriteLine($"_ = {EmitExpression(writer, expressionStatement.Expression, function, enumNames, ref tempIndex, diagnostics)};");
            }
            else
            {
                EmitStatement(writer, statement, function, enumNames, ref tempIndex, diagnostics);
            }
        }

        writer.WriteLine($"{resultTemporary} = {EmitExpression(writer, block.ValueExpression, function, enumNames, ref tempIndex, diagnostics)};");
        writer.WriteLine($"goto {joinLabel};");
        writer.Unindent();
        writer.WriteLine("}");
    }

    private static string EmitResultMatch(CSharpTextWriter writer, MirResultMatchExpression match, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        var resultTemporary = $"__cope_tmp{tempIndex++}"; var valueTemporary = $"__cope_tmp{tempIndex++}";
        writer.WriteLine($"var {resultTemporary} = {EmitExpression(writer, match.Scrutinee, function, enumNames, ref tempIndex, diagnostics)};"); writer.WriteLine($"{MapType(match.Type)} {valueTemporary};"); writer.WriteLine($"if ({resultTemporary}.IsOk)"); writer.WriteLine("{"); writer.Indent(); writer.WriteLine($"var {CSharpNameMangler.Mangle(match.OkBinding.Name)} = {resultTemporary}.Value;"); writer.WriteLine($"{valueTemporary} = {EmitExpression(writer, match.OkExpression, function, enumNames, ref tempIndex, diagnostics)};"); writer.Unindent(); writer.WriteLine("}"); writer.WriteLine("else"); writer.WriteLine("{"); writer.Indent(); writer.WriteLine($"var {CSharpNameMangler.Mangle(match.ErrBinding.Name)} = {resultTemporary}.Error;"); writer.WriteLine($"{valueTemporary} = {EmitExpression(writer, match.ErrExpression, function, enumNames, ref tempIndex, diagnostics)};"); writer.Unindent(); writer.WriteLine("}"); return valueTemporary;
    }

    private static string EmitEnumMatch(CSharpTextWriter writer, MirMatchExpression match, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        if (match.Scrutinee.Type is not MirType enumType || match.Scrutinee.Type is MirArrayType or MirResultType || !enumNames.Contains(enumType.Identifier)) return UnsupportedExpression(match, diagnostics);
        if (match.Arms.Any(arm => ExpressionRequiresStatements(arm.Expression)))
        {
            return EmitStatementfulEnumMatch(writer, match, function, enumNames, ref tempIndex, diagnostics, enumType);
        }
        var scrutinee = EmitExpression(writer, match.Scrutinee, function, enumNames, ref tempIndex, diagnostics);
        var arms = new List<string>();
        bool requiresTargetCast = match.Type is MirNamedType namedResultType
            && enumNames.Contains(namedResultType.Identifier);
        foreach (var arm in match.Arms)
        {
            var pattern = arm.PayloadBindings.Count == 0 ? $"{CSharpNameMangler.Mangle(enumType.Identifier)}.{CSharpNameMangler.Mangle(arm.CaseName)} _" : $"{CSharpNameMangler.Mangle(enumType.Identifier)}.{CSharpNameMangler.Mangle(arm.CaseName)}({string.Join(", ", arm.PayloadBindings.Select(binding => $"var {CSharpNameMangler.Mangle(binding.Name)}"))})";
            string armExpression = EmitExpression(writer, arm.Expression, function, enumNames, ref tempIndex, diagnostics);
            if (requiresTargetCast)
            {
                armExpression = $"({MapType(match.Type)})({armExpression})";
            }
            arms.Add($"{pattern} => {armExpression}");
        }
        arms.Add("_ => throw new global::System.InvalidOperationException(\"Non-exhaustive match.\")");
        return $"{scrutinee} switch {{ {string.Join(", ", arms)} }}";
    }

    private static string EmitStatementfulEnumMatch(
        CSharpTextWriter writer,
        MirMatchExpression match,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics,
        MirType enumType)
    {
        string scrutineeValue = EmitExpression(writer, match.Scrutinee, function, enumNames, ref tempIndex, diagnostics);
        string scrutineeTemporary = $"__cope_match_scrutinee_{tempIndex++}";
        string resultTemporary = $"__cope_match_result_{tempIndex++}";
        writer.WriteLine($"{MapType(enumType)} {scrutineeTemporary} = {scrutineeValue};");
        writer.WriteLine($"{MapValueStorageType(match.Type)} {resultTemporary};");
        writer.WriteLine($"switch ({scrutineeTemporary})");
        writer.WriteLine("{");
        writer.Indent();

        foreach (var arm in match.Arms)
        {
            string enumName = CSharpNameMangler.Mangle(enumType.Identifier);
            string caseName = CSharpNameMangler.Mangle(arm.CaseName);
            string pattern = arm.PayloadBindings.Count == 0
                ? $"{enumName}.{caseName} _"
                : $"{enumName}.{caseName}({string.Join(", ", arm.PayloadBindings.Select(binding => $"var {CSharpNameMangler.Mangle(binding.Name)}"))})";
            writer.WriteLine($"case {pattern}:");
            writer.WriteLine("{");
            writer.Indent();
            string armValue = EmitExpression(writer, arm.Expression, function, enumNames, ref tempIndex, diagnostics);
            writer.WriteLine($"{resultTemporary} = {armValue};");
            writer.WriteLine("break;");
            writer.Unindent();
            writer.WriteLine("}");
        }

        writer.WriteLine("default:");
        writer.Indent();
        writer.WriteLine("throw new global::System.InvalidOperationException(\"Non-exhaustive match.\");");
        writer.Unindent();
        writer.Unindent();
        writer.WriteLine("}");
        return resultTemporary;
    }

    private static List<string> EmitArguments(IReadOnlyList<MirExpression> expressions, CSharpTextWriter writer, MirFunction function, IReadOnlySet<string> enumNames, ref int tempIndex, List<CSharpDiagnostic> diagnostics)
    {
        var values = new List<string>(expressions.Count);
        bool requiresOrderedStaging = expressions.Any(ExpressionRequiresStatements);
        foreach (var expression in expressions)
        {
            string value = EmitExpression(writer, expression, function, enumNames, ref tempIndex, diagnostics);
            if (!requiresOrderedStaging)
            {
                values.Add(value);
                continue;
            }

            string temporary = $"__cope_argument_{tempIndex++}";
            writer.WriteLine($"var {temporary} = {value};");
            values.Add(temporary);
        }
        return values;
    }

    private static string UnsupportedExpression(MirExpression expression, List<CSharpDiagnostic> diagnostics) { diagnostics.Add(new CSharpDiagnostic("COPE-CS-0001", $"Unsupported MIR expression: {expression.GetType().Name}")); return "default!"; }

    private static void EmitTsonEncodingRuntime(
        CSharpTextWriter writer,
        IReadOnlyList<MirTsonEncodingPlan> plans,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records,
        bool emitTransportDecoders)
    {
        bool needsArrayWriter = plans.Any(plan => CollectTsonArrayPlans(plan).Count > 0);
        EmitTsonWriter(writer, needsArrayWriter);
        foreach (MirTsonEncodingPlan plan in plans)
        {
            EmitTsonEncodingPlan(writer, plan, records);
        }
        if (emitTransportDecoders)
        {
            EmitTsonReader(writer);
            foreach (MirTsonEncodingPlan plan in plans.Where(plan => plan.RootType is MirRecordType && plan.TablePlan is null))
            {
                EmitTsonFlatRecordDecoder(writer, plan, records);
            }
        }
    }

    private static void EmitTsonReader(CSharpTextWriter writer)
    {
        writer.WriteLine("""
            private sealed class __TsonReader
            {
                private readonly string text;
                private int position;
                internal __TsonReader(string value) { text = value; }
                internal bool End => position == text.Length;
                internal bool Expect(string value)
                {
                    if (position > text.Length - value.Length || string.CompareOrdinal(text, position, value, 0, value.Length) != 0) return false;
                    position += value.Length;
                    return true;
                }
                internal void SkipWhitespace()
                {
                    while (position < text.Length && char.IsWhiteSpace(text[position])) position++;
                }
                internal bool TryBoolean(out bool value)
                {
                    if (Expect("true")) { value = true; return true; }
                    if (Expect("false")) { value = false; return true; }
                    value = false;
                    return false;
                }
                internal bool TryNumber(out double value)
                {
                    value = 0;
                    if (!Expect("$number(\"")) return false;
                    int start = position;
                    while (position < text.Length && text[position] != '"') position++;
                    if (position - start != 16 || !Expect("\")")) return false;
                    string hexadecimal = text.Substring(start, 16);
                    if (!ulong.TryParse(hexadecimal, global::System.Globalization.NumberStyles.AllowHexSpecifier, global::System.Globalization.CultureInfo.InvariantCulture, out ulong bits)) return false;
                    value = global::System.BitConverter.Int64BitsToDouble(unchecked((long)bits));
                    return true;
                }
                internal bool TryString(out string value)
                {
                    value = string.Empty;
                    if (position >= text.Length || text[position++] != '"') return false;
                    var builder = new global::System.Text.StringBuilder();
                    while (position < text.Length)
                    {
                        char current = text[position++];
                        if (current == '"') { value = builder.ToString(); return true; }
                        if (current < ' ') return false;
                        if (current != '\\') { builder.Append(current); continue; }
                        if (position >= text.Length) return false;
                        char escape = text[position++];
                        if (escape == '"' || escape == '\\') builder.Append(escape);
                        else if (escape == 'n') builder.Append('\n');
                        else if (escape == 'r') builder.Append('\r');
                        else if (escape == 't') builder.Append('\t');
                        else return false;
                    }
                    return false;
                }
            }
            """);
        writer.WriteLine();
    }

    private static void EmitTsonFlatRecordDecoder(
        CSharpTextWriter writer,
        MirTsonEncodingPlan plan,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        if (plan.RootValuePlan is not MirTsonRecordValuePlan root
            || !records.TryGetValue(root.RecordTypeId, out MirRecordDefinition? record)
            || plan.Definitions.OfType<MirTsonRecordPlan>().SingleOrDefault(candidate => candidate.RecordTypeId == root.RecordTypeId) is not MirTsonRecordPlan recordPlan)
        {
            return;
        }

        writer.WriteLine($"private static {RecordTypeName(record.Id)} {TsonDecodeMethodName(plan.Id)}(string text)");
        writer.WriteLine("{");
        writer.Indent();
        string rootPrefix = "$record." + record.Name + "({\n";
        writer.WriteLine("if (!text.StartsWith(\"const $schema: string = \\\"\", global::System.StringComparison.Ordinal)) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at schema.\");");
        writer.WriteLine($"int rootPosition = text.IndexOf({CSharpLiteralWriter.Write(rootPrefix)}, global::System.StringComparison.Ordinal);");
        writer.WriteLine("if (rootPosition < 0) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at record prefix.\");");
        writer.WriteLine("var reader = new __TsonReader(text.Substring(rootPosition));");
        writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write(rootPrefix)})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at record prefix.\");");
        var valuesByFieldId = new Dictionary<MirRecordFieldId, string>();
        int temporaryIndex = 0;
        for (int index = 0; index < recordPlan.Fields.Count; index++)
        {
            MirTsonRecordFieldPlan fieldPlan = recordPlan.Fields[index];
            MirRecordFieldDefinition field = record.Fields.Single(candidate => candidate.Id == fieldPlan.FieldId);
            writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write("    \"" + fieldPlan.Name + "\": ")})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at field label {fieldPlan.Name}.\");");
            string variable = EmitTsonDecoderValue(writer, plan, fieldPlan.ValuePlan, field.Type, records, indentation: 1, ref temporaryIndex);
            writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write(",\n")})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at field separator.\");");
            valuesByFieldId.Add(field.Id, variable);
        }
        writer.WriteLine("if (!reader.Expect(\"})\") || !reader.Expect(\";\\n\") || !reader.End) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at suffix.\");");
        writer.WriteLine($"return new {RecordTypeName(record.Id)}({string.Join(", ", record.Fields.Select(field => valuesByFieldId[field.Id]))});");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static string EmitTsonDecoderValue(
        CSharpTextWriter writer,
        MirTsonEncodingPlan plan,
        MirTsonValuePlan valuePlan,
        MirType type,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records,
        int indentation,
        ref int temporaryIndex)
    {
        string variable = "field" + temporaryIndex++;
        switch (valuePlan)
        {
            case MirTsonBooleanPlan:
                writer.WriteLine($"if (!reader.TryBoolean(out bool {variable})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at boolean value.\");");
                return variable;
            case MirTsonNumberPlan:
                writer.WriteLine($"if (!reader.TryNumber(out double {variable})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at number value.\");");
                return variable;
            case MirTsonStringPlan:
                writer.WriteLine($"if (!reader.TryString(out string {variable})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at string value.\");");
                return variable;
            case MirTsonArrayPlan arrayPlan when type is MirArrayType arrayType:
                string elementType = MapType(arrayType.ElementType);
                string items = "items" + temporaryIndex++;
                writer.WriteLine($"var {items} = new global::System.Collections.Generic.List<{elementType}>();");
                writer.WriteLine("reader.SkipWhitespace();");
                writer.WriteLine("if (!reader.Expect(\"[\")) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at array prefix.\");");
                writer.WriteLine("while (true)");
                writer.WriteLine("{");
                writer.Indent();
                writer.WriteLine("reader.SkipWhitespace();");
                writer.WriteLine("if (reader.Expect(\"]\")) break;");
                string element = EmitTsonDecoderValue(writer, plan, arrayPlan.ElementPlan, arrayType.ElementType, records, indentation + 1, ref temporaryIndex);
                writer.WriteLine($"{items}.Add({element});");
                writer.WriteLine("reader.SkipWhitespace();");
                writer.WriteLine("if (!reader.Expect(\",\")) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at array separator.\");");
                writer.Unindent();
                writer.WriteLine("}");
                writer.WriteLine($"var {variable} = {items}.ToArray();");
                return variable;
            case MirTsonRecordValuePlan recordValue when type is MirRecordType recordType
                && records.TryGetValue(recordValue.RecordTypeId, out MirRecordDefinition? record)
                && plan.Definitions.OfType<MirTsonRecordPlan>().SingleOrDefault(candidate => candidate.RecordTypeId == recordValue.RecordTypeId) is MirTsonRecordPlan recordPlan:
                writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write("$record." + record.Name + "({\n")})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at nested record prefix.\");");
                var values = new Dictionary<MirRecordFieldId, string>();
                for (int index = 0; index < recordPlan.Fields.Count; index++)
                {
                    MirTsonRecordFieldPlan fieldPlan = recordPlan.Fields[index];
                    MirRecordFieldDefinition field = record.Fields.Single(candidate => candidate.Id == fieldPlan.FieldId);
                    string fieldPrefix = new string(' ', 4 * (indentation + 1)) + "\"" + fieldPlan.Name + "\": ";
                    writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write(fieldPrefix)})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at nested field label.\");");
                    values.Add(field.Id, EmitTsonDecoderValue(writer, plan, fieldPlan.ValuePlan, field.Type, records, indentation + 1, ref temporaryIndex));
                    writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write(",\n")})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at nested field separator.\");");
                }
                writer.WriteLine($"if (!reader.Expect({CSharpLiteralWriter.Write(new string(' ', 4 * indentation) + "})")})) throw new global::System.InvalidOperationException(\"Malformed TSON transport payload at nested record suffix.\");");
                writer.WriteLine($"var {variable} = new {RecordTypeName(record.Id)}({string.Join(", ", record.Fields.Select(field => values[field.Id]))});");
                return variable;
            default:
                throw new InvalidOperationException("Transport decoder received an unsupported nested TSON value plan.");
        }
    }

    private static void EmitTsonWriter(CSharpTextWriter writer, bool needsArrayWriter)
    {
        writer.WriteLine("private sealed class __TsonWriter");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("private readonly global::System.Text.StringBuilder _builder = new();");
        writer.WriteLine("private readonly int _maximumBytes;");
        writer.WriteLine("private readonly int _maximumStringCodeUnits;");
        writer.WriteLine("private int _bytes;");
        writer.WriteLine("internal TsonEncodeError? Error { get; private set; }");
        writer.WriteLine();
        writer.WriteLine("internal __TsonWriter(int maximumBytes, int maximumStringCodeUnits)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("_maximumBytes = maximumBytes;");
        writer.WriteLine("_maximumStringCodeUnits = maximumStringCodeUnits;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("internal bool Static(string value) => AppendRaw(value, false);");
        writer.WriteLine();
        writer.WriteLine("internal bool Indent(int level)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return Static(new string(' ', level * 4));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("internal bool String(string value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (value.Length > _maximumStringCodeUnits)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return FailOutputLimit();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("for (int index = 0; index < value.Length; index++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("char character = value[index];");
        writer.WriteLine("if (char.IsHighSurrogate(character))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (index + 1 >= value.Length || !char.IsLowSurrogate(value[index + 1])) return FailInvalidUnicode();");
        writer.WriteLine("index++;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("else if (char.IsLowSurrogate(character)) return FailInvalidUnicode();");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("if (!Static(\"\\\"\")) return false;");
        writer.WriteLine("for (int index = 0; index < value.Length; index++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("char character = value[index];");
        writer.WriteLine("switch (character)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("case '\"': if (!Static(\"\\\\\\\"\")) return false; break;");
        writer.WriteLine("case '\\\\': if (!Static(\"\\\\\\\\\")) return false; break;");
        writer.WriteLine("case '\\b': if (!Static(\"\\\\b\")) return false; break;");
        writer.WriteLine("case '\\f': if (!Static(\"\\\\f\")) return false; break;");
        writer.WriteLine("case '\\n': if (!Static(\"\\\\n\")) return false; break;");
        writer.WriteLine("case '\\r': if (!Static(\"\\\\r\")) return false; break;");
        writer.WriteLine("case '\\t': if (!Static(\"\\\\t\")) return false; break;");
        writer.WriteLine("case '\\u2028': if (!UnicodeEscape(character)) return false; break;");
        writer.WriteLine("case '\\u2029': if (!UnicodeEscape(character)) return false; break;");
        writer.WriteLine("default:");
        writer.Indent();
        writer.WriteLine("if (character < ' ') { if (!UnicodeEscape(character)) return false; }");
        writer.WriteLine("else if (char.IsHighSurrogate(character))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (index + 1 >= value.Length || !char.IsLowSurrogate(value[index + 1])) return FailInvalidUnicode();");
        writer.WriteLine("if (!AppendScalar(character, value[++index])) return false;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("else if (char.IsLowSurrogate(character)) return FailInvalidUnicode();");
        writer.WriteLine("else if (!AppendRaw(character.ToString(), false)) return false;");
        writer.WriteLine("break;");
        writer.Unindent();
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("return Static(\"\\\"\");");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("internal bool Number(double value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("ulong bits = global::System.BitConverter.DoubleToUInt64Bits(value);");
        writer.WriteLine("if ((bits & 0x7FF0000000000000UL) == 0x7FF0000000000000UL && (bits & 0x000FFFFFFFFFFFFFUL) != 0) bits = 0x7FF8000000000000UL;");
        writer.WriteLine("return Static(\"$number(\\\"\" + bits.ToString(\"X16\", global::System.Globalization.CultureInfo.InvariantCulture) + \"\\\")\");");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("internal string Finish() => _builder.ToString();");
        writer.WriteLine();
        writer.WriteLine("private bool UnicodeEscape(char value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("return Static(\"\\\\u\" + ((int)value).ToString(\"X4\", global::System.Globalization.CultureInfo.InvariantCulture));");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("private bool AppendScalar(char high, char low)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (_bytes > _maximumBytes - 4) return FailOutputLimit();");
        writer.WriteLine("_bytes += 4;");
        writer.WriteLine("_builder.Append(high);");
        writer.WriteLine("_builder.Append(low);");
        writer.WriteLine("return true;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("private bool AppendRaw(string value, bool enforceStringLimit)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (enforceStringLimit && value.Length > _maximumStringCodeUnits) return FailOutputLimit();");
        writer.WriteLine("int byteCount = 0;");
        writer.WriteLine("for (int index = 0; index < value.Length; index++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("char character = value[index];");
        writer.WriteLine("if (character <= 0x7F) byteCount += 1;");
        writer.WriteLine("else if (character <= 0x7FF) byteCount += 2;");
        writer.WriteLine("else if (char.IsHighSurrogate(character))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (index + 1 >= value.Length || !char.IsLowSurrogate(value[index + 1])) return FailInvalidUnicode();");
        writer.WriteLine("byteCount += 4;");
        writer.WriteLine("index++;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("else if (char.IsLowSurrogate(character)) return FailInvalidUnicode();");
        writer.WriteLine("else byteCount += 3;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("if (_bytes > _maximumBytes - byteCount) return FailOutputLimit();");
        writer.WriteLine("_bytes += byteCount;");
        writer.WriteLine("_builder.Append(value);");
        writer.WriteLine("return true;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("private bool FailInvalidUnicode()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("Error = new TsonEncodeError.InvalidUnicode();");
        writer.WriteLine("return false;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("private bool FailOutputLimit()");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("Error = new TsonEncodeError.OutputLimitExceeded();");
        writer.WriteLine("return false;");
        writer.Unindent();
        writer.WriteLine("}");
        if (needsArrayWriter)
        {
            writer.WriteLine();
            writer.WriteLine("internal bool OutputLimit() => FailOutputLimit();");
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        writer.WriteLine("private static bool __tson_write_boolean(__TsonWriter writer, bool value, int indentation) => writer.Static(value ? \"true\" : \"false\");");
        writer.WriteLine("private static bool __tson_write_number(__TsonWriter writer, double value, int indentation) => writer.Number(value);");
        writer.WriteLine("private static bool __tson_write_string(__TsonWriter writer, string value, int indentation) => writer.String(value);");
        writer.WriteLine();
    }

    private static void EmitTsonEncodingPlan(
        CSharpTextWriter writer,
        MirTsonEncodingPlan plan,
        IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records)
    {
        IReadOnlyList<MirTsonArrayPlan> arrayPlans = CollectTsonArrayPlans(plan);
        string resultType = $"CopeResult<string, TsonEncodeError>";
        if (plan.TablePlan is not null)
        {
            EmitTsonTableEncodingPlan(writer, plan, arrayPlans, resultType);
        }
        else
        {
        writer.WriteLine($"private static {resultType} {TsonEncodeMethodName(plan.Id)}({MapType(plan.RootType)} value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"var writer = new __TsonWriter({plan.Limits.MaximumUtf8Bytes}, {plan.Limits.MaximumStringCodeUnits});");
        string prefix = MirTsonCanonicalText.BuildDocumentPrefix(plan);
        writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write(prefix)})");
        writer.Indent();
        writer.WriteLine($"|| !{TsonValueWriterName(plan.Id, plan.RootValuePlan, arrayPlans)}(writer, value, 0)");
        writer.WriteLine("|| !writer.Static(\";\\n\"))");
        writer.Unindent();
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"return {resultType}.Ok(writer.Finish());");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
        }

        foreach (MirTsonNominalPlan definition in plan.Definitions)
        {
            switch (definition)
            {
                case MirTsonRecordPlan record:
                    EmitTsonRecordWriter(writer, plan, record, records, arrayPlans);
                    break;
                case MirTsonEnumPlan @enum:
                    EmitTsonEnumWriter(writer, plan, @enum, arrayPlans);
                    break;
            }
        }

        foreach (MirTsonArrayPlan arrayPlan in arrayPlans)
        {
            EmitTsonArrayWriter(writer, plan, arrayPlan, arrayPlans);
        }
    }

    private static void EmitTsonTableEncodingPlan(
        CSharpTextWriter writer,
        MirTsonEncodingPlan plan,
        IReadOnlyList<MirTsonArrayPlan> arrayPlans,
        string resultType)
    {
        MirTsonTablePlan table = plan.TablePlan!;
        writer.WriteLine($"private static {resultType} {TsonEncodeMethodName(plan.Id)}({TableTypeName(table.TableId)} value)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"if (!object.ReferenceEquals(value, {TableSingletonName(table.TableId)})) throw new global::System.InvalidOperationException(\"Copeland C# backend invariant failure.\");");
        for (int index = 0; index < table.Columns.Count; index++)
        {
            MirTsonTableColumnPlan column = table.Columns[index];
            writer.WriteLine($"var column{index} = value.{TableTsonStorageAccessName(column.ColumnId)}();");
            writer.WriteLine($"var length{index} = column{index} is null ? -1 : column{index}.Length;");
            writer.WriteLine($"if (length{index} != {column.ExpectedElementCount}) throw new global::System.InvalidOperationException(\"Copeland C# backend invariant failure.\");");
        }
        writer.WriteLine($"var writer = new __TsonWriter({plan.Limits.MaximumUtf8Bytes}, {plan.Limits.MaximumStringCodeUnits});");
        writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write(MirTsonCanonicalText.BuildDocumentPrefix(plan))}))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
        writer.Unindent();
        writer.WriteLine("}");
        for (int columnIndex = 0; columnIndex < table.Columns.Count; columnIndex++)
        {
            MirTsonTableColumnPlan column = table.Columns[columnIndex];
            writer.WriteLine($"if (length{columnIndex} == 0)");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write(MirTsonCanonicalText.BuildTableColumnPrefix(plan, column))}) || !writer.Static(\"[];\\n\"))");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine("goto " + $"__tson_table_column_done_{columnIndex};");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write(MirTsonCanonicalText.BuildTableColumnPrefix(plan, column))}) || !writer.Static(\"[\\n\"))");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine($"for (var index = 0; index < length{columnIndex}; index++)");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"var cell = column{columnIndex}[index];");
            writer.WriteLine("if (!writer.Indent(2)");
            writer.Indent();
            writer.WriteLine($"|| !{TsonValueWriterName(plan.Id, column.ElementPlan, arrayPlans)}(writer, cell, 2)");
            writer.WriteLine("|| !writer.Static(\",\\n\"))");
            writer.Unindent();
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
            writer.Unindent();
            writer.WriteLine("}");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine("if (!writer.Indent(1) || !writer.Static(\"];\\n\"))");
            writer.WriteLine("{");
            writer.Indent();
            writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
            writer.Unindent();
            writer.WriteLine("}");
            writer.WriteLine($"__tson_table_column_done_{columnIndex}: ;");
        }
        writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write(MirTsonCanonicalText.BuildTableDocumentSuffix(plan))}))");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine($"return {resultType}.Err(writer.Error ?? new TsonEncodeError.OutputLimitExceeded());");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine($"return {resultType}.Ok(writer.Finish());");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitTsonRecordWriter(CSharpTextWriter writer, MirTsonEncodingPlan plan, MirTsonRecordPlan record, IReadOnlyDictionary<MirRecordTypeId, MirRecordDefinition> records, IReadOnlyList<MirTsonArrayPlan> arrayPlans)
    {
        writer.WriteLine($"private static bool {TsonValueWriterName(plan.Id, new MirTsonRecordValuePlan(record.RecordTypeId))}(__TsonWriter writer, {RecordTypeName(record.RecordTypeId)} value, int indentation)");
        writer.WriteLine("{");
        writer.Indent();
        if (record.Fields.Count == 0)
        {
            writer.WriteLine($"return writer.Static({CSharpLiteralWriter.Write($"$record.{record.Name}({{}})")});");
        }
        else
        {
            writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write($"$record.{record.Name}({{\n")}) ) return false;");
            MirRecordDefinition carrier = records[record.RecordTypeId];
            for (int index = 0; index < record.Fields.Count; index++)
            {
                MirTsonRecordFieldPlan field = record.Fields[index];
                MirRecordFieldDefinition carrierField = carrier.Fields[index];
                writer.WriteLine("if (!writer.Indent(indentation + 1)) return false;");
                writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write($"\"{field.Name}\": ")})) return false;");
                writer.WriteLine($"if (!{TsonValueWriterName(plan.Id, field.ValuePlan, arrayPlans)}(writer, value.{RecordFieldName(carrierField.Id)}, indentation + 1)) return false;");
                writer.WriteLine("if (!writer.Static(\",\\n\")) return false;");
            }
            writer.WriteLine("if (!writer.Indent(indentation)) return false;");
            writer.WriteLine("return writer.Static(\"})\");");
        }
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitTsonEnumWriter(CSharpTextWriter writer, MirTsonEncodingPlan plan, MirTsonEnumPlan @enum, IReadOnlyList<MirTsonArrayPlan> arrayPlans)
    {
        string methodName = TsonValueWriterName(plan.Id, new MirTsonEnumValuePlan(@enum.Name));
        string typeName = CSharpNameMangler.Mangle(@enum.Name);
        writer.WriteLine($"private static bool {methodName}(__TsonWriter writer, {typeName} value, int indentation)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("switch (value)");
        writer.WriteLine("{");
        writer.Indent();
        foreach (MirTsonEnumCasePlan @case in @enum.Cases)
        {
            string caseType = $"{typeName}.{CSharpNameMangler.Mangle(@case.Name)}";
            string variable = @case.Payloads.Count == 0 ? "" : " item";
            writer.WriteLine($"case {caseType}{variable}:");
            writer.Indent();
            if (@case.Payloads.Count == 0)
            {
                writer.WriteLine($"return writer.Static({CSharpLiteralWriter.Write($"{@enum.Name}.{@case.Name}")});");
            }
            else
            {
                writer.WriteLine($"if (!writer.Static({CSharpLiteralWriter.Write($"{@enum.Name}.{@case.Name}(\n")})) return false;");
                for (int index = 0; index < @case.Payloads.Count; index++)
                {
                    MirTsonEnumPayloadPlan payload = @case.Payloads[index];
                    writer.WriteLine("if (!writer.Indent(indentation + 1)) return false;");
                    writer.WriteLine($"if (!{TsonValueWriterName(plan.Id, payload.ValuePlan, arrayPlans)}(writer, item.{CSharpNameMangler.Mangle(payload.Name)}, indentation + 1)) return false;");
                    writer.WriteLine(index + 1 < @case.Payloads.Count
                        ? "if (!writer.Static(\",\\n\")) return false;"
                        : "if (!writer.Static(\"\\n\")) return false;");
                }
                writer.WriteLine("if (!writer.Indent(indentation)) return false;");
                writer.WriteLine("return writer.Static(\")\");");
            }
            writer.Unindent();
        }
        writer.WriteLine("default:");
        writer.Indent();
        writer.WriteLine("throw new global::System.InvalidOperationException(\"Copeland C# backend invariant failure.\");");
        writer.Unindent();
        writer.Unindent();
        writer.WriteLine("}");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static void EmitTsonArrayWriter(
        CSharpTextWriter writer,
        MirTsonEncodingPlan plan,
        MirTsonArrayPlan arrayPlan,
        IReadOnlyList<MirTsonArrayPlan> arrayPlans)
    {
        string elementType = TsonValuePlanType(arrayPlan.ElementPlan);
        writer.WriteLine($"private static bool {TsonArrayWriterName(plan.Id, arrayPlan, arrayPlans)}(__TsonWriter writer, {elementType}[] value, int indentation)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("if (value is null) throw new global::System.InvalidOperationException(\"Copeland C# backend invariant failure.\");");
        writer.WriteLine("var array = value;");
        writer.WriteLine("var length = array.Length;");
        writer.WriteLine($"if (length > {plan.Limits.MaximumArrayLength}) return writer.OutputLimit();");
        writer.WriteLine("if (length == 0) return writer.Static(\"[]\");");
        writer.WriteLine("if (!writer.Static(\"[\\n\")) return false;");
        writer.WriteLine("for (var index = 0; index < length; index++)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("var element = array[index];");
        writer.WriteLine("if (!writer.Indent(indentation + 1)) return false;");
        writer.WriteLine($"if (!{TsonValueWriterName(plan.Id, arrayPlan.ElementPlan, arrayPlans)}(writer, element, indentation + 1)) return false;");
        writer.WriteLine("if (!writer.Static(\",\\n\")) return false;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("if (!writer.Indent(indentation)) return false;");
        writer.WriteLine("return writer.Static(\"]\");");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine();
    }

    private static string TsonEncodeMethodName(MirTsonEncodingPlanId id)
        => "__tson_encode_" + EncodeStableIdentity(id.Value);

    private static string TsonDecodeMethodName(MirTsonEncodingPlanId id)
        => "__tson_decode_" + EncodeStableIdentity(id.Value);

    private static string TsonValueWriterName(MirTsonEncodingPlanId id, MirTsonValuePlan valuePlan)
        => valuePlan switch
        {
            MirTsonBooleanPlan => "__tson_write_boolean",
            MirTsonNumberPlan => "__tson_write_number",
            MirTsonStringPlan => "__tson_write_string",
            MirTsonRecordValuePlan record => "__tson_write_" + EncodeStableIdentity(id.Value + "_record_" + record.RecordTypeId.Value),
            MirTsonEnumValuePlan @enum => "__tson_write_" + EncodeStableIdentity(id.Value + "_enum_" + @enum.EnumName),
            _ => throw new InvalidOperationException("Unsupported validated TSON value plan."),
        };

    private static string TsonValueWriterName(MirTsonEncodingPlanId id, MirTsonValuePlan valuePlan, IReadOnlyList<MirTsonArrayPlan> arrayPlans)
        => valuePlan is MirTsonArrayPlan array
            ? TsonArrayWriterName(id, array, arrayPlans)
            : TsonValueWriterName(id, valuePlan);

    private static string TsonArrayWriterName(MirTsonEncodingPlanId id, MirTsonArrayPlan arrayPlan, IReadOnlyList<MirTsonArrayPlan> arrayPlans)
        => "__tson_write_" + EncodeStableIdentity(id.Value + "_array_" + TsonArrayPlanIndex(arrayPlan, arrayPlans));

    private static int TsonArrayPlanIndex(MirTsonArrayPlan arrayPlan, IReadOnlyList<MirTsonArrayPlan> arrayPlans)
    {
        for (int index = 0; index < arrayPlans.Count; index++)
        {
            if (arrayPlans[index].Equals(arrayPlan))
            {
                return index;
            }
        }

        throw new InvalidOperationException("Validated TSON array plan was not collected.");
    }

    private static string TsonValuePlanType(MirTsonValuePlan valuePlan)
        => valuePlan switch
        {
            MirTsonBooleanPlan => "bool",
            MirTsonNumberPlan => "double",
            MirTsonStringPlan => "string",
            MirTsonRecordValuePlan record => RecordTypeName(record.RecordTypeId),
            MirTsonEnumValuePlan @enum => CSharpNameMangler.Mangle(@enum.EnumName),
            MirTsonArrayPlan array => TsonValuePlanType(array.ElementPlan) + "[]",
            _ => throw new InvalidOperationException("Unsupported validated TSON value plan."),
        };

    private static IReadOnlyList<MirTsonArrayPlan> CollectTsonArrayPlans(MirTsonEncodingPlan plan)
    {
        var arrays = new List<MirTsonArrayPlan>();

        void Visit(MirTsonValuePlan valuePlan)
        {
            if (valuePlan is not MirTsonArrayPlan array || arrays.Contains(array))
            {
                return;
            }

            arrays.Add(array);
            Visit(array.ElementPlan);
        }

        Visit(plan.RootValuePlan);
        if (plan.TablePlan is not null)
        {
            foreach (MirTsonTableColumnPlan column in plan.TablePlan.Columns)
            {
                Visit(column.ElementPlan);
            }
        }
        foreach (MirTsonNominalPlan definition in plan.Definitions)
        {
            IEnumerable<MirTsonValuePlan> values = definition switch
            {
                MirTsonRecordPlan record => record.Fields.Select(field => field.ValuePlan),
                MirTsonEnumPlan @enum => @enum.Cases.SelectMany(@case => @case.Payloads.Select(payload => payload.ValuePlan)),
                _ => [],
            };
            foreach (MirTsonValuePlan value in values)
            {
                Visit(value);
            }
        }

        return arrays;
    }
    private static string MapClrType(MirClrType type)
    {
        if (type.TypeArguments.Count == 0) return "global::" + type.MetadataName;
        string definition = type.MetadataName[..type.MetadataName.IndexOf('`')];
        return "global::" + definition + "<" + string.Join(", ", type.TypeArguments.Select(MapType)) + ">";
    }

    private static string MapType(MirType type) => type switch { MirType { Identifier: "int" } => "int", MirType { Identifier: "float" or "number" } => "double", MirType { Identifier: "string" } => "string", MirType { Identifier: "boolean" } => "bool", MirType { Identifier: "void" } => "void", MirType { Identifier: "Document" } => "TextDocument", MirClrType clr => MapClrType(clr), MirArrayType array => MapType(array.ElementType) + "[]", MirMutableArrayType array => MapType(array.ElementType) + "[]", MirResultType result => $"CopeResult<{MapResultComponentType(result.SuccessType)}, {MapType(result.ErrorType)}>", MirAsyncType async => $"CopeAsync<{MapValueStorageType(async.EventualType)}>", MirIterableType iterable => $"global::System.Collections.Generic.IEnumerable<{MapValueStorageType(iterable.ElementType)}>", MirCallableType callable => CallableDelegateName(callable), MirRecordType record => RecordTypeName(record.RecordTypeId), MirTableType table => TableTypeName(table.TableId), MirTableRowType row => TableRowTypeName(row.RowTypeId), MirColumnType column => $"CopeColumn<{MapType(column.ElementType)}>", MirType named => CSharpNameMangler.Mangle(named.Identifier), _ => throw new InvalidOperationException("Unknown structured MIR type.") };

    private static string EmitTextDocument(
        CSharpTextWriter writer,
        MirTextDocumentExpression document,
        MirFunction function,
        IReadOnlySet<string> enumNames,
        ref int tempIndex,
        List<CSharpDiagnostic> diagnostics)
    {
        var slots = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (MirTextValueSlot slot in document.Slots)
        {
            string value = EmitExpression(writer, slot.Expression, function, enumNames, ref tempIndex, diagnostics);
            slots.Add(slot.SlotId, value);
        }
        return "new TextDocument(" + EmitTextNode(document.Root, slots) + ")";
    }

    private static string EmitTextNode(MirTextNode node, IReadOnlyDictionary<string, string> slots)
    {
        string attributes = string.Join(", ", node.Attributes.Select(attribute =>
            "[" + CSharpLiteralWriter.Write(attribute.Name) + "] = " + CSharpLiteralWriter.Write(attribute.Value)));
        string children = string.Join(", ", node.Children.Select(child => EmitTextContent(child, slots)));
        return $"new TextNode({CSharpLiteralWriter.Write(node.Kind)}, new global::System.Collections.ObjectModel.ReadOnlyDictionary<string, string>(new global::System.Collections.Generic.Dictionary<string, string> {{ {attributes} }}), global::System.Array.AsReadOnly(new TextContent[] {{ {children} }}))";
    }

    private static string EmitTextContent(MirTextContent content, IReadOnlyDictionary<string, string> slots) => content switch
    {
        MirTextRun text => $"new TextRun({CSharpLiteralWriter.Write(text.Value)})",
        MirTextSlot slot => $"new EmbeddedTextValue({CSharpLiteralWriter.Write(slot.SlotId)}, {slots[slot.SlotId]})",
        MirTextChild child => $"new TextChild({EmitTextNode(child.Node, slots)})",
        _ => throw new InvalidOperationException($"Unsupported text content '{content.GetType().Name}'."),
    };

    private static void EmitTextDocumentRuntime(CSharpTextWriter writer)
    {
        writer.WriteLine("public sealed record TextDocument(TextNode Root)");
        writer.WriteLine("{");
        writer.Indent();
        writer.WriteLine("public string Kind => Root.Kind;");
        writer.Unindent();
        writer.WriteLine("}");
        writer.WriteLine("public sealed record TextNode(string Kind, global::System.Collections.Generic.IReadOnlyDictionary<string, string> Attributes, global::System.Collections.Generic.IReadOnlyList<TextContent> Children);");
        writer.WriteLine("public abstract record TextContent;");
        writer.WriteLine("public sealed record TextRun(string Value) : TextContent;");
        writer.WriteLine("public sealed record EmbeddedTextValue(string SlotId, string Value) : TextContent;");
        writer.WriteLine("public sealed record TextChild(TextNode Node) : TextContent;");
        writer.WriteLine();
    }
    private static string MapValueStorageType(MirType type) => type is MirNamedType { Identifier: "void" } ? "CopeUnit" : MapType(type);
    private static string MapResultComponentType(MirType type) => type is MirNamedType { Identifier: "void" } ? "CopeUnit" : MapType(type);

    private static bool ProgramUsesResult(MirProgram program) => EnumerateTypes(program).Any(MirTypeFacts.ContainsResult);

    private static bool ProgramUsesUnwrap(MirProgram program)
        => program.Functions.Any(function => function.Body.Any(StatementUsesUnwrap));

    private static bool ProgramUsesBatch(MirProgram program)
        => program.Functions.Any(function => function.Body.Any(StatementUsesBatch));

    private static bool ProgramUsesArrayElementAccess(MirProgram program)
        => program.Functions.Any(function => function.Body.Any(StatementUsesArrayElementAccess));

    private static bool StatementUsesArrayElementAccess(MirStatement statement)
        => statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesArrayElementAccess(declaration.Initializer),
            MirResourceUsingDeclarationStatement declaration => ExpressionUsesArrayElementAccess(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesArrayElementAccess(expression.Expression),
            MirReturnStatement { Expression: not null } returned => ExpressionUsesArrayElementAccess(returned.Expression),
            MirIfStatement conditional => ExpressionUsesArrayElementAccess(conditional.Condition)
                || conditional.ThenStatements.Any(StatementUsesArrayElementAccess)
                || (conditional.ElseStatements?.Any(StatementUsesArrayElementAccess) ?? false),
            MirWhileStatement loop => ExpressionUsesArrayElementAccess(loop.Condition) || loop.BodyStatements.Any(StatementUsesArrayElementAccess),
            MirForStatement loop => (loop.Initializer is not null && StatementUsesArrayElementAccess(loop.Initializer))
                || (loop.Condition is not null && ExpressionUsesArrayElementAccess(loop.Condition))
                || (loop.Increment is not null && ExpressionUsesArrayElementAccess(loop.Increment))
                || loop.BodyStatements.Any(StatementUsesArrayElementAccess),
            MirForOfStatement loop => ExpressionUsesArrayElementAccess(loop.Iterable) || loop.BodyStatements.Any(StatementUsesArrayElementAccess),
            _ => false,
        };

    private static bool ExpressionUsesArrayElementAccess(MirExpression expression)
        => expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesArrayElementAccess(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesArrayElementAccess(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesArrayElementAccess(rows.Table),
            MirTableWhereExpression where => ExpressionUsesArrayElementAccess(where.Source) || where.Predicates.Any(ExpressionUsesArrayElementAccess),
            MirTableSelectExpression select => ExpressionUsesArrayElementAccess(select.Source) || ExpressionUsesArrayElementAccess(select.Projector),
            MirArrayElementAccessExpression => true,
            MirMutableArrayElementAccessExpression => true,
            MirMutableArrayElementAssignmentExpression => true,
            MirMutableArrayConstructionExpression => true,
            MirMutableArrayLengthExpression length => ExpressionUsesArrayElementAccess(length.Receiver),
            MirMutableArrayIterableExpression iterable => ExpressionUsesArrayElementAccess(iterable.Receiver),
            MirMutableArrayFreezeExpression freeze => ExpressionUsesArrayElementAccess(freeze.Receiver),
            MirArrayLengthExpression length => ExpressionUsesArrayElementAccess(length.Receiver),
            MirArrayIterableExpression iterable => ExpressionUsesArrayElementAccess(iterable.Receiver),
            MirAssignmentExpression assignment => ExpressionUsesArrayElementAccess(assignment.Expression),
            MirUnaryExpression unary => ExpressionUsesArrayElementAccess(unary.Operand),
            MirBinaryExpression binary => ExpressionUsesArrayElementAccess(binary.Left) || ExpressionUsesArrayElementAccess(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesArrayElementAccess),
            MirInvokeExpression invoke => ExpressionUsesArrayElementAccess(invoke.Callee) || invoke.Arguments.Any(ExpressionUsesArrayElementAccess),
            MirArrayExpression array => array.Counts is not null || array.Elements.Any(ExpressionUsesArrayElementAccess),
            MirBatchExpression batch => ExpressionUsesArrayElementAccess(batch.Input)
                || batch.Body.PrefixStatements.Any(StatementUsesArrayElementAccess)
                || ExpressionUsesArrayElementAccess(batch.Body.ValueExpression),
            MirRecordConstructionExpression record => record.Initializers.Any(initializer => ExpressionUsesArrayElementAccess(initializer.Value)),
            MirRecordFieldAccessExpression access => ExpressionUsesArrayElementAccess(access.Receiver),
            MirTableWithExpression update => ExpressionUsesArrayElementAccess(update.Source) || update.Replacements.Any(replacement => ExpressionUsesArrayElementAccess(replacement.Value)),
            MirRecordWithExpression update => ExpressionUsesArrayElementAccess(update.Source) || update.Replacements.Any(replacement => ExpressionUsesArrayElementAccess(replacement.Value)),
            MirEnumValueExpression value => value.Arguments.Any(ExpressionUsesArrayElementAccess),
            MirMatchExpression match => ExpressionUsesArrayElementAccess(match.Scrutinee) || match.Arms.Any(arm => ExpressionUsesArrayElementAccess(arm.Expression)),
            MirResultMatchExpression match => ExpressionUsesArrayElementAccess(match.Scrutinee) || ExpressionUsesArrayElementAccess(match.OkExpression) || ExpressionUsesArrayElementAccess(match.ErrExpression),
            MirIfExpression conditional => ExpressionUsesArrayElementAccess(conditional.Condition) || ExpressionUsesArrayElementAccess(conditional.ThenExpression) || ExpressionUsesArrayElementAccess(conditional.ElseExpression),
            _ => false,
        };

    private static bool StatementUsesBatch(MirStatement statement)
        => statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesBatch(declaration.Initializer),
            MirResourceUsingDeclarationStatement declaration => ExpressionUsesBatch(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesBatch(expression.Expression),
            MirReturnStatement { Expression: not null } returned => ExpressionUsesBatch(returned.Expression),
            MirIfStatement conditional => ExpressionUsesBatch(conditional.Condition)
                || conditional.ThenStatements.Any(StatementUsesBatch)
                || (conditional.ElseStatements?.Any(StatementUsesBatch) ?? false),
            MirWhileStatement loop => ExpressionUsesBatch(loop.Condition) || loop.BodyStatements.Any(StatementUsesBatch),
            MirForStatement loop => (loop.Initializer is not null && StatementUsesBatch(loop.Initializer))
                || (loop.Condition is not null && ExpressionUsesBatch(loop.Condition))
                || (loop.Increment is not null && ExpressionUsesBatch(loop.Increment))
                || loop.BodyStatements.Any(StatementUsesBatch),
            _ => false,
        };

    private static bool StatementUsesTableWith(MirStatement statement)
        => statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesTableWith(declaration.Initializer),
            MirResourceUsingDeclarationStatement declaration => ExpressionUsesTableWith(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesTableWith(expression.Expression),
            MirReturnStatement { Expression: not null } returned => ExpressionUsesTableWith(returned.Expression),
            MirIfStatement conditional => ExpressionUsesTableWith(conditional.Condition)
                || conditional.ThenStatements.Any(StatementUsesTableWith)
                || (conditional.ElseStatements?.Any(StatementUsesTableWith) ?? false),
            MirWhileStatement loop => ExpressionUsesTableWith(loop.Condition)
                || loop.BodyStatements.Any(StatementUsesTableWith),
            MirForStatement loop => (loop.Initializer is not null && StatementUsesTableWith(loop.Initializer))
                || (loop.Condition is not null && ExpressionUsesTableWith(loop.Condition))
                || (loop.Increment is not null && ExpressionUsesTableWith(loop.Increment))
                || loop.BodyStatements.Any(StatementUsesTableWith),
            _ => false,
        };

    private static bool ExpressionUsesTableWith(MirExpression expression)
        => expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesTableWith(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesTableWith(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesTableWith(rows.Table),
            MirTableWhereExpression where => ExpressionUsesTableWith(where.Source) || where.Predicates.Any(ExpressionUsesTableWith),
            MirTableSelectExpression select => ExpressionUsesTableWith(select.Source) || ExpressionUsesTableWith(select.Projector),
            MirArrayLengthExpression length => ExpressionUsesTableWith(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionUsesTableWith(access.Receiver) || ExpressionUsesTableWith(access.Index),
            MirTableAggregateExpression aggregate => ExpressionUsesTableWith(aggregate.Receiver),
            MirTableColumnAccessExpression access => ExpressionUsesTableWith(access.Receiver),
            MirTableRowAccessExpression access => ExpressionUsesTableWith(access.Receiver) || ExpressionUsesTableWith(access.Index),
            MirColumnElementAccessExpression access => ExpressionUsesTableWith(access.Receiver) || ExpressionUsesTableWith(access.Index),
            MirTableRowFieldAccessExpression access => ExpressionUsesTableWith(access.Receiver),
            MirTableWithExpression => true,
            MirAssignmentExpression assignment => ExpressionUsesTableWith(assignment.Expression),
            MirUnaryExpression unary => ExpressionUsesTableWith(unary.Operand),
            MirBinaryExpression binary => ExpressionUsesTableWith(binary.Left) || ExpressionUsesTableWith(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesTableWith),
            MirInvokeExpression invoke => ExpressionUsesTableWith(invoke.Callee) || invoke.Arguments.Any(ExpressionUsesTableWith),
            MirArrayExpression array => array.Elements.Any(ExpressionUsesTableWith),
            MirRecordConstructionExpression record => record.Initializers.Any(initializer => ExpressionUsesTableWith(initializer.Value)),
            MirRecordFieldAccessExpression access => ExpressionUsesTableWith(access.Receiver),
            MirRecordWithExpression update => ExpressionUsesTableWith(update.Source)
                || update.Replacements.Any(replacement => ExpressionUsesTableWith(replacement.Value)),
            MirEnumValueExpression value => value.Arguments.Any(ExpressionUsesTableWith),
            MirMatchExpression match => ExpressionUsesTableWith(match.Scrutinee)
                || match.Arms.Any(arm => ExpressionUsesTableWith(arm.Expression)),
            MirResultMatchExpression match => ExpressionUsesTableWith(match.Scrutinee)
                || ExpressionUsesTableWith(match.OkExpression)
                || ExpressionUsesTableWith(match.ErrExpression),
            MirIfExpression conditional => ExpressionUsesTableWith(conditional.Condition)
                || ExpressionUsesTableWith(conditional.ThenExpression)
                || ExpressionUsesTableWith(conditional.ElseExpression),
            MirOkExpression ok => ExpressionUsesTableWith(ok.Payload),
            MirErrExpression err => ExpressionUsesTableWith(err.Payload),
            MirPropagateExpression propagate => ExpressionUsesTableWith(propagate.Operand),
            MirUnwrapExpression unwrap => ExpressionUsesTableWith(unwrap.Operand),
            MirTryExpression attempt => attempt.Protected.PrefixStatements.Any(StatementUsesTableWith)
                || ExpressionUsesTableWith(attempt.Protected.ValueExpression)
                || attempt.Handler.PrefixStatements.Any(StatementUsesTableWith)
                || ExpressionUsesTableWith(attempt.Handler.ValueExpression),
            _ => false,
        };

    private static bool ExpressionUsesBatch(MirExpression expression)
        => expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesBatch(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesBatch(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesBatch(rows.Table),
            MirTableWhereExpression where => ExpressionUsesBatch(where.Source) || where.Predicates.Any(ExpressionUsesBatch),
            MirTableSelectExpression select => ExpressionUsesBatch(select.Source) || ExpressionUsesBatch(select.Projector),
            MirArrayLengthExpression length => ExpressionUsesBatch(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionUsesBatch(access.Receiver) || ExpressionUsesBatch(access.Index),
            MirBatchExpression => true,
            MirAssignmentExpression assignment => ExpressionUsesBatch(assignment.Expression),
            MirUnaryExpression unary => ExpressionUsesBatch(unary.Operand),
            MirBinaryExpression binary => ExpressionUsesBatch(binary.Left) || ExpressionUsesBatch(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesBatch),
            MirInvokeExpression invoke => ExpressionUsesBatch(invoke.Callee) || invoke.Arguments.Any(ExpressionUsesBatch),
            MirArrayExpression array => array.Elements.Any(ExpressionUsesBatch),
            MirRecordConstructionExpression construction => construction.Initializers.Any(initializer => ExpressionUsesBatch(initializer.Value)),
            MirRecordFieldAccessExpression access => ExpressionUsesBatch(access.Receiver),
            MirTableWithExpression update => ExpressionUsesBatch(update.Source) || update.Replacements.Any(replacement => ExpressionUsesBatch(replacement.Value)),
            MirRecordWithExpression update => ExpressionUsesBatch(update.Source) || update.Replacements.Any(replacement => ExpressionUsesBatch(replacement.Value)),
            MirEnumValueExpression value => value.Arguments.Any(ExpressionUsesBatch),
            MirMatchExpression match => ExpressionUsesBatch(match.Scrutinee) || match.Arms.Any(arm => ExpressionUsesBatch(arm.Expression)),
            MirResultMatchExpression match => ExpressionUsesBatch(match.Scrutinee) || ExpressionUsesBatch(match.OkExpression) || ExpressionUsesBatch(match.ErrExpression),
            MirIfExpression conditional => ExpressionUsesBatch(conditional.Condition) || ExpressionUsesBatch(conditional.ThenExpression) || ExpressionUsesBatch(conditional.ElseExpression),
            MirOkExpression ok => ExpressionUsesBatch(ok.Payload),
            MirErrExpression err => ExpressionUsesBatch(err.Payload),
            MirUnwrapExpression unwrap => ExpressionUsesBatch(unwrap.Operand),
            MirTryExpression attempt => attempt.Protected.PrefixStatements.Any(StatementUsesBatch)
                || ExpressionUsesBatch(attempt.Protected.ValueExpression)
                || attempt.Handler.PrefixStatements.Any(StatementUsesBatch)
                || ExpressionUsesBatch(attempt.Handler.ValueExpression),
            _ => false,
        };

    private static bool ProgramUsesTsonTransport(MirProgram program)
        => program.Functions.Any(function => function.Body.Any(StatementUsesTsonTransport));

    private static bool ProgramUsesSystemTextJson(MirProgram program)
        => program.Functions.Any(function => function.Body.Any(StatementUsesSystemTextJson))
            || program.Functions.Any(function => function.IsRemote
                && program.CSharpUsings.Contains("System.Text.Json", StringComparer.Ordinal));

    private static bool StatementUsesSystemTextJson(MirStatement statement)
        => statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesSystemTextJson(declaration.Initializer),
            MirResourceUsingDeclarationStatement declaration => ExpressionUsesSystemTextJson(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesSystemTextJson(expression.Expression),
            MirReturnStatement { Expression: not null } returned => ExpressionUsesSystemTextJson(returned.Expression),
            MirIfStatement conditional => ExpressionUsesSystemTextJson(conditional.Condition) || conditional.ThenStatements.Any(StatementUsesSystemTextJson) || (conditional.ElseStatements?.Any(StatementUsesSystemTextJson) ?? false),
            MirWhileStatement loop => ExpressionUsesSystemTextJson(loop.Condition) || loop.BodyStatements.Any(StatementUsesSystemTextJson),
            MirForStatement loop => (loop.Initializer is not null && StatementUsesSystemTextJson(loop.Initializer)) || (loop.Condition is not null && ExpressionUsesSystemTextJson(loop.Condition)) || (loop.Increment is not null && ExpressionUsesSystemTextJson(loop.Increment)) || loop.BodyStatements.Any(StatementUsesSystemTextJson),
            _ => false,
        };

    private static bool ExpressionUsesSystemTextJson(MirExpression expression)
        => expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesSystemTextJson(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesSystemTextJson(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesSystemTextJson(rows.Table),
            MirTableWhereExpression where => ExpressionUsesSystemTextJson(where.Source) || where.Predicates.Any(ExpressionUsesSystemTextJson),
            MirTableSelectExpression select => ExpressionUsesSystemTextJson(select.Source) || ExpressionUsesSystemTextJson(select.Projector),
            MirArrayLengthExpression length => ExpressionUsesSystemTextJson(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionUsesSystemTextJson(access.Receiver) || ExpressionUsesSystemTextJson(access.Index),
            MirClrInvocationExpression { Member.DeclaringType: "System.Text.Json.JsonSerializer" } => true,
            MirClrInvocationExpression invocation => invocation.Arguments.Any(ExpressionUsesSystemTextJson) || (invocation.Receiver is not null && ExpressionUsesSystemTextJson(invocation.Receiver)),
            MirClrPropertyAccessExpression property => property.Receiver is not null && ExpressionUsesSystemTextJson(property.Receiver),
            MirBinaryExpression binary => ExpressionUsesSystemTextJson(binary.Left) || ExpressionUsesSystemTextJson(binary.Right),
            MirUnaryExpression unary => ExpressionUsesSystemTextJson(unary.Operand),
            MirAssignmentExpression assignment => ExpressionUsesSystemTextJson(assignment.Expression),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesSystemTextJson),
            MirArrayExpression array => array.Elements.Any(ExpressionUsesSystemTextJson),
            MirRecordConstructionExpression construction => construction.Initializers.Any(initializer => ExpressionUsesSystemTextJson(initializer.Value)),
            _ => false,
        };

    private static bool StatementUsesTsonTransport(MirStatement statement)
        => statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesTsonTransport(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesTsonTransport(expression.Expression),
            MirReturnStatement { Expression: not null } returned => ExpressionUsesTsonTransport(returned.Expression),
            MirIfStatement conditional => ExpressionUsesTsonTransport(conditional.Condition)
                || conditional.ThenStatements.Any(StatementUsesTsonTransport)
                || (conditional.ElseStatements?.Any(StatementUsesTsonTransport) ?? false),
            MirWhileStatement loop => ExpressionUsesTsonTransport(loop.Condition) || loop.BodyStatements.Any(StatementUsesTsonTransport),
            MirForStatement loop => (loop.Initializer is not null && StatementUsesTsonTransport(loop.Initializer))
                || (loop.Condition is not null && ExpressionUsesTsonTransport(loop.Condition))
                || (loop.Increment is not null && ExpressionUsesTsonTransport(loop.Increment))
                || loop.BodyStatements.Any(StatementUsesTsonTransport),
            _ => false,
        };

    private static bool ExpressionUsesTsonTransport(MirExpression expression)
        => expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesTsonTransport(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesTsonTransport(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesTsonTransport(rows.Table),
            MirTableWhereExpression where => ExpressionUsesTsonTransport(where.Source) || where.Predicates.Any(ExpressionUsesTsonTransport),
            MirTableSelectExpression select => ExpressionUsesTsonTransport(select.Source) || ExpressionUsesTsonTransport(select.Projector),
            MirArrayLengthExpression length => ExpressionUsesTsonTransport(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionUsesTsonTransport(access.Receiver) || ExpressionUsesTsonTransport(access.Index),
            MirTsonTransportExpression or MirNpmCallExpression => true,
            MirAwaitExpression awaited => ExpressionUsesTsonTransport(awaited.Operand),
            MirAssignmentExpression assignment => ExpressionUsesTsonTransport(assignment.Expression),
            MirUnaryExpression unary => ExpressionUsesTsonTransport(unary.Operand),
            MirBinaryExpression binary => ExpressionUsesTsonTransport(binary.Left) || ExpressionUsesTsonTransport(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesTsonTransport),
            MirRecordConstructionExpression record => record.Initializers.Any(value => ExpressionUsesTsonTransport(value.Value)),
            MirRecordFieldAccessExpression access => ExpressionUsesTsonTransport(access.Receiver),
            MirTsonEncodeExpression encode => ExpressionUsesTsonTransport(encode.Operand),
            _ => false,
        };

    private static bool StatementUsesUnwrap(MirStatement statement)
    {
        return statement switch
        {
            MirVariableDeclarationStatement declaration => ExpressionUsesUnwrap(declaration.Initializer),
            MirExpressionStatement expression => ExpressionUsesUnwrap(expression.Expression),
            MirReturnStatement { Expression: not null } returnStatement => ExpressionUsesUnwrap(returnStatement.Expression),
            MirIfStatement conditional =>
                ExpressionUsesUnwrap(conditional.Condition)
                || conditional.ThenStatements.Any(StatementUsesUnwrap)
                || (conditional.ElseStatements?.Any(StatementUsesUnwrap) ?? false),
            MirWhileStatement loop =>
                ExpressionUsesUnwrap(loop.Condition)
                || loop.BodyStatements.Any(StatementUsesUnwrap),
            MirForStatement loop =>
                (loop.Initializer is not null && StatementUsesUnwrap(loop.Initializer))
                || (loop.Condition is not null && ExpressionUsesUnwrap(loop.Condition))
                || (loop.Increment is not null && ExpressionUsesUnwrap(loop.Increment))
                || loop.BodyStatements.Any(StatementUsesUnwrap),
            _ => false,
        };
    }

    private static bool ExpressionUsesUnwrap(MirExpression expression)
    {
        return expression switch
        {
            MirTableRecalculationExpression recalculation => recalculation.Inputs.Any(input => ExpressionUsesUnwrap(input.Value)),
            MirTableSummaryExpression summary => ExpressionUsesUnwrap(summary.Source),
            MirTableRowsExpression rows => ExpressionUsesUnwrap(rows.Table),
            MirTableWhereExpression where => ExpressionUsesUnwrap(where.Source) || where.Predicates.Any(ExpressionUsesUnwrap),
            MirTableSelectExpression select => ExpressionUsesUnwrap(select.Source) || ExpressionUsesUnwrap(select.Projector),
            MirArrayLengthExpression length => ExpressionUsesUnwrap(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionUsesUnwrap(access.Receiver) || ExpressionUsesUnwrap(access.Index),
            MirUnwrapExpression => true,
            MirAssignmentExpression assignment => ExpressionUsesUnwrap(assignment.Expression),
            MirUnaryExpression unary => ExpressionUsesUnwrap(unary.Operand),
            MirBinaryExpression binary => ExpressionUsesUnwrap(binary.Left) || ExpressionUsesUnwrap(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionUsesUnwrap),
            MirInvokeExpression invoke => ExpressionUsesUnwrap(invoke.Callee) || invoke.Arguments.Any(ExpressionUsesUnwrap),
            MirArrayExpression array => array.Elements.Any(ExpressionUsesUnwrap),
            MirRecordConstructionExpression construction => construction.Initializers.Any(initializer => ExpressionUsesUnwrap(initializer.Value)),
            MirRecordFieldAccessExpression access => ExpressionUsesUnwrap(access.Receiver),
            MirTableWithExpression withExpression => ExpressionUsesUnwrap(withExpression.Source) || withExpression.Replacements.Any(replacement => ExpressionUsesUnwrap(replacement.Value)),
            MirRecordWithExpression withExpression => ExpressionUsesUnwrap(withExpression.Source) || withExpression.Replacements.Any(replacement => ExpressionUsesUnwrap(replacement.Value)),
            MirTableColumnAccessExpression access => ExpressionUsesUnwrap(access.Receiver),
            MirTableRowAccessExpression access => ExpressionUsesUnwrap(access.Receiver) || ExpressionUsesUnwrap(access.Index),
            MirColumnElementAccessExpression access => ExpressionUsesUnwrap(access.Receiver) || ExpressionUsesUnwrap(access.Index),
            MirTableRowFieldAccessExpression access => ExpressionUsesUnwrap(access.Receiver),
            MirEnumValueExpression value => value.Arguments.Any(ExpressionUsesUnwrap),
            MirMatchExpression match => ExpressionUsesUnwrap(match.Scrutinee) || match.Arms.Any(arm => ExpressionUsesUnwrap(arm.Expression)),
            MirResultMatchExpression match => ExpressionUsesUnwrap(match.Scrutinee) || ExpressionUsesUnwrap(match.OkExpression) || ExpressionUsesUnwrap(match.ErrExpression),
            MirIfExpression conditional => ExpressionUsesUnwrap(conditional.Condition) || ExpressionUsesUnwrap(conditional.ThenExpression) || ExpressionUsesUnwrap(conditional.ElseExpression),
            MirOkExpression ok => ExpressionUsesUnwrap(ok.Payload),
            MirErrExpression err => ExpressionUsesUnwrap(err.Payload),
            MirPropagateExpression propagation => ExpressionUsesUnwrap(propagation.Operand),
            MirTryExpression tryExpression => ValueBlockUsesUnwrap(tryExpression.Protected) || ValueBlockUsesUnwrap(tryExpression.Handler),
            MirTsonEncodeExpression encode => ExpressionUsesUnwrap(encode.Operand),
            _ => false,
        };
    }

    private static bool ValueBlockUsesUnwrap(MirValueBlock block)
        => block.PrefixStatements.Any(StatementUsesUnwrap)
            || ExpressionUsesUnwrap(block.ValueExpression);
    private static IEnumerable<MirType> EnumerateTypes(MirProgram program)
    {
        foreach (var function in program.Functions)
        {
            yield return function.ReturnType;
            foreach (var parameter in function.Parameters) yield return parameter.Type;
            foreach (var local in function.Locals) yield return local.Type;
            foreach (MirType type in function.Body.SelectMany(EnumerateTableQueryTypes)) yield return type;
        }
        foreach (var @enum in program.Enums) foreach (var @case in @enum.Cases) foreach (var field in @case.PayloadFields) yield return field.Type;
        foreach (var record in program.Records) foreach (var field in record.Fields) yield return field.Type;
        foreach (var table in program.Tables)
        {
            foreach (var column in table.Columns)
            {
                yield return column.ElementType;
                foreach (var constant in column.Constants)
                {
                    foreach (var type in EnumerateTableConstantTypes(constant))
                    {
                        yield return type;
                    }
                }
            }
        }
    }

    private static IEnumerable<MirType> EnumerateTableQueryTypes(MirStatement statement)
    {
        return statement switch
        {
            MirVariableDeclarationStatement declaration => EnumerateTableQueryTypes(declaration.Initializer),
            MirExpressionStatement expression => EnumerateTableQueryTypes(expression.Expression),
            MirReturnStatement { Expression: not null } returned => EnumerateTableQueryTypes(returned.Expression),
            MirIfStatement conditional => EnumerateTableQueryTypes(conditional.Condition)
                .Concat(conditional.ThenStatements.SelectMany(EnumerateTableQueryTypes))
                .Concat(conditional.ElseStatements?.SelectMany(EnumerateTableQueryTypes) ?? []),
            MirWhileStatement loop => EnumerateTableQueryTypes(loop.Condition)
                .Concat(loop.BodyStatements.SelectMany(EnumerateTableQueryTypes)),
            MirForStatement loop => (loop.Initializer is null ? [] : EnumerateTableQueryTypes(loop.Initializer))
                .Concat(loop.Condition is null ? [] : EnumerateTableQueryTypes(loop.Condition))
                .Concat(loop.Increment is null ? [] : EnumerateTableQueryTypes(loop.Increment))
                .Concat(loop.BodyStatements.SelectMany(EnumerateTableQueryTypes)),
            _ => [],
        };
    }

    private static IEnumerable<MirType> EnumerateTableQueryTypes(MirExpression expression)
    {
        return expression switch
        {
            MirArrayLengthExpression length => EnumerateTableQueryTypes(length.Receiver),
            MirArrayElementAccessExpression access => EnumerateTableQueryTypes(access.Receiver).Concat(EnumerateTableQueryTypes(access.Index)),
            MirNumericConversionExpression conversion => EnumerateTableQueryTypes(conversion.Operand),
            MirTableSummaryExpression summary => EnumerateTableQueryTypes(summary.Source),
            MirTableRecalculationExpression recalculation => recalculation.Inputs.SelectMany(input => EnumerateTableQueryTypes(input.Value)),
            MirTableRowsExpression rows => EnumerateTableQueryTypes(rows.Table),
            MirTableWhereExpression where => EnumerateTableQueryTypes(where.Source)
                .Concat(where.Predicates.SelectMany(predicate => new[] { predicate.Type }.Concat(EnumerateTableQueryTypes(predicate)))),
            MirTableSelectExpression select => EnumerateTableQueryTypes(select.Source)
                .Concat([select.Projector.Type])
                .Concat(EnumerateTableQueryTypes(select.Projector)),
            MirTableAggregateExpression aggregate => EnumerateTableQueryTypes(aggregate.Receiver),
            MirAssignmentExpression assignment => EnumerateTableQueryTypes(assignment.Expression),
            MirUnaryExpression unary => EnumerateTableQueryTypes(unary.Operand),
            MirBinaryExpression binary => EnumerateTableQueryTypes(binary.Left).Concat(EnumerateTableQueryTypes(binary.Right)),
            MirCallExpression call => call.Arguments.SelectMany(EnumerateTableQueryTypes),
            MirInvokeExpression invoke => EnumerateTableQueryTypes(invoke.Callee).Concat(invoke.Arguments.SelectMany(EnumerateTableQueryTypes)),
            MirArrayExpression array => array.Elements.SelectMany(EnumerateTableQueryTypes),
            MirRecordConstructionExpression record => record.Initializers.SelectMany(initializer => EnumerateTableQueryTypes(initializer.Value)),
            MirRecordFieldAccessExpression access => EnumerateTableQueryTypes(access.Receiver),
            MirTableColumnAccessExpression access => EnumerateTableQueryTypes(access.Receiver),
            MirTableRowAccessExpression access => EnumerateTableQueryTypes(access.Receiver).Concat(EnumerateTableQueryTypes(access.Index)),
            MirColumnElementAccessExpression access => EnumerateTableQueryTypes(access.Receiver).Concat(EnumerateTableQueryTypes(access.Index)),
            MirTableRowFieldAccessExpression access => EnumerateTableQueryTypes(access.Receiver),
            _ => [],
        };
    }

    private static bool ExpressionRequiresStatements(MirExpression expression)
    {
        return expression switch
        {
            MirRecordConstructionExpression => true,
            MirTableSummaryExpression => true,
            MirTableRecalculationExpression => true,
            MirTableSelectExpression => true,
            MirTableWithExpression => true,
            MirRecordWithExpression => true,
            MirResultMatchExpression => true,
            MirPropagateExpression => true,
            MirUnwrapExpression => true,
            MirTryExpression => true,
            MirAssignmentExpression assignment => ExpressionRequiresStatements(assignment.Expression),
            MirUnaryExpression unary => ExpressionRequiresStatements(unary.Operand),
            MirBinaryExpression binary => ExpressionRequiresStatements(binary.Left) || ExpressionRequiresStatements(binary.Right),
            MirCallExpression call => call.Arguments.Any(ExpressionRequiresStatements),
            MirInvokeExpression invoke => ExpressionRequiresStatements(invoke.Callee) || invoke.Arguments.Any(ExpressionRequiresStatements),
            MirArrayExpression array => array.Counts is not null || array.Elements.Any(ExpressionRequiresStatements),
            MirArrayLengthExpression length => ExpressionRequiresStatements(length.Receiver),
            MirArrayElementAccessExpression access => ExpressionRequiresStatements(access.Receiver) || ExpressionRequiresStatements(access.Index),
            MirNumericConversionExpression conversion => ExpressionRequiresStatements(conversion.Operand),
            MirRecordFieldAccessExpression access => ExpressionRequiresStatements(access.Receiver),
            MirTableColumnAccessExpression access => ExpressionRequiresStatements(access.Receiver),
            MirTableAggregateExpression aggregate => ExpressionRequiresStatements(aggregate.Receiver),
            MirTableRowAccessExpression access => ExpressionRequiresStatements(access.Receiver) || ExpressionRequiresStatements(access.Index),
            MirColumnElementAccessExpression access => ExpressionRequiresStatements(access.Receiver) || ExpressionRequiresStatements(access.Index),
            MirTableRowFieldAccessExpression access => ExpressionRequiresStatements(access.Receiver),
            MirEnumValueExpression value => value.Arguments.Any(ExpressionRequiresStatements),
            MirMatchExpression match => ExpressionRequiresStatements(match.Scrutinee) || match.Arms.Any(arm => ExpressionRequiresStatements(arm.Expression)),
            MirIfExpression conditional => ExpressionRequiresStatements(conditional.Condition) || ExpressionRequiresStatements(conditional.ThenExpression) || ExpressionRequiresStatements(conditional.ElseExpression),
            MirOkExpression ok => ExpressionRequiresStatements(ok.Payload),
            MirErrExpression err => ExpressionRequiresStatements(err.Payload),
            MirTsonEncodeExpression encode => ExpressionRequiresStatements(encode.Operand),
            _ => false,
        };
    }

    private static string RecordTypeName(MirRecordTypeId id)
        => "__CopeRecord_" + (EmissionOptions.RecordCarrierScope is null ? string.Empty : EmissionOptions.RecordCarrierScope + "_") + EncodeStableIdentity(id.Value);

    private static string RecordFieldName(MirRecordFieldId id)
        => "__field_" + EncodeStableIdentity(id.Value);

    private static string TableTypeName(MirTableId id)
        => "__CopeTable_" + EncodeStableIdentity(id.Value);

    private static string TableRowTypeName(string rowTypeId)
        => "__CopeTableRow_" + EncodeStableIdentity(rowTypeId);

    private static string TableColumnTypeName(MirTableColumnId id)
        => "__CopeTableColumn_" + EncodeStableIdentity(id.Value);

    private static IEnumerable<MirCallableType> EnumerateCallableTypes(MirType root)
    {
        var pending = new Stack<MirType>();
        pending.Push(root);
        while (pending.Count > 0)
        {
            MirType type = pending.Pop();
            switch (type)
            {
                case MirCallableType callable:
                    yield return callable;
                    foreach (var parameter in callable.Parameters) pending.Push(parameter.Type);
                    pending.Push(callable.ReturnType);
                    break;
                case MirArrayType array:
                    pending.Push(array.ElementType);
                    break;
                case MirResultType result:
                    pending.Push(result.SuccessType);
                    pending.Push(result.ErrorType);
                    break;
                case MirColumnType column:
                    pending.Push(column.ElementType);
                    break;
            }
        }
    }

    private static string CallableDelegateName(MirCallableType callable)
        => "__CopeCallable_" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(CallableTypeIdentity(callable))));

    private static string CallableTypeIdentity(MirCallableType callable)
        => "(" + string.Join(",", callable.Parameters.Select(parameter => MirTypeIdentity(parameter.Type))) + ")->" + MirTypeIdentity(callable.ReturnType);

    private static string MirTypeIdentity(MirType type) => type switch
    {
        MirArrayType array => "array(" + MirTypeIdentity(array.ElementType) + ")",
        MirResultType result => "result(" + MirTypeIdentity(result.SuccessType) + "," + MirTypeIdentity(result.ErrorType) + ")",
        MirCallableType callable => CallableTypeIdentity(callable),
        MirRecordType record => "record:" + record.RecordTypeId.Value,
        MirTableType table => "table:" + table.TableId.Value,
        MirTableRowType row => "row:" + row.RowTypeId,
        MirColumnType column => "column(" + MirTypeIdentity(column.ElementType) + ")",
        _ => "named:" + type.Identifier,
    };

    private static string TableSingletonName(MirTableId id)
        => "__cope_table_" + EncodeStableIdentity(id.Value);

    private static string TableStorageName(MirTableColumnId id)
        => "_column_" + EncodeStableIdentity(id.Value);

    private static string TableWithColumnMethodName(MirTableColumnId id)
        => "__with_" + EncodeStableIdentity(id.Value);

    private static string TableColumnPropertyName(MirTableColumnId id)
        => "__column_" + EncodeStableIdentity(id.Value);

    private static string TableReadMethodName(MirTableColumnId id)
        => "__read_" + EncodeStableIdentity(id.Value);

    private static string DerivedJoinParameterName(MirRelationJoin join)
        => CSharpNameMangler.Mangle(join.Alias) + "Relation";

    private static string TableTsonStorageAccessName(MirTableColumnId id)
        => "__tson_values_" + EncodeStableIdentity(id.Value);

    private static string TableRowFieldName(MirTableColumnId id)
        => "__row_field_" + EncodeStableIdentity(id.Value);

    private static string TableRowFieldName(string fieldId)
        => "__row_field_" + EncodeStableIdentity(fieldId.Replace(".f", string.Empty, StringComparison.Ordinal));

    private static IEnumerable<MirType> EnumerateTableConstantTypes(MirTableConstant constant)
    {
        yield return constant.Type;
        switch (constant)
        {
            case MirTableArrayConstant array:
                foreach (var element in array.Elements)
                {
                    foreach (var type in EnumerateTableConstantTypes(element))
                    {
                        yield return type;
                    }
                }
                break;
            case MirTableRecordConstant record:
                foreach (var field in record.Fields)
                {
                    foreach (var type in EnumerateTableConstantTypes(field.Value))
                    {
                        yield return type;
                    }
                }
                break;
            case MirTableEnumConstant value:
                foreach (var payload in value.Payloads)
                {
                    foreach (var type in EnumerateTableConstantTypes(payload))
                    {
                        yield return type;
                    }
                }
                break;
            case MirTableResultConstant result:
                foreach (var type in EnumerateTableConstantTypes(result.Payload))
                {
                    yield return type;
                }
                break;
        }
    }

    private static string EncodeStableIdentity(string identity)
    {
        var encoded = new global::System.Text.StringBuilder(identity.Length);
        foreach (char character in identity)
        {
            if ((character >= 'a' && character <= 'z')
                || (character >= 'A' && character <= 'Z')
                || (character >= '0' && character <= '9'))
            {
                encoded.Append(character);
            }
            else
            {
                encoded.Append('_');
                encoded.Append(((int)character).ToString("X4", global::System.Globalization.CultureInfo.InvariantCulture));
            }
        }

        return encoded.ToString();
    }
    private static bool ContainsVoidResult(MirType type) => type switch { MirResultType result => result.SuccessType is MirNamedType { Identifier: "void" } || ContainsVoidResult(result.SuccessType) || ContainsVoidResult(result.ErrorType), MirArrayType array => ContainsVoidResult(array.ElementType), _ => false };
    private static List<string> CollectErrorNominalTypes(MirProgram program, IReadOnlySet<string> enumNames)
    {
        var names = new HashSet<string>(StringComparer.Ordinal); foreach (var type in EnumerateTypes(program)) Collect(type, names, enumNames); return names.OrderBy(name => name, StringComparer.Ordinal).ToList();
    }
    private static void Collect(MirType type, ISet<string> names, IReadOnlySet<string> enumNames)
    {
        switch (type) { case MirResultType result: CollectError(result.ErrorType, names, enumNames); Collect(result.SuccessType, names, enumNames); break; case MirArrayType array: Collect(array.ElementType, names, enumNames); break; }
    }
    private static void CollectError(MirType type, ISet<string> names, IReadOnlySet<string> enumNames)
    {
        switch (type) { case MirNamedType named when named.Identifier is not ("number" or "string" or "boolean" or "void" or "error") && !enumNames.Contains(named.Identifier): names.Add(named.Identifier); break; case MirResultType result: CollectError(result.ErrorType, names, enumNames); Collect(result.SuccessType, names, enumNames); break; case MirArrayType array: CollectError(array.ElementType, names, enumNames); break; }
    }
}
