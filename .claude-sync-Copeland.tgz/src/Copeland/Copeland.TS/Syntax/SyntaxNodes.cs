namespace Copeland.TS.Syntax;

public abstract record SyntaxNode
{
    public abstract SyntaxKind Kind { get; }

    public abstract IEnumerable<object> GetChildren();
}

public abstract record MemberSyntax : SyntaxNode;

public abstract record StatementSyntax : SyntaxNode;

public abstract record ExpressionSyntax : SyntaxNode;
public abstract record TypeSyntax : SyntaxNode;

/// <summary>
/// Evaluates an ordinary Copeland expression during the post-binding static
/// phase. This is unrelated to runtime static members or storage duration.
/// </summary>
public sealed record StaticExpressionSyntax(
    SyntaxToken StaticKeyword,
    ExpressionSyntax Expression) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StaticExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return StaticKeyword;
        yield return Expression;
    }
}

/// <summary>
/// An explicit request for bounded compiler-owned semantic metadata. Unlike a
/// static expression, the operand names a reflection query rather than normal
/// Copeland computation.
/// </summary>
public sealed record ReflectExpressionSyntax(
    SyntaxToken ReflectKeyword,
    ExpressionSyntax Expression) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ReflectExpression;
    public override IEnumerable<object> GetChildren()
    {
        yield return ReflectKeyword;
        yield return Expression;
    }
}

public sealed record TemplateExpressionSyntax(SyntaxToken TemplateToken, IReadOnlyList<TemplatePartSyntax> Parts) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TemplateExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return TemplateToken;
        foreach (TemplatePartSyntax part in Parts)
        {
            yield return part;
        }
    }
}

public abstract record TemplatePartSyntax : SyntaxNode;

public sealed record TemplateTextPartSyntax(string Text) : TemplatePartSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TemplateTextPart;
    public override IEnumerable<object> GetChildren() => [];
}

public sealed record TemplateInterpolationPartSyntax(ExpressionSyntax Expression) : TemplatePartSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TemplateInterpolationPart;
    public override IEnumerable<object> GetChildren() => [Expression];
}

public sealed record CompilationUnitSyntax(IReadOnlyList<MemberSyntax> Members, SyntaxToken EndOfFileToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.CompilationUnit;

    public override IEnumerable<object> GetChildren()
    {
        foreach (var member in Members)
        {
            yield return member;
        }

        yield return EndOfFileToken;
    }
}

public sealed record GlobalStatementMemberSyntax(StatementSyntax Statement) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.GlobalStatementMember;

    public override IEnumerable<object> GetChildren()
    {
        yield return Statement;
    }
}

public sealed record PredefinedTypeSyntax(SyntaxToken Keyword) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.PredefinedType;

    public override IEnumerable<object> GetChildren()
    {
        yield return Keyword;
    }
}

public sealed record IdentifierTypeSyntax(SyntaxToken Identifier) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IdentifierType;

    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
    }
}

public sealed record ArrayTypeSyntax(TypeSyntax ElementType, SyntaxToken OpenBracketToken, SyntaxToken CloseBracketToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ArrayType;

    public override IEnumerable<object> GetChildren()
    {
        yield return ElementType;
        yield return OpenBracketToken;
        yield return CloseBracketToken;
    }
}

/// <summary>A finite, compile-time-only object shape used by <c>type</c> declarations.</summary>
public sealed record StructuralObjectTypeSyntax(
    SyntaxToken OpenBraceToken,
    IReadOnlyList<StructuralTypeFieldSyntax> Fields,
    SyntaxToken CloseBraceToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StructuralObjectType;
    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBraceToken;
        foreach (StructuralTypeFieldSyntax field in Fields) yield return field;
        yield return CloseBraceToken;
    }
}

public sealed record StructuralTypeFieldSyntax(
    SyntaxToken? ReadonlyKeyword,
    SyntaxToken Identifier,
    SyntaxToken? QuestionToken,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.StructuralTypeField;
    public override IEnumerable<object> GetChildren()
    {
        if (ReadonlyKeyword is not null) yield return ReadonlyKeyword;
        yield return Identifier;
        if (QuestionToken is not null) yield return QuestionToken;
        yield return ColonToken;
        yield return Type;
        yield return SemicolonToken;
    }
}

public sealed record UnionTypeSyntax(TypeSyntax Left, SyntaxToken PipeToken, TypeSyntax Right) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.UnionType;
    public override IEnumerable<object> GetChildren() => [Left, PipeToken, Right];
}

public sealed record IntersectionTypeSyntax(TypeSyntax Left, SyntaxToken AmpersandToken, TypeSyntax Right) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IntersectionType;
    public override IEnumerable<object> GetChildren() => [Left, AmpersandToken, Right];
}

public sealed record GenericTypeSyntax(
    SyntaxToken Identifier,
    SyntaxToken LessToken,
    IReadOnlyList<TypeSyntax> TypeArguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken GreaterToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.GenericType;
    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        yield return LessToken;
        for (int index = 0; index < TypeArguments.Count; index++)
        {
            if (index > 0) yield return CommaTokens[index - 1];
            yield return TypeArguments[index];
        }
        yield return GreaterToken;
    }
}

public sealed record LiteralTypeSyntax(SyntaxToken LiteralToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LiteralType;
    public override IEnumerable<object> GetChildren() => [LiteralToken];
}

/// <summary>
/// Preserves a TypeScript import for profile-owned validation. The base language
/// intentionally gives imports no executable meaning.
/// </summary>
public sealed record ImportDeclarationSyntax(IReadOnlyList<SyntaxToken> Tokens) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ImportDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        foreach (SyntaxToken token in Tokens)
        {
            yield return token;
        }
    }
}

/// <summary>
/// A module-level CLR namespace or named-type import. This is intentionally a
/// different syntax node from TypeScript's resource <c>using</c> declaration.
/// </summary>
public sealed record ClrUsingDirectiveSyntax(
    SyntaxToken UsingKeyword,
    IReadOnlyList<SyntaxToken> NameParts,
    IReadOnlyList<SyntaxToken> DotTokens,
    SyntaxToken SemicolonToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ClrUsingDirective;

    public string QualifiedName => string.Join('.', NameParts.Select(part => part.Text));

    public override IEnumerable<object> GetChildren()
    {
        yield return UsingKeyword;
        for (int index = 0; index < NameParts.Count; index++)
        {
            yield return NameParts[index];
            if (index < DotTokens.Count)
            {
                yield return DotTokens[index];
            }
        }

        yield return SemicolonToken;
    }
}

/// <summary>
/// Preserves an export-default wrapper for a profile-owned document root.
/// </summary>
public sealed record ExportDefaultDeclarationSyntax(
    SyntaxToken ExportToken,
    SyntaxToken DefaultToken,
    ExpressionSyntax Expression,
    SyntaxToken? SemicolonToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ExportDefaultDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return ExportToken;
        yield return DefaultToken;
        yield return Expression;
        if (SemicolonToken is not null)
        {
            yield return SemicolonToken;
        }
    }
}

public sealed record AsyncTypeSyntax(
    SyntaxToken AsyncKeyword,
    SyntaxToken LessToken,
    TypeSyntax EventualType,
    SyntaxToken GreaterToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.AsyncType;

    public override IEnumerable<object> GetChildren()
    {
        yield return AsyncKeyword;
        yield return LessToken;
        yield return EventualType;
        yield return GreaterToken;
    }
}

public sealed record IterableTypeSyntax(
    SyntaxToken IterableIdentifier,
    SyntaxToken LessToken,
    TypeSyntax ElementType,
    SyntaxToken GreaterToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IterableType;

    public override IEnumerable<object> GetChildren()
    {
        yield return IterableIdentifier;
        yield return LessToken;
        yield return ElementType;
        yield return GreaterToken;
    }
}

public sealed record TypeAliasDeclarationSyntax(
    SyntaxToken TypeKeyword,
    SyntaxToken Identifier,
    IReadOnlyList<SyntaxToken> TypeParameterTokens,
    SyntaxToken EqualsToken,
    TypeSyntax TargetType,
    IReadOnlyList<SyntaxToken> UnsupportedTokens,
    SyntaxToken SemicolonToken,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : MemberSyntax
{
    public GenericParameterListSyntax? GenericParameters { get; init; }

    public override SyntaxKind Kind => SyntaxKind.TypeAliasDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? [])
        {
            yield return annotation;
        }
        if (GenericParameters?.TemplateKeyword is not null)
        {
            yield return GenericParameters;
        }
        yield return TypeKeyword;
        yield return Identifier;
        if (GenericParameters is { TemplateKeyword: null }) yield return GenericParameters;
        foreach (var token in TypeParameterTokens)
        {
            yield return token;
        }

        yield return EqualsToken;
        yield return TargetType;
        foreach (var token in UnsupportedTokens)
        {
            yield return token;
        }

        yield return SemicolonToken;
    }
}

/// <summary>
/// A compilation-unit nominal union declaration. Pipe spelling is deliberately
/// not admitted into general TypeSyntax.
/// </summary>
public sealed record NominalUnionDeclarationSyntax(
    SyntaxToken TypeKeyword,
    SyntaxToken Identifier,
    SyntaxToken EqualsToken,
    SyntaxToken? LeadingPipeToken,
    IReadOnlyList<SyntaxToken> Alternatives,
    IReadOnlyList<SyntaxToken> PipeTokens,
    SyntaxToken SemicolonToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.NominalUnionDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return TypeKeyword;
        yield return Identifier;
        yield return EqualsToken;
        if (LeadingPipeToken is not null)
        {
            yield return LeadingPipeToken;
        }

        for (var index = 0; index < Alternatives.Count; index++)
        {
            yield return Alternatives[index];
            if (index < PipeTokens.Count)
            {
                yield return PipeTokens[index];
            }
        }

        yield return SemicolonToken;
    }
}

public sealed record InterfaceFieldSyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    IReadOnlyList<SyntaxToken> UnsupportedTokens,
    SyntaxToken SemicolonToken,
    bool HasExplicitType,
    bool HasTerminator,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.InterfaceField;
    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        yield return Identifier;
        yield return ColonToken;
        yield return Type;
        foreach (var token in UnsupportedTokens) yield return token;
        yield return SemicolonToken;
    }
}

public sealed record InterfaceDeclarationSyntax(
    SyntaxToken InterfaceKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<InterfaceFieldSyntax> Fields,
    SyntaxToken CloseBraceToken,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : MemberSyntax
{
    public GenericParameterListSyntax? GenericParameters { get; init; }

    public override SyntaxKind Kind => SyntaxKind.InterfaceDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        if (GenericParameters?.TemplateKeyword is not null)
        {
            yield return GenericParameters;
        }
        yield return InterfaceKeyword;
        yield return Identifier;
        if (GenericParameters is { TemplateKeyword: null }) yield return GenericParameters;
        yield return OpenBraceToken;
        foreach (var field in Fields) yield return field;
        yield return CloseBraceToken;
    }
}

public sealed record TypeParameterSyntax(
    SyntaxToken? TypeKeyword,
    SyntaxToken Identifier,
    SyntaxToken? ExtendsKeyword,
    IReadOnlyList<SyntaxToken> RequirementNames,
    IReadOnlyList<SyntaxToken> AmpersandTokens,
    SyntaxToken? EqualsToken = null,
    TypeSyntax? DefaultType = null,
    IReadOnlyList<TypeSyntax>? RequirementTypes = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TypeParameter;
    public override IEnumerable<object> GetChildren()
    {
        if (TypeKeyword is not null) yield return TypeKeyword;
        yield return Identifier;
        if (ExtendsKeyword is not null) yield return ExtendsKeyword;
        if (RequirementTypes is not null)
        {
            for (int index = 0; index < RequirementTypes.Count; index++)
            {
                if (index > 0) yield return AmpersandTokens[index - 1];
                yield return RequirementTypes[index];
            }
        }
        else
        {
            for (var i = 0; i < RequirementNames.Count; i++)
            {
                if (i > 0) yield return AmpersandTokens[i - 1];
                yield return RequirementNames[i];
            }
        }
        if (EqualsToken is not null) yield return EqualsToken;
        if (DefaultType is not null) yield return DefaultType;
    }
}

public sealed record ParenthesizedTypeSyntax(SyntaxToken OpenParenToken, TypeSyntax Type, SyntaxToken CloseParenToken) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ParenthesizedType;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenParenToken;
        yield return Type;
        yield return CloseParenToken;
    }
}

public sealed record ResultTypeSyntax(TypeSyntax SuccessType, SyntaxToken BangToken, TypeSyntax ErrorType) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ResultType;

    public override IEnumerable<object> GetChildren()
    {
        yield return SuccessType;
        yield return BangToken;
        yield return ErrorType;
    }
}

public sealed record CallableTypeParameterSyntax(SyntaxToken Identifier, SyntaxToken ColonToken, TypeSyntax Type) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.Parameter;

    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        yield return ColonToken;
        yield return Type;
    }
}

public sealed record CallableTypeSyntax(
    SyntaxToken OpenParenToken,
    IReadOnlyList<CallableTypeParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken,
    SyntaxToken ArrowToken,
    TypeSyntax ReturnType) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.CallableType;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenParenToken;
        foreach (var parameter in Parameters) yield return parameter;
        foreach (var comma in CommaTokens) yield return comma;
        yield return CloseParenToken;
        yield return ArrowToken;
        yield return ReturnType;
    }
}

public sealed record QualifiedRowTypeSyntax(SyntaxToken TableIdentifier, SyntaxToken DotToken, SyntaxToken RowIdentifier) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.QualifiedRowType;
    public override IEnumerable<object> GetChildren() { yield return TableIdentifier; yield return DotToken; yield return RowIdentifier; }
}

public sealed record ColumnTypeSyntax(SyntaxToken ColumnKeyword, TypeSyntax ElementType) : TypeSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ColumnType;
    public override IEnumerable<object> GetChildren() { yield return ColumnKeyword; yield return ElementType; }
}

public sealed record AnnotationSyntax(
    SyntaxToken AtToken,
    SyntaxToken NameToken,
    SyntaxToken? OpenParenToken,
    IReadOnlyList<ExpressionSyntax> Arguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken? CloseParenToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.Annotation;

    public override IEnumerable<object> GetChildren()
    {
        yield return AtToken;
        yield return NameToken;
        if (OpenParenToken is not null) yield return OpenParenToken;
        for (int index = 0; index < Arguments.Count; index++)
        {
            if (index > 0) yield return CommaTokens[index - 1];
            yield return Arguments[index];
        }
        if (CloseParenToken is not null) yield return CloseParenToken;
    }
}

public sealed record ParameterSyntax(
    SyntaxToken Identifier,
    SyntaxToken? ColonToken,
    TypeSyntax? Type,
    IReadOnlyList<AnnotationSyntax>? Annotations = null,
    SyntaxToken? AccessToken = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.Parameter;

    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        if (AccessToken is not null) yield return AccessToken;
        yield return Identifier;
        if (ColonToken is not null)
        {
            yield return ColonToken;
        }

        if (Type is not null)
        {
            yield return Type;
        }
    }
}

public sealed record FunctionDeclarationSyntax(
    SyntaxToken? RemoteKeyword,
    SyntaxToken? AsyncKeyword,
    SyntaxToken FunctionKeyword,
    SyntaxToken? GeneratorStarToken,
    SyntaxToken Identifier,
    SyntaxToken? LessToken,
    IReadOnlyList<TypeParameterSyntax> TypeParameters,
    IReadOnlyList<SyntaxToken> TypeParameterCommas,
    SyntaxToken? GreaterToken,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken,
    SyntaxToken? ReturnTypeColonToken,
    TypeSyntax? ReturnType,
    BlockStatementSyntax Body,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : MemberSyntax
{
    public GenericParameterListSyntax? GenericParameters { get; init; }

    public override SyntaxKind Kind => SyntaxKind.FunctionDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        if (RemoteKeyword is not null) yield return RemoteKeyword;
        if (AsyncKeyword is not null) yield return AsyncKeyword;
        if (GenericParameters?.TemplateKeyword is not null)
        {
            yield return GenericParameters;
        }
        yield return FunctionKeyword;
        if (GeneratorStarToken is not null) yield return GeneratorStarToken;
        yield return Identifier;
        if (GenericParameters is { TemplateKeyword: null })
        {
            yield return GenericParameters;
        }
        else if (GenericParameters is null)
        {
            if (LessToken is not null) yield return LessToken;
            for (var i = 0; i < TypeParameters.Count; i++)
            {
                if (i > 0) yield return TypeParameterCommas[i - 1];
                yield return TypeParameters[i];
            }
            if (GreaterToken is not null) yield return GreaterToken;
        }
        yield return OpenParenToken;

        for (var i = 0; i < Parameters.Count; i++)
        {
            if (i > 0)
            {
                yield return CommaTokens[i - 1];
            }

            yield return Parameters[i];
        }

        yield return CloseParenToken;
        if (ReturnTypeColonToken is not null)
        {
            yield return ReturnTypeColonToken;
        }

        if (ReturnType is not null)
        {
            yield return ReturnType;
        }
        yield return Body;
    }
}

/// <summary>A bounded structural artifact constructor, never a runtime function.</summary>
public sealed record TemplateDeclarationSyntax(
    SyntaxToken TemplateKeyword,
    SyntaxToken LessToken,
    IReadOnlyList<TypeParameterSyntax> TypeParameters,
    IReadOnlyList<TemplateParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken GreaterToken,
    SyntaxToken Identifier,
    SyntaxToken ReturnTypeColonToken,
    TypeSyntax ReturnType,
    BlockStatementSyntax Body) : MemberSyntax
{
    public LayoutDeclarationSyntax? LayoutBody { get; init; }

    public override SyntaxKind Kind => SyntaxKind.TemplateDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return TemplateKeyword;
        yield return LessToken;
        int commaIndex = 0;
        for (int index = 0; index < TypeParameters.Count; index++)
        {
            if (index > 0) yield return CommaTokens[commaIndex++];
            yield return TypeParameters[index];
        }
        for (int index = 0; index < Parameters.Count; index++)
        {
            if (TypeParameters.Count > 0 || index > 0) yield return CommaTokens[commaIndex++];
            yield return Parameters[index];
        }
        yield return GreaterToken;
        if (LayoutBody is not null)
        {
            yield return LayoutBody;
        }
        else
        {
            yield return Identifier;
            yield return ReturnTypeColonToken;
            yield return ReturnType;
            yield return Body;
        }
    }
}

public sealed record TemplateParameterSyntax(
    SyntaxToken StaticKeyword,
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    SyntaxToken? EqualsToken = null,
    ExpressionSyntax? DefaultValue = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.Parameter;
    public override IEnumerable<object> GetChildren()
    {
        yield return StaticKeyword;
        yield return Identifier;
        yield return ColonToken;
        yield return Type;
        if (EqualsToken is not null) yield return EqualsToken;
        if (DefaultValue is not null) yield return DefaultValue;
    }
}

public sealed record TemplateInstantiationArgumentSyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    ExpressionSyntax Value) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TemplateInstantiationArgument;
    public override IEnumerable<object> GetChildren() => [Identifier, ColonToken, Value];
}

/// <summary>Explicit static-phase specialization. This is not a runtime call.</summary>
public sealed record TemplateInstantiationExpressionSyntax(
    SyntaxToken InstantiateKeyword,
    SyntaxToken TemplateIdentifier,
    SyntaxToken LessToken,
    IReadOnlyList<TypeSyntax> TypeArguments,
    IReadOnlyList<TemplateInstantiationArgumentSyntax> StaticArguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken GreaterToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TemplateInstantiationExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return InstantiateKeyword;
        yield return TemplateIdentifier;
        yield return LessToken;
        int commaIndex = 0;
        for (int index = 0; index < TypeArguments.Count; index++)
        {
            if (index > 0) yield return CommaTokens[commaIndex++];
            yield return TypeArguments[index];
        }
        for (int index = 0; index < StaticArguments.Count; index++)
        {
            if (TypeArguments.Count > 0 || index > 0) yield return CommaTokens[commaIndex++];
            yield return StaticArguments[index];
        }
        yield return GreaterToken;
    }
}

/// <summary>
/// A layout declaration is syntax for finite, immutable spatial data. It is not
/// a function body and therefore has no statements, parameters, or return value.
/// </summary>
public sealed record LayoutDeclarationSyntax(
    SyntaxToken LayoutKeyword,
    SyntaxToken? Profile,
    SyntaxToken Identifier,
    LayoutOriginSyntax? Origin,
    SyntaxToken? SatisfiesKeyword,
    SyntaxToken? ContractIdentifier,
    SyntaxToken? EqualsToken,
    SyntaxToken? ComposedLayout,
    SyntaxToken? WithKeyword,
    IReadOnlyList<LayoutPropertySyntax> CompositionProperties,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<LayoutPropertySyntax> Properties,
    IReadOnlyList<LayoutNodeSyntax> Nodes,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public ExpressionSyntax? Initializer { get; init; }

    public override SyntaxKind Kind => SyntaxKind.LayoutDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return LayoutKeyword;
        if (Profile is not null) yield return Profile;
        yield return Identifier;
        if (Origin is not null) yield return Origin;
        if (SatisfiesKeyword is not null) yield return SatisfiesKeyword;
        if (ContractIdentifier is not null) yield return ContractIdentifier;
        if (EqualsToken is not null) yield return EqualsToken;
        if (Initializer is not null) yield return Initializer;
        else if (ComposedLayout is not null) yield return ComposedLayout;
        if (WithKeyword is not null) yield return WithKeyword;
        foreach (LayoutPropertySyntax property in CompositionProperties) yield return property;
        yield return OpenBraceToken;
        foreach (LayoutPropertySyntax property in Properties) yield return property;
        foreach (LayoutNodeSyntax node in Nodes) yield return node;
        yield return CloseBraceToken;
    }
}

/// <summary>
/// A finite compile-time spatial topology contract. It deliberately reuses the
/// layout node grammar while excluding origins, geometry, and executable code.
/// </summary>
public sealed record LayoutTypeDeclarationSyntax(
    SyntaxToken LayoutKeyword,
    SyntaxToken TypeKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<LayoutNodeSyntax> Nodes,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LayoutTypeDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return LayoutKeyword;
        yield return TypeKeyword;
        yield return Identifier;
        yield return OpenBraceToken;
        foreach (LayoutNodeSyntax node in Nodes) yield return node;
        yield return CloseBraceToken;
    }
}

/// <summary>
/// A finite, declaration-ordered semantic paint-layer space. Layer names are
/// compiler symbols, not CSS strings or numeric z-index aliases.
/// </summary>
public sealed record LayerSetDeclarationSyntax(
    SyntaxToken LayersKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<SyntaxToken> Layers,
    IReadOnlyList<SyntaxToken> SemicolonTokens,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LayerSetDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return LayersKeyword;
        yield return Identifier;
        yield return OpenBraceToken;
        foreach (SyntaxToken layer in Layers) yield return layer;
        foreach (SyntaxToken semicolon in SemicolonTokens) yield return semicolon;
        yield return CloseBraceToken;
    }
}

/// <summary>
/// Associates renderable component expressions with the authored slot names of
/// one concrete layout. Binding has no geometry syntax: the layout remains the
/// sole owner of spatial constraints.
/// </summary>
public sealed record LayoutBindingDeclarationSyntax(
    SyntaxToken BindKeyword,
    SyntaxToken LayoutIdentifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<LayoutBindingEntrySyntax> Entries,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LayoutBindingDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return BindKeyword;
        yield return LayoutIdentifier;
        yield return OpenBraceToken;
        foreach (LayoutBindingEntrySyntax entry in Entries) yield return entry;
        yield return CloseBraceToken;
    }
}

public sealed record LayoutBindingEntrySyntax(
    SyntaxToken SlotIdentifier,
    SyntaxToken ColonToken,
    ExpressionSyntax Value,
    SyntaxToken? SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.LayoutBindingEntry;

    public override IEnumerable<object> GetChildren()
    {
        yield return SlotIdentifier;
        yield return ColonToken;
        yield return Value;
        if (SemicolonToken is not null) yield return SemicolonToken;
    }
}

/// <summary>
/// Ergonomic static layout composition. A stream is bound into the same
/// immutable layout and exact singular binding concepts as explicit authoring.
/// </summary>
public sealed record StreamDeclarationSyntax(
    SyntaxToken StreamKeyword,
    SyntaxToken Identifier,
    LayoutOriginSyntax? Origin,
    SyntaxToken? SatisfiesKeyword,
    SyntaxToken? ContractIdentifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<LayoutPropertySyntax> Properties,
    IReadOnlyList<StreamNodeSyntax> Nodes,
    IReadOnlyList<StreamTableSyntax> Tables,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StreamDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return StreamKeyword;
        yield return Identifier;
        if (Origin is not null) yield return Origin;
        if (SatisfiesKeyword is not null) yield return SatisfiesKeyword;
        if (ContractIdentifier is not null) yield return ContractIdentifier;
        yield return OpenBraceToken;
        foreach (LayoutPropertySyntax property in Properties) yield return property;
        foreach (StreamNodeSyntax node in Nodes) yield return node;
        foreach (StreamTableSyntax table in Tables) yield return table;
        yield return CloseBraceToken;
    }
}

/// <summary>
/// A GPU-profile stream is a typed shader boundary. It deliberately has a
/// separate syntax node from Copeland's layout stream even though both retain
/// the compact <c>stream Name { ... }</c> surface.
/// </summary>
public sealed record ShaderStreamDeclarationSyntax(
    SyntaxToken StreamKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<RecordFieldSyntax> Fields,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ShaderStreamDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return StreamKeyword;
        yield return Identifier;
        yield return OpenBraceToken;
        foreach (RecordFieldSyntax field in Fields)
        {
            yield return field;
        }
        yield return CloseBraceToken;
    }
}

/// <summary>
/// A structural container has an explicit kind; an unkinded node is a singular
/// content region and therefore synthesizes an exact slot.
/// </summary>
public sealed record StreamNodeSyntax(
    SyntaxToken? KindToken,
    SyntaxToken Identifier,
    SyntaxToken? ColonToken,
    ExpressionSyntax? Content,
    SyntaxToken? OpenBraceToken,
    IReadOnlyList<LayoutPropertySyntax> Properties,
    IReadOnlyList<StreamNodeSyntax> Children,
    IReadOnlyList<StreamTableSyntax> Tables,
    SyntaxToken? CloseBraceToken,
    IReadOnlyList<LayoutRelativeDerivationSyntax>? RelativeDerivations = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.StreamNode;

    public override IEnumerable<object> GetChildren()
    {
        if (KindToken is not null) yield return KindToken;
        yield return Identifier;
        if (ColonToken is not null) yield return ColonToken;
        if (Content is not null) yield return Content;
        if (OpenBraceToken is not null) yield return OpenBraceToken;
        foreach (LayoutPropertySyntax property in Properties) yield return property;
        foreach (StreamNodeSyntax child in Children) yield return child;
        foreach (StreamTableSyntax table in Tables) yield return table;
        if (CloseBraceToken is not null) yield return CloseBraceToken;
        foreach (LayoutRelativeDerivationSyntax derivation in RelativeDerivations ?? []) yield return derivation;
    }
}

/// <summary>
/// A CSV-shaped, semicolon-row-terminated projection of sibling stream boxes.
/// Cells are ordinary expressions; the header gives each cell its typed layout
/// meaning. It is deliberately syntax, not an embedded CSV string.
/// </summary>
public sealed record StreamTableSyntax(
    SyntaxToken CsvKeyword,
    SyntaxToken ContainerKindToken,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<SyntaxToken> Headers,
    IReadOnlyList<SyntaxToken> HeaderCommas,
    SyntaxToken HeaderSemicolonToken,
    IReadOnlyList<StreamTableRowSyntax> Rows,
    SyntaxToken CloseBraceToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.StreamTable;

    public override IEnumerable<object> GetChildren()
    {
        yield return CsvKeyword;
        yield return ContainerKindToken;
        yield return Identifier;
        yield return OpenBraceToken;
        foreach (SyntaxToken header in Headers) yield return header;
        foreach (SyntaxToken comma in HeaderCommas) yield return comma;
        yield return HeaderSemicolonToken;
        foreach (StreamTableRowSyntax row in Rows) yield return row;
        yield return CloseBraceToken;
    }
}

public sealed record StreamTableRowSyntax(
    IReadOnlyList<ExpressionSyntax> Cells,
    IReadOnlyList<SyntaxToken> Commas,
    SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.StreamTableRow;

    public override IEnumerable<object> GetChildren()
    {
        foreach (ExpressionSyntax cell in Cells) yield return cell;
        foreach (SyntaxToken comma in Commas) yield return comma;
        yield return SemicolonToken;
    }
}

/// <summary>
/// Required local coordinate-space anchor for a layout declaration. This is
/// declaration geometry, rather than an optional property in the layout body.
/// </summary>
public sealed record LayoutOriginSyntax(
    SyntaxToken LessToken,
    ExpressionSyntax X,
    SyntaxToken CommaToken,
    ExpressionSyntax Y,
    SyntaxToken GreaterToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.LayoutDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return LessToken;
        yield return X;
        yield return CommaToken;
        yield return Y;
        yield return GreaterToken;
    }
}

public sealed record LayoutNodeSyntax(
    SyntaxToken KindToken,
    SyntaxToken Identifier,
    SyntaxToken? SemicolonToken,
    SyntaxToken? OpenBraceToken,
    IReadOnlyList<LayoutPropertySyntax> Properties,
    IReadOnlyList<LayoutNodeSyntax> Children,
    SyntaxToken? CloseBraceToken,
    IReadOnlyList<LayoutRelativeDerivationSyntax>? RelativeDerivations = null) : SyntaxNode
{
    public LayoutConditionalSyntax? Conditional { get; init; }

    public override SyntaxKind Kind => SyntaxKind.LayoutNode;

    public override IEnumerable<object> GetChildren()
    {
        if (Conditional is not null)
        {
            yield return Conditional;
            yield break;
        }
        yield return KindToken;
        yield return Identifier;
        if (SemicolonToken is not null) yield return SemicolonToken;
        if (OpenBraceToken is not null) yield return OpenBraceToken;
        foreach (LayoutPropertySyntax property in Properties) yield return property;
        foreach (LayoutNodeSyntax child in Children) yield return child;
        if (CloseBraceToken is not null) yield return CloseBraceToken;
        foreach (LayoutRelativeDerivationSyntax derivation in RelativeDerivations ?? []) yield return derivation;
    }
}

/// <summary>
/// A closed layout-profile derivation. It deliberately is not an ordinary call
/// expression: the binder owns its transform vocabulary and field contract.
/// </summary>
public sealed record LayoutRelativeDerivationSyntax(
    SyntaxToken WithKeyword,
    SyntaxToken TransformIdentifier,
    SyntaxToken OpenParenToken,
    SyntaxToken SourceIdentifier,
    SyntaxToken? CommaToken,
    ExpressionSyntax? GapOrPadding,
    SyntaxToken CloseParenToken,
    SyntaxToken? SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.LayoutNode;

    public override IEnumerable<object> GetChildren()
    {
        yield return WithKeyword;
        yield return TransformIdentifier;
        yield return OpenParenToken;
        yield return SourceIdentifier;
        if (CommaToken is not null) yield return CommaToken;
        if (GapOrPadding is not null) yield return GapOrPadding;
        yield return CloseParenToken;
        if (SemicolonToken is not null) yield return SemicolonToken;
    }
}

public sealed record LayoutPropertySyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    ExpressionSyntax Value,
    SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.LayoutProperty;
    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        yield return ColonToken;
        yield return Value;
        yield return SemicolonToken;
    }
}

public sealed record EnumDeclarationSyntax(
    SyntaxToken EnumKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<EnumCaseSyntax> Cases,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.EnumDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        yield return EnumKeyword;
        yield return Identifier;
        yield return OpenBraceToken;
        foreach (var @case in Cases)
        {
            yield return @case;
        }

        yield return CloseBraceToken;
    }
}

public sealed record EnumCaseSyntax(
    SyntaxToken Identifier,
    SyntaxToken? OpenParenToken,
    IReadOnlyList<EnumPayloadFieldSyntax> PayloadFields,
    SyntaxToken? CloseParenToken,
    SyntaxToken? CommaToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.EnumCase;

    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        if (OpenParenToken is not null)
        {
            yield return OpenParenToken;
        }

        foreach (var field in PayloadFields)
        {
            yield return field;
        }

        if (CloseParenToken is not null)
        {
            yield return CloseParenToken;
        }

        if (CommaToken is not null)
        {
            yield return CommaToken;
        }
    }
}

public sealed record EnumPayloadFieldSyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    SyntaxToken? CommaToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.EnumPayloadField;

    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        yield return ColonToken;
        yield return Type;
        if (CommaToken is not null)
        {
            yield return CommaToken;
        }
    }
}

public sealed record BlockStatementSyntax(
    SyntaxToken OpenBraceToken,
    IReadOnlyList<StatementSyntax> Statements,
    SyntaxToken CloseBraceToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.BlockStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBraceToken;
        foreach (var statement in Statements)
        {
            yield return statement;
        }

        yield return CloseBraceToken;
    }
}

public sealed record VariableDeclarationStatementSyntax(
    SyntaxToken Keyword,
    SyntaxToken Identifier,
    SyntaxToken? TypeColonToken,
    TypeSyntax? Type,
    SyntaxToken EqualsToken,
    ExpressionSyntax Initializer,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.VariableDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return Keyword;
        yield return Identifier;
        if (TypeColonToken is not null)
        {
            yield return TypeColonToken;
        }

        if (Type is not null)
        {
            yield return Type;
        }

        yield return EqualsToken;
        yield return Initializer;
        yield return SemicolonToken;
    }
}

/// <summary>
/// Immutable state owned by one Copeland component instance.  This is kept as
/// a statement (rather than a function modifier) so the ordinary lexical
/// scope continues to own the state name used by presentation expressions.
/// </summary>
public sealed record ComponentStateDeclarationStatementSyntax(
    SyntaxToken StateKeyword,
    SyntaxToken Identifier,
    SyntaxToken? TypeColonToken,
    TypeSyntax? Type,
    SyntaxToken EqualsToken,
    ExpressionSyntax Initializer,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ComponentStateDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return StateKeyword;
        yield return Identifier;
        if (TypeColonToken is not null) yield return TypeColonToken;
        if (Type is not null) yield return Type;
        yield return EqualsToken;
        yield return Initializer;
        yield return SemicolonToken;
    }
}

/// <summary>
/// A typed component-local event transition.  The fat-arrow body evaluates to
/// the next immutable state; it is not a renderer callback body.
/// </summary>
public sealed record ComponentEventHandlerStatementSyntax(
    SyntaxToken OnKeyword,
    SyntaxToken EventIdentifier,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken,
    SyntaxToken ArrowToken,
    ExpressionSyntax NextState,
    IReadOnlyList<ComponentEffectSyntax> Effects,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ComponentEventHandlerStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return OnKeyword;
        yield return EventIdentifier;
        yield return OpenParenToken;
        foreach (ParameterSyntax parameter in Parameters) yield return parameter;
        foreach (SyntaxToken comma in CommaTokens) yield return comma;
        yield return CloseParenToken;
        yield return ArrowToken;
        yield return NextState;
        foreach (ComponentEffectSyntax effect in Effects) yield return effect;
        yield return SemicolonToken;
    }
}

/// <summary>
/// A transition consequence. The grammar deliberately keeps effects adjacent
/// to the transition that requested them; they are not component hooks.
/// </summary>
public sealed record ComponentEffectSyntax(
    SyntaxToken? AfterKeyword,
    SyntaxToken? PhaseIdentifier,
    SyntaxToken EffectKeyword,
    ExpressionSyntax Invocation,
    SyntaxToken? CompletionArrowToken,
    SyntaxToken? CompletionEventIdentifier,
    SyntaxToken? CompletionOpenParenToken,
    IReadOnlyList<ExpressionSyntax> CompletionArguments,
    IReadOnlyList<SyntaxToken> CompletionCommaTokens,
    SyntaxToken? CompletionCloseParenToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.ComponentEffect;

    public override IEnumerable<object> GetChildren()
    {
        if (AfterKeyword is not null) yield return AfterKeyword;
        if (PhaseIdentifier is not null) yield return PhaseIdentifier;
        yield return EffectKeyword;
        yield return Invocation;
        if (CompletionArrowToken is not null) yield return CompletionArrowToken;
        if (CompletionEventIdentifier is not null) yield return CompletionEventIdentifier;
        if (CompletionOpenParenToken is not null) yield return CompletionOpenParenToken;
        foreach (ExpressionSyntax argument in CompletionArguments) yield return argument;
        foreach (SyntaxToken comma in CompletionCommaTokens) yield return comma;
        if (CompletionCloseParenToken is not null) yield return CompletionCloseParenToken;
    }
}

public sealed record ResourceUsingDeclarationStatementSyntax(
    SyntaxToken? AwaitKeyword,
    SyntaxToken UsingKeyword,
    SyntaxToken Identifier,
    SyntaxToken EqualsToken,
    ExpressionSyntax Initializer,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ResourceUsingDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        if (AwaitKeyword is not null)
        {
            yield return AwaitKeyword;
        }

        yield return UsingKeyword;
        yield return Identifier;
        yield return EqualsToken;
        yield return Initializer;
        yield return SemicolonToken;
    }
}

/// <summary>Module-level, compiler-owned event automaton declaration.</summary>
public sealed record FlowDeclarationSyntax(
    SyntaxToken FlowKeyword,
    SyntaxToken Identifier,
    SyntaxToken? ResultArrowToken,
    TypeSyntax? ResultType,
    SyntaxToken OpenBraceToken,
    FlowBoardSyntax? Board,
    IReadOnlyList<FlowEventSyntax> Events,
    IReadOnlyList<FlowStateSyntax> States,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public IReadOnlyList<ParameterSyntax> Parameters { get; init; } = [];
    public SyntaxToken? StackCapacityToken { get; init; }
    public bool IsExecution { get; init; }
    public FlowTapePlan? TapePlan { get; init; }
    public bool HasExecution => IsExecution || Parameters.Count > 0 || StackCapacityToken is not null || States.Any(state => state.Body is not null || state.Parameters.Count > 0);
    public override SyntaxKind Kind => SyntaxKind.FlowDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        yield return FlowKeyword; yield return Identifier;
        foreach (var parameter in Parameters) yield return parameter;
        if (ResultArrowToken is not null) yield return ResultArrowToken;
        if (ResultType is not null) yield return ResultType;
        yield return OpenBraceToken;
        if (StackCapacityToken is not null) yield return StackCapacityToken;
        if (Board is not null) yield return Board;
        foreach (var @event in Events) yield return @event;
        foreach (var state in States) yield return state;
        yield return CloseBraceToken;
    }
}

public sealed record FlowBoardSyntax(SyntaxToken BoardKeyword, SyntaxToken OpenBraceToken, IReadOnlyList<FlowBoardFieldSyntax> Fields, SyntaxToken CloseBraceToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.FlowBoard;
    public override IEnumerable<object> GetChildren()
    {
        yield return BoardKeyword; yield return OpenBraceToken;
        foreach (var field in Fields) yield return field;
        yield return CloseBraceToken;
    }
}

public sealed record FlowBoardFieldSyntax(SyntaxToken Identifier, SyntaxToken ColonToken, TypeSyntax? Type, SyntaxToken? EqualsToken, ExpressionSyntax? Initializer, SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.FlowBoardField;
    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier; yield return ColonToken;
        if (Type is not null) yield return Type;
        if (EqualsToken is not null) yield return EqualsToken;
        if (Initializer is not null) yield return Initializer;
        yield return SemicolonToken;
    }
}

public sealed record FlowEventSyntax(SyntaxToken EventKeyword, SyntaxToken Identifier, SyntaxToken OpenParenToken, IReadOnlyList<ParameterSyntax> Parameters, IReadOnlyList<SyntaxToken> CommaTokens, SyntaxToken CloseParenToken, SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.FlowEvent;
    public override IEnumerable<object> GetChildren()
    {
        yield return EventKeyword; yield return Identifier; yield return OpenParenToken;
        foreach (var parameter in Parameters) yield return parameter;
        foreach (var comma in CommaTokens) yield return comma;
        yield return CloseParenToken; yield return SemicolonToken;
    }
}

public sealed record FlowStateSyntax(SyntaxToken StateKeyword, SyntaxToken Identifier, SyntaxToken? InitialKeyword, SyntaxToken OpenBraceToken, IReadOnlyList<FlowTransitionSyntax> Transitions, FlowTerminalSyntax? Terminal, SyntaxToken CloseBraceToken) : SyntaxNode
{
    public IReadOnlyList<ParameterSyntax> Parameters { get; init; } = [];
    public BlockStatementSyntax? Body { get; init; }
    public override SyntaxKind Kind => SyntaxKind.FlowState;
    public override IEnumerable<object> GetChildren()
    {
        yield return StateKeyword; yield return Identifier;
        foreach (var parameter in Parameters) yield return parameter;
        if (InitialKeyword is not null) yield return InitialKeyword;
        yield return OpenBraceToken;
        foreach (var transition in Transitions) yield return transition;
        if (Terminal is not null) yield return Terminal;
        if (Body is not null) yield return Body;
        yield return CloseBraceToken;
    }
}

public sealed record FlowTransitionSyntax(SyntaxToken OnKeyword, SyntaxToken EventIdentifier, SyntaxToken OpenParenToken, IReadOnlyList<SyntaxToken> Bindings, IReadOnlyList<SyntaxToken> CommaTokens, SyntaxToken CloseParenToken, SyntaxToken? WhenKeyword, ExpressionSyntax? Guard, SyntaxToken ArrowToken, SyntaxToken TargetIdentifier, BlockStatementSyntax? Body, SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.FlowTransition;
    public override IEnumerable<object> GetChildren()
    {
        yield return OnKeyword; yield return EventIdentifier; yield return OpenParenToken;
        foreach (var binding in Bindings) yield return binding;
        foreach (var comma in CommaTokens) yield return comma;
        yield return CloseParenToken;
        if (WhenKeyword is not null) yield return WhenKeyword;
        if (Guard is not null) yield return Guard;
        yield return ArrowToken; yield return TargetIdentifier;
        if (Body is not null) yield return Body;
        yield return SemicolonToken;
    }
}

public sealed record FlowTerminalSyntax(SyntaxToken Keyword, ExpressionSyntax? Expression, SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => Keyword.Text == "finish" ? SyntaxKind.FlowFinish : SyntaxKind.FlowFail;
    public override IEnumerable<object> GetChildren() { yield return Keyword; if (Expression is not null) yield return Expression; yield return SemicolonToken; }
}

public sealed record FlowControlStatementSyntax(
    SyntaxToken Keyword,
    ExpressionSyntax? Value,
    SyntaxToken? SuccessTarget,
    SyntaxToken? FailureTarget,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.FlowControlStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return Keyword;
        if (Value is not null) yield return Value;
        if (SuccessTarget is not null) yield return SuccessTarget;
        if (FailureTarget is not null) yield return FailureTarget;
        yield return SemicolonToken;
    }
}

public sealed record CSharpBlockStatementSyntax(
    SyntaxToken CSharpKeyword,
    SyntaxToken OpenBraceToken,
    string BodyText,
    int BodyPosition,
    SyntaxToken CloseBraceToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.CSharpBlockStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return CSharpKeyword;
        yield return OpenBraceToken;
        yield return CloseBraceToken;
    }
}

public sealed record ExpressionStatementSyntax(
    ExpressionSyntax Expression,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ExpressionStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return Expression;
        yield return SemicolonToken;
    }
}

public sealed record IfStatementSyntax(
    SyntaxToken IfKeyword,
    SyntaxToken OpenParenToken,
    ExpressionSyntax Condition,
    SyntaxToken CloseParenToken,
    StatementSyntax ThenStatement,
    SyntaxToken? ElseKeyword,
    StatementSyntax? ElseStatement) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IfStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return IfKeyword;
        yield return OpenParenToken;
        yield return Condition;
        yield return CloseParenToken;
        yield return ThenStatement;

        if (ElseKeyword is not null)
        {
            yield return ElseKeyword;
        }

        if (ElseStatement is not null)
        {
            yield return ElseStatement;
        }
    }
}

public sealed record StaticIfStatementSyntax(
    SyntaxToken StaticKeyword,
    SyntaxToken IfKeyword,
    SyntaxToken OpenParenToken,
    ExpressionSyntax Condition,
    SyntaxToken CloseParenToken,
    StatementSyntax ThenStatement,
    SyntaxToken? ElseKeyword,
    StatementSyntax? ElseStatement) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StaticIfStatement;
    public override IEnumerable<object> GetChildren()
    {
        yield return StaticKeyword;
        yield return IfKeyword;
        yield return OpenParenToken;
        yield return Condition;
        yield return CloseParenToken;
        yield return ThenStatement;
        if (ElseKeyword is not null) yield return ElseKeyword;
        if (ElseStatement is not null) yield return ElseStatement;
    }
}

public sealed record StaticForStatementSyntax(
    SyntaxToken StaticKeyword,
    SyntaxToken ForKeyword,
    SyntaxToken OpenParenToken,
    SyntaxToken DeclarationKeyword,
    SyntaxToken Identifier,
    SyntaxToken OfKeyword,
    ExpressionSyntax Iterable,
    SyntaxToken CloseParenToken,
    StatementSyntax Body) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StaticForStatement;
    public override IEnumerable<object> GetChildren()
    {
        yield return StaticKeyword;
        yield return ForKeyword;
        yield return OpenParenToken;
        yield return DeclarationKeyword;
        yield return Identifier;
        yield return OfKeyword;
        yield return Iterable;
        yield return CloseParenToken;
        yield return Body;
    }
}

public sealed record StaticMatchArmSyntax(
    MatchPatternSyntax Pattern,
    SyntaxToken ArrowToken,
    StatementSyntax Statement,
    SyntaxToken? CommaToken,
    SyntaxToken? CaseKeyword = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.StaticMatchArm;
    public override IEnumerable<object> GetChildren()
    {
        if (CaseKeyword is not null) yield return CaseKeyword;
        yield return Pattern;
        yield return ArrowToken;
        yield return Statement;
        if (CommaToken is not null) yield return CommaToken;
    }
}

public sealed record StaticMatchStatementSyntax(
    SyntaxToken StaticKeyword,
    SyntaxToken MatchKeyword,
    ExpressionSyntax Expression,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<StaticMatchArmSyntax> Arms,
    SyntaxToken CloseBraceToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.StaticMatchStatement;
    public override IEnumerable<object> GetChildren()
    {
        yield return StaticKeyword;
        yield return MatchKeyword;
        yield return Expression;
        yield return OpenBraceToken;
        foreach (StaticMatchArmSyntax arm in Arms) yield return arm;
        yield return CloseBraceToken;
    }
}

public sealed record WhileStatementSyntax(
    SyntaxToken WhileKeyword,
    SyntaxToken OpenParenToken,
    ExpressionSyntax Condition,
    SyntaxToken CloseParenToken,
    StatementSyntax Body) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.WhileStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return WhileKeyword;
        yield return OpenParenToken;
        yield return Condition;
        yield return CloseParenToken;
        yield return Body;
    }
}

public sealed record ForStatementSyntax(
    SyntaxToken ForKeyword,
    SyntaxToken OpenParenToken,
    SyntaxNode? Initializer,
    SyntaxToken FirstSemicolonToken,
    ExpressionSyntax? Condition,
    SyntaxToken SecondSemicolonToken,
    ExpressionSyntax? Increment,
    SyntaxToken CloseParenToken,
    StatementSyntax Body) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ForStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return ForKeyword;
        yield return OpenParenToken;

        if (Initializer is not null)
        {
            yield return Initializer;
        }

        yield return FirstSemicolonToken;

        if (Condition is not null)
        {
            yield return Condition;
        }

        yield return SecondSemicolonToken;

        if (Increment is not null)
        {
            yield return Increment;
        }

        yield return CloseParenToken;
        yield return Body;
    }
}

public sealed record ForOfStatementSyntax(
    SyntaxToken ForKeyword,
    SyntaxToken OpenParenToken,
    SyntaxToken DeclarationKeyword,
    SyntaxToken Identifier,
    SyntaxToken OfKeyword,
    ExpressionSyntax Iterable,
    SyntaxToken CloseParenToken,
    StatementSyntax Body) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ForOfStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return ForKeyword;
        yield return OpenParenToken;
        yield return DeclarationKeyword;
        yield return Identifier;
        yield return OfKeyword;
        yield return Iterable;
        yield return CloseParenToken;
        yield return Body;
    }
}

public sealed record ReturnStatementSyntax(
    SyntaxToken ReturnKeyword,
    ExpressionSyntax? Expression,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ReturnStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return ReturnKeyword;
        if (Expression is not null)
        {
            yield return Expression;
        }

        yield return SemicolonToken;
    }
}

public sealed record YieldStatementSyntax(
    SyntaxToken YieldKeyword,
    SyntaxToken? ReturnKeyword,
    SyntaxToken? StarToken,
    SyntaxToken? BreakKeyword,
    ExpressionSyntax? Expression,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.YieldStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return YieldKeyword;
        if (ReturnKeyword is not null) yield return ReturnKeyword;
        if (StarToken is not null) yield return StarToken;
        if (BreakKeyword is not null) yield return BreakKeyword;
        if (Expression is not null) yield return Expression;
        yield return SemicolonToken;
    }
}

public sealed record NameExpressionSyntax(SyntaxToken IdentifierToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.NameExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return IdentifierToken;
    }
}

public sealed record LiteralExpressionSyntax(SyntaxToken LiteralToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LiteralExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return LiteralToken;
    }
}

public sealed record ParenthesizedExpressionSyntax(SyntaxToken OpenParenToken, ExpressionSyntax Expression, SyntaxToken CloseParenToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ParenthesizedExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenParenToken;
        yield return Expression;
        yield return CloseParenToken;
    }
}

public sealed record UnaryExpressionSyntax(SyntaxToken OperatorToken, ExpressionSyntax Operand) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.UnaryExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return OperatorToken;
        yield return Operand;
    }
}

public sealed record BinaryExpressionSyntax(ExpressionSyntax Left, SyntaxToken OperatorToken, ExpressionSyntax Right) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.BinaryExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Left;
        yield return OperatorToken;
        yield return Right;
    }
}

public sealed record AssignmentExpressionSyntax(ExpressionSyntax Left, SyntaxToken EqualsToken, ExpressionSyntax Right) : ExpressionSyntax
{
    public bool ReturnsPreviousValue { get; init; }

    public override SyntaxKind Kind => SyntaxKind.AssignmentExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Left;
        yield return EqualsToken;
        yield return Right;
    }
}

public sealed record CallExpressionSyntax(
    ExpressionSyntax Target,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ExpressionSyntax> Arguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.CallExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Target;
        yield return OpenParenToken;

        for (var i = 0; i < Arguments.Count; i++)
        {
            if (i > 0)
            {
                yield return CommaTokens[i - 1];
            }

            yield return Arguments[i];
        }

        yield return CloseParenToken;
    }
}

public sealed record NewExpressionSyntax(
    SyntaxToken NewKeyword,
    ExpressionSyntax Target,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ExpressionSyntax> Arguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken) : ExpressionSyntax
{
    public IReadOnlyList<TypeSyntax> TypeArguments { get; init; } = [];
    public override SyntaxKind Kind => SyntaxKind.NewExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return NewKeyword;
        yield return Target;
        yield return OpenParenToken;
        for (int index = 0; index < Arguments.Count; index++)
        {
            if (index > 0)
            {
                yield return CommaTokens[index - 1];
            }

            yield return Arguments[index];
        }

        yield return CloseParenToken;
    }
}

public sealed record MemberAccessExpressionSyntax(
    ExpressionSyntax Target,
    SyntaxToken DotToken,
    SyntaxToken NameToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.MemberAccessExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Target;
        yield return DotToken;
        yield return NameToken;
    }
}

public sealed record RepeatedInitializerSyntax(
    ExpressionSyntax Value,
    SyntaxToken EllipsisToken,
    ExpressionSyntax? Count) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.RepeatedInitializer;

    public override IEnumerable<object> GetChildren()
    {
        yield return Value;
        yield return EllipsisToken;
        if (Count is not null)
        {
            yield return Count;
        }
    }
}

public sealed record ArrayLiteralExpressionSyntax(
    SyntaxToken OpenBracketToken,
    IReadOnlyList<ExpressionSyntax> Elements,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseBracketToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ArrayLiteralExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBracketToken;

        for (var i = 0; i < Elements.Count; i++)
        {
            if (i > 0)
            {
                yield return CommaTokens[i - 1];
            }

            yield return Elements[i];
        }

        yield return CloseBracketToken;
    }
}

public sealed record PropagateExpressionSyntax(ExpressionSyntax Operand, SyntaxToken QuestionToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.PropagateExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Operand;
        yield return QuestionToken;
    }
}

public sealed record OptionalMemberAccessExpressionSyntax(
    ExpressionSyntax Target,
    SyntaxToken QuestionToken,
    SyntaxToken DotToken,
    SyntaxToken NameToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.OptionalMemberAccessExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Target;
        yield return QuestionToken;
        yield return DotToken;
        yield return NameToken;
    }
}

public sealed record CoalesceExpressionSyntax(
    ExpressionSyntax Left,
    SyntaxToken FirstQuestionToken,
    SyntaxToken SecondQuestionToken,
    ExpressionSyntax Right) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.CoalesceExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Left;
        yield return FirstQuestionToken;
        yield return SecondQuestionToken;
        yield return Right;
    }
}

public sealed record BatchExpressionSyntax(
    SyntaxToken BatchKeyword,
    ExpressionSyntax Input,
    SyntaxToken AsKeyword,
    SyntaxToken ItemIdentifier,
    BlockStatementSyntax Body) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.BatchExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return BatchKeyword;
        yield return Input;
        yield return AsKeyword;
        yield return ItemIdentifier;
        yield return Body;
    }
}

public sealed record GenericCallExpressionSyntax(
    ExpressionSyntax Target,
    SyntaxToken LessToken,
    IReadOnlyList<TypeSyntax> TypeArguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken GreaterToken,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ExpressionSyntax> Arguments,
    IReadOnlyList<SyntaxToken> ArgumentCommas,
    SyntaxToken CloseParenToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.GenericCallExpression;
    public override IEnumerable<object> GetChildren()
    {
        yield return Target;
        yield return LessToken;
        for (var i = 0; i < TypeArguments.Count; i++)
        {
            if (i > 0) yield return CommaTokens[i - 1];
            yield return TypeArguments[i];
        }
        yield return GreaterToken;
        yield return OpenParenToken;
        for (var i = 0; i < Arguments.Count; i++)
        {
            if (i > 0) yield return ArgumentCommas[i - 1];
            yield return Arguments[i];
        }
        yield return CloseParenToken;
    }
}

public sealed record GenericFunctionReferenceExpressionSyntax(
    ExpressionSyntax Target,
    SyntaxToken LessToken,
    IReadOnlyList<TypeSyntax> TypeArguments,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken GreaterToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.GenericFunctionReferenceExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Target;
        yield return LessToken;
        foreach (var argument in TypeArguments) yield return argument;
        foreach (var comma in CommaTokens) yield return comma;
        yield return GreaterToken;
    }
}

public sealed record BreakStatementSyntax(
    SyntaxToken BreakKeyword,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.BreakStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return BreakKeyword;
        yield return SemicolonToken;
    }
}

public sealed record ContinueStatementSyntax(
    SyntaxToken ContinueKeyword,
    SyntaxToken SemicolonToken) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ContinueStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return ContinueKeyword;
        yield return SemicolonToken;
    }
}

public sealed record IndexExpressionSyntax(ExpressionSyntax Target, SyntaxToken OpenBracketToken, ExpressionSyntax Index, SyntaxToken CloseBracketToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IndexExpression;
    public override IEnumerable<object> GetChildren() { yield return Target; yield return OpenBracketToken; yield return Index; yield return CloseBracketToken; }
}

public sealed record NestedRecordDeclarationStatementSyntax(RecordDeclarationSyntax Declaration) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.NestedRecordDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return Declaration;
    }
}

public sealed record NestedTableDeclarationStatementSyntax(TableDeclarationSyntax Declaration) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.NestedTableDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        yield return Declaration;
    }
}

/// <summary>
/// A layout or stream declared in an ordinary function body. The declaration is
/// semantically private to that lexical function; it is not a module member.
/// </summary>
public sealed record LocalPresentationDeclarationStatementSyntax(
    LayoutDeclarationSyntax? Layout,
    StreamDeclarationSyntax? Stream) : StatementSyntax
{
    public override SyntaxKind Kind => SyntaxKind.LocalPresentationDeclarationStatement;

    public override IEnumerable<object> GetChildren()
    {
        if (Layout is not null)
        {
            yield return Layout;
        }

        if (Stream is not null)
        {
            yield return Stream;
        }
    }
}

public sealed record RecordDeclarationSyntax(
    SyntaxToken? ConstKeyword,
    SyntaxToken RecordKeyword,
    SyntaxToken Identifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<RecordFieldSyntax> Fields,
    SyntaxToken CloseBraceToken,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : MemberSyntax
{
    public GenericParameterListSyntax? GenericParameters { get; init; }

    public override SyntaxKind Kind => SyntaxKind.RecordDeclaration;

    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        if (ConstKeyword is not null)
        {
            yield return ConstKeyword;
        }
        if (GenericParameters?.TemplateKeyword is not null)
        {
            yield return GenericParameters;
        }
        yield return RecordKeyword;
        yield return Identifier;
        if (GenericParameters is { TemplateKeyword: null }) yield return GenericParameters;
        yield return OpenBraceToken;
        foreach (var field in Fields)
        {
            yield return field;
        }
        yield return CloseBraceToken;
    }
}

public sealed record RecordFieldSyntax(
    SyntaxToken Identifier,
    SyntaxToken? QuestionToken,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    IReadOnlyList<SyntaxToken> UnsupportedTokens,
    SyntaxToken SemicolonToken,
    bool HasExplicitType,
    bool HasTerminator,
    IReadOnlyList<AnnotationSyntax>? Annotations = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.RecordField;

    public override IEnumerable<object> GetChildren()
    {
        foreach (AnnotationSyntax annotation in Annotations ?? []) yield return annotation;
        yield return Identifier;
        if (QuestionToken is not null)
        {
            yield return QuestionToken;
        }
        yield return ColonToken;
        yield return Type;
        foreach (var token in UnsupportedTokens)
        {
            yield return token;
        }
        yield return SemicolonToken;
    }
}

/// <summary>
/// The intentionally small class grammar. Class members are not general TypeScript
/// declarations: fields are immutable product slots and member functions are
/// associated functions with no receiver.
/// </summary>
public sealed record ClassDeclarationSyntax(
    SyntaxToken ClassKeyword,
    SyntaxToken Identifier,
    SyntaxToken? ExtendsKeyword,
    SyntaxToken? BaseTypeIdentifier,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<ClassMemberSyntax> Members,
    SyntaxToken CloseBraceToken) : MemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ClassDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        yield return ClassKeyword;
        yield return Identifier;
        if (ExtendsKeyword is not null) yield return ExtendsKeyword;
        if (BaseTypeIdentifier is not null) yield return BaseTypeIdentifier;
        yield return OpenBraceToken;
        foreach (var member in Members) yield return member;
        yield return CloseBraceToken;
    }
}

public abstract record ClassMemberSyntax : SyntaxNode
{
    public abstract SyntaxToken NameToken { get; }
}

public sealed record ClassFieldSyntax(
    SyntaxToken? VisibilityKeyword,
    IReadOnlyList<SyntaxToken> Modifiers,
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax Type,
    SyntaxToken? EqualsToken,
    ExpressionSyntax? Initializer,
    SyntaxToken SemicolonToken,
    bool HasExplicitType,
    bool HasTerminator) : ClassMemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ClassField;
    public override SyntaxToken NameToken => Identifier;
    public override IEnumerable<object> GetChildren()
    {
        if (VisibilityKeyword is not null) yield return VisibilityKeyword;
        foreach (var modifier in Modifiers) yield return modifier;
        yield return Identifier;
        yield return ColonToken;
        yield return Type;
        if (EqualsToken is not null) yield return EqualsToken;
        if (Initializer is not null) yield return Initializer;
        yield return SemicolonToken;
    }
}

public sealed record ClassConstructorDeclarationSyntax(
    SyntaxToken? VisibilityKeyword,
    IReadOnlyList<SyntaxToken> Modifiers,
    SyntaxToken ConstructorKeyword,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken,
    SyntaxToken? ReturnTypeColonToken,
    TypeSyntax? ReturnType,
    BlockStatementSyntax Body) : ClassMemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ClassConstructor;
    public override SyntaxToken NameToken => ConstructorKeyword;
    public override IEnumerable<object> GetChildren()
    {
        if (VisibilityKeyword is not null) yield return VisibilityKeyword;
        foreach (var modifier in Modifiers) yield return modifier;
        yield return ConstructorKeyword;
        yield return OpenParenToken;
        foreach (var parameter in Parameters) yield return parameter;
        foreach (var comma in CommaTokens) yield return comma;
        yield return CloseParenToken;
        if (ReturnTypeColonToken is not null) yield return ReturnTypeColonToken;
        if (ReturnType is not null) yield return ReturnType;
        yield return Body;
    }
}

public sealed record ClassAssociatedFunctionDeclarationSyntax(
    SyntaxToken? VisibilityKeyword,
    IReadOnlyList<SyntaxToken> Modifiers,
    SyntaxToken Identifier,
    SyntaxToken? LessToken,
    IReadOnlyList<TypeParameterSyntax> TypeParameters,
    IReadOnlyList<SyntaxToken> TypeParameterCommas,
    SyntaxToken? GreaterToken,
    SyntaxToken OpenParenToken,
    IReadOnlyList<ParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseParenToken,
    SyntaxToken? ReturnTypeColonToken,
    TypeSyntax? ReturnType,
    BlockStatementSyntax Body) : ClassMemberSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ClassAssociatedFunction;
    public override SyntaxToken NameToken => Identifier;
    public override IEnumerable<object> GetChildren()
    {
        if (VisibilityKeyword is not null) yield return VisibilityKeyword;
        foreach (var modifier in Modifiers) yield return modifier;
        yield return Identifier;
        if (LessToken is not null) yield return LessToken;
        foreach (var parameter in TypeParameters) yield return parameter;
        foreach (var comma in TypeParameterCommas) yield return comma;
        if (GreaterToken is not null) yield return GreaterToken;
        yield return OpenParenToken;
        foreach (var parameter in Parameters) yield return parameter;
        foreach (var comma in CommaTokens) yield return comma;
        yield return CloseParenToken;
        if (ReturnTypeColonToken is not null) yield return ReturnTypeColonToken;
        if (ReturnType is not null) yield return ReturnType;
        yield return Body;
    }
}

public sealed record TableAssetClauseSyntax(
    SyntaxToken FromToken,
    CallExpressionSyntax AssetCall) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TableAssetClause;

    public override IEnumerable<object> GetChildren()
    {
        yield return FromToken;
        yield return AssetCall;
    }
}

public sealed record TableColumnSyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax? ExplicitType,
    SyntaxToken? EqualsToken,
    ArrayLiteralExpressionSyntax Cells,
    SyntaxToken SemicolonToken,
    bool HasInlineData = true,
    SyntaxToken? KeyKeyword = null,
    SyntaxToken? ReferenceKeyword = null,
    SyntaxToken? ReferenceArrowToken = null,
    SyntaxToken? ReferencedTableIdentifier = null,
    SyntaxToken? ReferencedColumnIdentifier = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TableColumn;
    public override IEnumerable<object> GetChildren()
    {
        if (KeyKeyword is not null) yield return KeyKeyword;
        if (ReferenceKeyword is not null) yield return ReferenceKeyword;
        yield return Identifier; yield return ColonToken;
        if (ExplicitType is not null) yield return ExplicitType;
        if (ReferenceArrowToken is not null) yield return ReferenceArrowToken;
        if (ReferencedTableIdentifier is not null) yield return ReferencedTableIdentifier;
        if (ReferencedColumnIdentifier is not null) yield return ReferencedColumnIdentifier;
        if (EqualsToken is not null) yield return EqualsToken;
        if (HasInlineData) yield return Cells;
        yield return SemicolonToken;
    }
}

/// <summary>A single named scalar projection in a derived record table.</summary>
public sealed record DerivedTableColumnSyntax(
    SyntaxToken Identifier,
    SyntaxToken ColonToken,
    TypeSyntax? ExplicitType,
    SyntaxToken? EqualsToken,
    ExpressionSyntax Expression,
    SyntaxToken SemicolonToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TableColumn;
    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        yield return ColonToken;
        if (ExplicitType is not null) yield return ExplicitType;
        if (EqualsToken is not null) yield return EqualsToken;
        yield return Expression;
        yield return SemicolonToken;
    }
}

/// <summary>A relationship join in a derived record table.  The selected member
/// is a declared table reference; it is never an arbitrary predicate.</summary>
public sealed record DerivedTableJoinSyntax(
    SyntaxToken JoinKeyword,
    SyntaxToken RelationIdentifier,
    SyntaxToken AsKeyword,
    SyntaxToken AliasIdentifier,
    SyntaxToken ThroughKeyword,
    SyntaxToken ReferenceAliasIdentifier,
    SyntaxToken DotToken,
    SyntaxToken ReferenceColumnIdentifier) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TableDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        yield return JoinKeyword; yield return RelationIdentifier; yield return AsKeyword;
        yield return AliasIdentifier; yield return ThroughKeyword; yield return ReferenceAliasIdentifier;
        yield return DotToken; yield return ReferenceColumnIdentifier;
    }
}

/// <summary>Source plus ordered declared-reference joins and scalar projection syntax.</summary>
public sealed record DerivedTableClauseSyntax(
    SyntaxToken EqualsToken,
    SyntaxToken DeriveKeyword,
    SyntaxToken SourceIdentifier,
    SyntaxToken AsKeyword,
    SyntaxToken AliasIdentifier,
    IReadOnlyList<DerivedTableJoinSyntax> Joins,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<DerivedTableColumnSyntax> Columns,
    SyntaxToken CloseBraceToken) : SyntaxNode
{
    public IReadOnlyList<VariableDeclarationStatementSyntax> Locals { get; init; } = [];
    public override SyntaxKind Kind => SyntaxKind.TableDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        yield return EqualsToken; yield return DeriveKeyword; yield return SourceIdentifier;
        yield return AsKeyword; yield return AliasIdentifier;
        foreach (var join in Joins) yield return join;
        yield return OpenBraceToken;
        foreach (var local in Locals) yield return local;
        foreach (var column in Columns) yield return column;
        yield return CloseBraceToken;
    }
}

public sealed record TableDeclarationSyntax(
    SyntaxToken RecordKeyword,
    SyntaxToken TableKeyword,
    SyntaxToken Identifier,
    TableAssetClauseSyntax? AssetClause,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<TableColumnSyntax> Columns,
    SyntaxToken CloseBraceToken,
    bool IsExported,
    DerivedTableClauseSyntax? DerivedClause = null) : MemberSyntax
{
    public SyntaxToken? RowsEqualsToken { get; init; }
    public ArrayLiteralExpressionSyntax? RowsInitializer { get; init; }
    public SyntaxToken? RowsSemicolonToken { get; init; }
    public override SyntaxKind Kind => SyntaxKind.TableDeclaration;
    public override IEnumerable<object> GetChildren()
    {
        yield return RecordKeyword;
        yield return TableKeyword;
        yield return Identifier;
        if (AssetClause is not null)
        {
            yield return AssetClause;
        }
        if (DerivedClause is not null) yield return DerivedClause;
        else { yield return OpenBraceToken; foreach (var column in Columns) yield return column; yield return CloseBraceToken; }
        if (RowsInitializer is not null)
        {
            yield return RowsEqualsToken!;
            yield return RowsInitializer;
            yield return RowsSemicolonToken!;
        }
    }
}

public sealed record UnwrapExpressionSyntax(ExpressionSyntax Operand, SyntaxToken BangToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.UnwrapExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Operand;
        yield return BangToken;
    }
}

public sealed record AwaitExpressionSyntax(SyntaxToken AwaitKeyword, ExpressionSyntax Operand) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.AwaitExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return AwaitKeyword;
        yield return Operand;
    }
}

public sealed record ObjectPropertySyntax(
    SyntaxToken NameToken,
    SyntaxToken ColonToken,
    ExpressionSyntax ValueExpression) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.ObjectProperty;

    public override IEnumerable<object> GetChildren()
    {
        yield return NameToken;
        yield return ColonToken;
        yield return ValueExpression;
    }
}

public sealed record ObjectLiteralExpressionSyntax(
    SyntaxToken OpenBraceToken,
    IReadOnlyList<ObjectPropertySyntax> Properties,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseBraceToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ObjectLiteralExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBraceToken;

        for (var i = 0; i < Properties.Count; i++)
        {
            if (i > 0)
            {
                yield return CommaTokens[i - 1];
            }

            yield return Properties[i];
        }

        yield return CloseBraceToken;
    }
}


public sealed record IfExpressionSyntax(
    SyntaxToken IfKeyword,
    ExpressionSyntax Condition,
    SyntaxToken ThenOpenBraceToken,
    ExpressionSyntax ThenExpression,
    SyntaxToken ThenCloseBraceToken,
    SyntaxToken ElseKeyword,
    SyntaxToken ElseOpenBraceToken,
    ExpressionSyntax ElseExpression,
    SyntaxToken ElseCloseBraceToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.IfExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return IfKeyword;
        yield return Condition;
        yield return ThenOpenBraceToken;
        yield return ThenExpression;
        yield return ThenCloseBraceToken;
        yield return ElseKeyword;
        yield return ElseOpenBraceToken;
        yield return ElseExpression;
        yield return ElseCloseBraceToken;
    }
}

public sealed record WithExpressionSyntax(
    ExpressionSyntax Source,
    SyntaxToken WithKeyword,
    ObjectLiteralExpressionSyntax Replacements) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.WithExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Source;
        yield return WithKeyword;
        yield return Replacements;
    }
}

public sealed record TryValueBlockSyntax(
    SyntaxToken OpenBraceToken,
    IReadOnlyList<StatementSyntax> PrefixStatements,
    ExpressionSyntax ValueExpression,
    SyntaxToken CloseBraceToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TryValueBlock;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBraceToken;
        foreach (var statement in PrefixStatements)
        {
            yield return statement;
        }

        yield return ValueExpression;
        yield return CloseBraceToken;
    }
}

public sealed record TryExceptExpressionSyntax(
    SyntaxToken TryKeyword,
    TryValueBlockSyntax Protected,
    SyntaxToken ExceptKeyword,
    SyntaxToken OpenParenToken,
    SyntaxToken BindingIdentifier,
    SyntaxToken CloseParenToken,
    TryValueBlockSyntax Handler) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TryExceptExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return TryKeyword;
        yield return Protected;
        yield return ExceptKeyword;
        yield return OpenParenToken;
        yield return BindingIdentifier;
        yield return CloseParenToken;
        yield return Handler;
    }
}

public sealed record MatchPatternSyntax(
    SyntaxToken CaseIdentifier,
    SyntaxToken? OpenParenToken,
    IReadOnlyList<SyntaxToken> PayloadIdentifiers,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken? CloseParenToken,
    SyntaxToken? EnumQualifier = null,
    SyntaxToken? QualifierDot = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.MatchPattern;

    public override IEnumerable<object> GetChildren()
    {
        if (EnumQualifier is not null)
        {
            yield return EnumQualifier;
            yield return QualifierDot!;
        }
        yield return CaseIdentifier;
        if (OpenParenToken is not null)
        {
            yield return OpenParenToken;
        }

        for (var i = 0; i < PayloadIdentifiers.Count; i++)
        {
            if (i > 0)
            {
                yield return CommaTokens[i - 1];
            }

            yield return PayloadIdentifiers[i];
        }

        if (CloseParenToken is not null)
        {
            yield return CloseParenToken;
        }
    }
}

public sealed record MatchArmSyntax(
    MatchPatternSyntax Pattern,
    SyntaxToken ArrowToken,
    ExpressionSyntax Expression,
    SyntaxToken? CommaToken,
    SyntaxToken? CaseKeyword = null) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.MatchArm;

    public override IEnumerable<object> GetChildren()
    {
        if (CaseKeyword is not null) yield return CaseKeyword;
        yield return Pattern;
        yield return ArrowToken;
        yield return Expression;
        if (CommaToken is not null)
        {
            yield return CommaToken;
        }
    }
}

public sealed record MatchExpressionSyntax(
    SyntaxToken MatchKeyword,
    ExpressionSyntax Expression,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<MatchArmSyntax> Arms,
    SyntaxToken CloseBraceToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.MatchExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return MatchKeyword;
        yield return Expression;
        yield return OpenBraceToken;
        foreach (var arm in Arms)
        {
            yield return arm;
        }
        yield return CloseBraceToken;
    }
}

public sealed record MissingExpressionSyntax(SyntaxToken Token) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.MissingExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Token;
    }
}

public sealed record ArrowParameterSyntax(
    SyntaxToken Identifier,
    SyntaxToken? ColonToken,
    TypeSyntax? Type) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.ArrowParameter;
    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        if (ColonToken is not null) yield return ColonToken;
        if (Type is not null) yield return Type;
    }
}

public sealed record UnsupportedExpressionSyntax(SyntaxToken Token) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.UnsupportedExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Token;
    }
}

public sealed record ArrowExpressionSyntax(
    SyntaxToken? OpenParenToken,
    IReadOnlyList<ArrowParameterSyntax> Parameters,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken? CloseParenToken,
    SyntaxToken? ReturnColonToken,
    TypeSyntax? ReturnType,
    SyntaxToken ArrowToken,
    ExpressionSyntax? ExpressionBody,
    BlockStatementSyntax? BlockBody) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.ArrowExpression;
    public override IEnumerable<object> GetChildren()
    {
        if (OpenParenToken is not null) yield return OpenParenToken;
        for (var index = 0; index < Parameters.Count; index++)
        {
            if (index > 0) yield return CommaTokens[index - 1];
            yield return Parameters[index];
        }
        if (CloseParenToken is not null) yield return CloseParenToken;
        if (ReturnColonToken is not null) yield return ReturnColonToken;
        if (ReturnType is not null) yield return ReturnType;
        yield return ArrowToken;
        if (ExpressionBody is not null) yield return ExpressionBody;
        if (BlockBody is not null) yield return BlockBody;
    }
}

public sealed record CaptureExpressionSyntax(
    SyntaxToken CaptureKeyword,
    SyntaxToken OpenBraceToken,
    IReadOnlyList<CaptureEntrySyntax> Entries,
    IReadOnlyList<SyntaxToken> CommaTokens,
    SyntaxToken CloseBraceToken,
    ArrowExpressionSyntax Arrow) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.CaptureExpression;
    public IReadOnlyList<SyntaxToken> Identifiers => Entries.Select(entry => entry.Identifier).ToArray();
    public override IEnumerable<object> GetChildren()
    {
        yield return CaptureKeyword;
        yield return OpenBraceToken;
        for (var index = 0; index < Entries.Count; index++)
        {
            if (index > 0) yield return CommaTokens[index - 1];
            yield return Entries[index];
        }
        yield return CloseBraceToken;
        yield return Arrow;
    }
}

public sealed record CaptureEntrySyntax(
    SyntaxToken Identifier,
    SyntaxToken? ColonToken,
    ExpressionSyntax? Initializer) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.CaptureEntry;

    public override IEnumerable<object> GetChildren()
    {
        yield return Identifier;
        if (ColonToken is not null) yield return ColonToken;
        if (Initializer is not null) yield return Initializer;
    }
}

/// <summary>
/// A backend-neutral TS-XML element. Semantic profiles decide what an element means;
/// this syntax node deliberately does not imply a UI, component, or runtime model.
/// </summary>
public abstract record TsXmlExpressionSyntax : ExpressionSyntax;

/// <summary>
/// A payload-enum match arm used as a static child of a TSX Flow State.
/// Semantic profiles decide whether this otherwise inert syntax has meaning.
/// </summary>
public sealed record TsXmlFlowTransitionArmExpressionSyntax(
    MatchPatternSyntax Pattern,
    SyntaxToken? WhenToken,
    ExpressionSyntax? Guard,
    SyntaxToken ArrowToken,
    SyntaxToken TargetIdentifier,
    BlockStatementSyntax? Body) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlFlowTransitionArmExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return Pattern;
        if (WhenToken is not null) yield return WhenToken;
        if (Guard is not null) yield return Guard;
        yield return ArrowToken;
        yield return TargetIdentifier;
        if (Body is not null) yield return Body;
    }
}

/// <summary>
/// A language-owned source body in a static template.  The parser deliberately
/// keeps the body intact; the selected artifact language parses it later.
/// </summary>
public sealed record SourceCodeBlockExpressionSyntax(
    SyntaxToken CodeKeyword,
    SyntaxToken OpenBraceToken,
    string BodyText,
    int BodyPosition,
    SyntaxToken CloseBraceToken) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.SourceCodeBlockExpression;
    public override IEnumerable<object> GetChildren()
    {
        yield return CodeKeyword;
        yield return OpenBraceToken;
        yield return CloseBraceToken;
    }
}

public sealed record TsXmlElementExpressionSyntax(
    SyntaxToken LessToken,
    SyntaxToken NameToken,
    IReadOnlyList<TsXmlAttributeSyntax> Attributes,
    SyntaxToken? SlashToken,
    SyntaxToken OpenCloseToken,
    IReadOnlyList<TsXmlChildSyntax> Children,
    SyntaxToken? CloseLessToken,
    SyntaxToken? CloseSlashToken,
    SyntaxToken? CloseNameToken,
    SyntaxToken? CloseGreaterToken) : TsXmlExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlElementExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return LessToken;
        yield return NameToken;
        foreach (TsXmlAttributeSyntax attribute in Attributes)
        {
            yield return attribute;
        }

        if (SlashToken is not null)
        {
            yield return SlashToken;
        }

        yield return OpenCloseToken;
        foreach (TsXmlChildSyntax child in Children)
        {
            yield return child;
        }

        if (CloseLessToken is not null)
        {
            yield return CloseLessToken;
        }

        if (CloseSlashToken is not null)
        {
            yield return CloseSlashToken;
        }

        if (CloseNameToken is not null)
        {
            yield return CloseNameToken;
        }

        if (CloseGreaterToken is not null)
        {
            yield return CloseGreaterToken;
        }
    }
}

public sealed record TsXmlFragmentExpressionSyntax(
    SyntaxToken LessToken,
    SyntaxToken OpenCloseToken,
    IReadOnlyList<TsXmlChildSyntax> Children,
    SyntaxToken CloseLessToken,
    SyntaxToken CloseSlashToken,
    SyntaxToken CloseGreaterToken) : TsXmlExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlFragmentExpression;

    public override IEnumerable<object> GetChildren()
    {
        yield return LessToken;
        yield return OpenCloseToken;
        foreach (TsXmlChildSyntax child in Children)
        {
            yield return child;
        }

        yield return CloseLessToken;
        yield return CloseSlashToken;
        yield return CloseGreaterToken;
    }
}

public sealed record TsXmlAttributeSyntax(
    SyntaxToken NameToken,
    SyntaxToken? EqualsToken,
    SyntaxToken? StringValueToken,
    SyntaxToken? OpenBraceToken,
    ExpressionSyntax? ExpressionValue,
    SyntaxToken? CloseBraceToken) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlAttribute;

    public override IEnumerable<object> GetChildren()
    {
        yield return NameToken;
        if (EqualsToken is not null)
        {
            yield return EqualsToken;
        }

        if (StringValueToken is not null)
        {
            yield return StringValueToken;
        }

        if (OpenBraceToken is not null)
        {
            yield return OpenBraceToken;
        }

        if (ExpressionValue is not null)
        {
            yield return ExpressionValue;
        }

        if (CloseBraceToken is not null)
        {
            yield return CloseBraceToken;
        }
    }
}

public abstract record TsXmlChildSyntax : SyntaxNode;

public sealed record TsXmlTextSyntax(SyntaxToken TextToken) : TsXmlChildSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlText;

    public override IEnumerable<object> GetChildren()
    {
        yield return TextToken;
    }
}

public sealed record TsXmlExpressionChildSyntax(
    SyntaxToken OpenBraceToken,
    ExpressionSyntax Expression,
    SyntaxToken CloseBraceToken) : TsXmlChildSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlExpressionChild;

    public override IEnumerable<object> GetChildren()
    {
        yield return OpenBraceToken;
        yield return Expression;
        yield return CloseBraceToken;
    }
}

public sealed record TsXmlElementChildSyntax(TsXmlExpressionSyntax Element) : TsXmlChildSyntax
{
    public override SyntaxKind Kind => SyntaxKind.TsXmlElementChild;

    public override IEnumerable<object> GetChildren()
    {
        yield return Element;
    }
}

/// <summary>One-shot guarded utility choice. GPU scores are explicitly u32.</summary>
public sealed record WhenUtilityExpressionSyntax(
    SyntaxToken WhenToken, SyntaxToken UtilityToken, SyntaxToken OpenBrace,
    IReadOnlyList<UtilityCaseSyntax> Cases, SyntaxToken ElseToken,
    ExpressionSyntax Fallback, SyntaxToken CloseBrace) : ExpressionSyntax
{
    public override SyntaxKind Kind => SyntaxKind.WhenUtilityExpression;
    public override IEnumerable<object> GetChildren()
    {
        yield return WhenToken;
        yield return UtilityToken;
        yield return OpenBrace;
        foreach (var candidate in Cases) yield return candidate;
        yield return ElseToken;
        yield return Fallback;
        yield return CloseBrace;
    }
}

public sealed record UtilityCaseSyntax(
    SyntaxToken CaseToken, ExpressionSyntax Value, SyntaxToken WhenToken,
    ExpressionSyntax Condition, SyntaxToken ScoreToken, ExpressionSyntax Score) : SyntaxNode
{
    public override SyntaxKind Kind => SyntaxKind.UtilityCase;
    public override IEnumerable<object> GetChildren()
    {
        yield return CaseToken;
        yield return Value;
        yield return WhenToken;
        yield return Condition;
        yield return ScoreToken;
        yield return Score;
    }
}
