# X1 structural shadow specimens

These are source syntax evidence, not manufacturing examples or proof of semantic
admission. Nested Set and synthetic unrelated siblings deliberately exercise
structure independently of the production routes. The existing FrontendX0
specimens remain the authority for the two known production intent-loss witnesses.

`lexical` preserves trivia and spelling; `expressions` fixes structural precedence;
`nested-generics` fixes balanced parameter/argument structure; `malformed-field`
requires rejection and recovery into the next declaration. The four `unrelated-*`
files are inserted into a Model by metamorphic tests. No production migration is
enabled by these specimens.

`slot-route-perturbation` is a real production admission witness: removing the
unconsumed Slot2 sibling builds the hole plate on Canonical; including it selects
CanonicalAdvanced and rejects the document. Shadow preserves all original
subtrees. The Slot2 fields deliberately retain its owner's admitted PascalCase.
