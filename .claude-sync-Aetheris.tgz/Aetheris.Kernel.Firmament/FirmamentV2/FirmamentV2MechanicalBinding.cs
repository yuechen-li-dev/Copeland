using Aetheris.Kernel.Firmament.FirmamentV2.Syntax;

namespace Aetheris.Kernel.Firmament.FirmamentV2;

public static partial class FirmamentV2Parser
{
    private static IEnumerable<DeclarationSyntax> MechanicalDeclarations(IEnumerable<StatementSyntax> statements)
    {
        foreach (var declaration in statements.OfType<DeclarationSyntax>())
        {
            if (declaration.Modifiers.Any(m => m.Name.Text == "Template") || declaration.Type.Name.Text == "Template") continue;
            yield return declaration;
            if (declaration.Type.Name.Text == "Struct" && !declaration.Modifiers.Any(m => m.Name.Text == "Concept"))
                foreach (var child in MechanicalDeclarations(declaration.Body?.Statements ?? [])) yield return child;
        }
    }

    private static bool IsPrimitiveDeclaration(DeclarationSyntax d) => d.Type.Name.Text is
        "Box" or "Cylinder" or "Cone" or "Sphere" or "Torus" or "RoundedBox" or "Frustum" or "StandardPart" or "ExactCoaxialPart";

    /// <summary>Mechanical syntax has one owner. Selection of a material lowerer
    /// follows declared material bodies; unused construction data cannot select a grammar.</summary>
    private static FirmamentV2ParseResult BindMechanicalModel(DocumentSyntax syntax, DeclarationSyntax model,
        string source, List<string> diagnostics, string? sourceDirectory,
        IReadOnlyList<ConceptIrTemplateInstantiation>? templateInstantiations)
    {
        if (model.Body is null || model.Name is null) return CanonicalFailure(diagnostics, CanonicalDocumentMalformed);
        if (model.Annotation is not null)
            return ParseConceptModelingDocument(source, diagnostics, templateInstantiations);
        BindMechanicalScope(model.Body.Statements, diagnostics);
        if (diagnostics.Any(IsFatalDiagnosticCode)) return CanonicalFailure(diagnostics, CanonicalDocumentMalformed);
        var declarations = MechanicalDeclarations(model.Body.Statements).ToArray();
        var primitives = declarations.Where(IsPrimitiveDeclaration).ToArray();
        var materialConstruction = declarations.Any(d => d.Type.Name.Text is "Compose" or "Extrude");
        // Concept-valued stock and named construction policies retain their existing
        // engineering binders. They do not change the grammar of neighbouring nodes.
        var semanticStock = declarations.Any(d => d.Type.Name.Text == "Modify" && d.Body?.Statements.OfType<DeclarationSyntax>().Any(f => f.Type.Name.Text == "Pattern") == true)
            || declarations.Any(d => d.Type.Name.Text == "Struct" && d.Annotation is not null)
            || declarations.Where(d => d.Type.Name.Text == "Modify").SelectMany(d => d.Body?.Statements.OfType<DeclarationSyntax>() ?? [])
                .Any(d => d.Type.Name.Text == "Hole" && d.Body?.Statements.OfType<FieldSyntax>().Any(f => f.Name.Text == "From" || f.Name.Text == "On" && FirmamentSyntaxValues.Reference(f.Value) is not ("+X" or "-X" or "+Y" or "-Y" or "+Z" or "-Z")) == true);
        if (materialConstruction || semanticStock || primitives.Any(d => d.Body?.Statements.OfType<FieldSyntax>().Any(f => FirmamentSyntaxFields.SameField(f.Name.Text, "Bounds")) == true))
            return BindMechanicalConstruction(source, model, diagnostics, templateInstantiations);

        var units = model.Body.Statements.OfType<FieldSyntax>().Where(f => FirmamentSyntaxFields.SameField(f.Name.Text, "Units")).ToArray();
        if (units.Length == 0 && model.Type.Name.Text != "Struct" || units.Any(f => FirmamentSyntaxValues.Reference(f.Value) != "mm")) return CanonicalFailure(diagnostics, CanonicalUnitsInvalid);
        var solids = new Dictionary<string, FirmamentV2SolidBinding>(StringComparer.Ordinal);
        foreach (var declaration in primitives)
        {
            var fields = new FirmamentSyntaxFields(declaration, diagnostics);
            var primitive = BindMechanicalPrimitive(fields, diagnostics);
            FirmamentV2HollowIntent? hollow = null;
            if (declaration.Type.Arguments.Count > 0)
                hollow = BindMechanicalHollow(fields, primitive, diagnostics);
            fields.Complete();
            if (primitive is null) { diagnostics.Add(CanonicalPrimitiveMalformed); continue; }
            if (declaration.Name is null || !solids.TryAdd(declaration.Name.Text, new(declaration.Name.Text,
                declaration.Type.Name.Text, primitive, ConstructionPolicy: hollow is null ? FirmamentV2ConstructionPolicy.Solid : FirmamentV2ConstructionPolicy.Hollow, Hollow: hollow, SourceSpan: declaration.Span, AuthoredFields: fields.AuthoredFields))) diagnostics.Add(DuplicateName);
        }
        foreach (var declaration in declarations.Where(d => d.Type.Name.Text == "InlineStep"))
        {
            var body = declaration.Body;
            if (body is null || declaration.Name is null) { diagnostics.Add(CanonicalPrimitiveMalformed); continue; }
            var imported = ParseInlineStep(declaration.Name.Text, source.Substring(body.Span.Start + 1, body.Span.Length - 2), diagnostics, sourceDirectory);
            if (imported is not null && !solids.TryAdd(imported.Name, imported)) diagnostics.Add(DuplicateName);
        }
        if (solids.Count == 0) diagnostics.Add(MissingSolid);
        var modifies = new List<FirmamentV2ModifyBlock>();
        foreach (var modify in declarations.Where(d => d.Type.Name.Text == "Modify"))
        {
            if (modify.Name is null || !solids.TryGetValue(modify.Name.Text, out var solid)) { diagnostics.Add(ModifyTargetUnresolved); continue; }
            var holes = new List<FirmamentV2SemanticHoleDecl>(); var finishes = new List<FirmamentV2EdgeFinishDecl>(); var perforations = new List<FirmamentV2PerforationDecl>();
            foreach (var statement in modify.Body?.Statements ?? [])
            {
                if (statement is not DeclarationSyntax feature) { diagnostics.Add(CanonicalModifyMalformed); continue; }
                var fields = new FirmamentSyntaxFields(feature, diagnostics);
                switch (feature.Type.Name.Text)
                {
                    case "Hole":
                        if (BindMechanicalHole(fields, diagnostics) is { } hole) holes.Add(hole);
                        break;
                    case "EdgeFinish":
                        if (BindMechanicalFinish(fields, diagnostics) is { } finish) finishes.Add(finish);
                        break;
                    case "Perforation":
                        if (BindMechanicalPerforation(fields, diagnostics) is { } perforation) perforations.Add(perforation);
                        break;
                    default: diagnostics.Add($"{CanonicalDeclarationUnknown}:Modify:{feature.Type.Name.Text}"); break;
                }
                fields.Complete();
            }
            if (holes.Count > 0 && solid.Box is null) diagnostics.Add(ModifyTargetNotSolid);
            if (solid.ConstructionPolicy == FirmamentV2ConstructionPolicy.Hollow &&
                (solid.Cylinder is null || holes.Count > 0 || finishes.Count > 0 || perforations.Count != 1 ||
                 perforations.Any(p => p.SupportFace != "OuterWall" || p.Layout is not ("CylindricalGrid" or "CylindricalStaggered"))))
                diagnostics.Add("firmament-v2-hollow-modify-unsupported");
            modifies.Add(new(solid.Name, [], holes, finishes, perforations));
        }
        var bodyText = source.Substring(model.Body.Span.Start + 1, model.Body.Span.Length - 2);
        var recognized = ParseCanonicalRecognizedRegions(bodyText, solids, diagnostics);
        var replacements = ParseCanonicalReplacements(bodyText, solids, recognized, diagnostics);
        var selections = ParseCanonicalSelections(bodyText, model.Body.Span.Start + 1, diagnostics);
        ValidateCanonicalSelectionSources(bodyText, selections, [], diagnostics);
        var (pmi, pmiBlock, boundPmi) = ParsePmi(source, solids, modifies, recognized, [], [], diagnostics);
        if (diagnostics.Any(IsFatalDiagnosticCode)) return CanonicalFailure(diagnostics, CanonicalDocumentMalformed);
        return FirmamentV2ParseResult.Success(new(model.Name.Text, "mm", solids.Values.ToArray(), modifies,
            Pmi: pmi, RecognizedRegions: recognized, Replacements: replacements, PmiBlock: pmiBlock, BoundPmi: boundPmi, Selections: selections),
            diagnostics.Append("firmament-v2-unified-canonical-parsed").Append("firmament-v2-parse-succeeded").Distinct(StringComparer.Ordinal).Order().ToArray());
    }

    private static FirmamentV2HollowIntent? BindMechanicalHollow(FirmamentSyntaxFields f, FirmamentV2PrimitiveRecord? primitive, List<string> diagnostics)
    {
        var d = f.Declaration;
        if (d.Type.Arguments.Count != 1 || FirmamentSyntaxValues.Reference(d.Type.Arguments[0].Value) != "Hollow")
        { diagnostics.Add(UnknownConstructionPolicy); return null; }
        if (d.Type.Name.Text is not ("RoundedBox" or "Cylinder" or "Frustum"))
        { diagnostics.Add(PrimitiveDoesNotSatisfyHollowConstructible); return null; }
        var wallExpression = f.Take("WallThickness");
        if (wallExpression is null) diagnostics.Add(WallThicknessRequired);
        var wall = FirmamentSyntaxValues.TryMeasure(wallExpression, "mm", out var w) ? w : double.NaN;
        if (!(wall > 0)) diagnostics.Add(WallThicknessMustBePositive);
        var openings = f.Take("Openings") as SequenceSyntax;
        var items = openings?.Items.Select(a => FirmamentSyntaxValues.Reference(a.Value)).ToArray() ?? [];
        if (items.Length != 1 || items[0] != "Top") diagnostics.Add(items.Length > 1 ? MultipleOpeningsNotSupported : UnsupportedOpening);
        var blendExpression = f.Take("BottomBlendRadius");
        var blend = blendExpression is null ? 0 : FirmamentSyntaxValues.TryMeasure(blendExpression, "mm", out var b) ? b : double.NaN;
        if (blendExpression is not null && (primitive is not FirmamentV2CylinderRecord cylinder || !(blend > wall && blend < cylinder.Radius && blend < cylinder.Height)))
            diagnostics.Add("firmament-v2-hollow-bottom-blend-invalid");
        return new(wall, items.OfType<string>().ToArray(), d.Span, blend);
    }

    private static FirmamentV2PrimitiveRecord? BindMechanicalPrimitive(FirmamentSyntaxFields f, List<string> diagnostics)
    {
        var type = f.Declaration.Type.Name.Text;
        double Length(string name) => f.Number(name, "mm");
        double[]? Size() => f.Vector("Size", "mm", out var values) && values.Length == 3 && values.All(v => v > 0) ? values : null;
        switch (type)
        {
            case "Box": return Size() is { } box ? new FirmamentV2BoxRecord(box, []) : null;
            case "Cylinder":
                var radius = Length("Radius"); var height = Length("Height");
                return radius > 0 && height > 0 ? new FirmamentV2CylinderRecord(radius, height) : null;
            case "Cone":
                var bottom = Length("BottomRadius"); var top = Length("TopRadius"); var coneHeight = Length("Height");
                return bottom > 0 && top >= 0 && coneHeight > 0 ? new FirmamentV2ConeRecord(bottom, top, coneHeight) : null;
            case "Sphere": var sphere = Length("Radius"); return sphere > 0 ? new FirmamentV2SphereRecord(sphere) : null;
            case "Torus":
                var major = Length("MajorRadius"); var minor = Length("MinorRadius");
                return major > minor && minor > 0 ? new FirmamentV2TorusRecord(major, minor) : null;
            case "RoundedBox":
                var size = Size(); var corner = Length("CornerRadius");
                return size is not null && corner > 0 && corner < Math.Min(size[0], size[1]) / 2 ? new FirmamentV2RoundedBoxRecord(size, corner) : null;
            case "Frustum":
                var low = Length("BottomRadius"); var high = Length("TopRadius"); var h = Length("Height");
                return low > 0 && high > 0 && h > 0 && Math.Abs(low - high) > 1e-12 ? new FirmamentV2FrustumRecord(low, high, h) : null;
            // These recipe binders own family-specific field schemas. Their input
            // is admitted through their existing typed recipe authority below.
            case "StandardPart":
                var family = f.Word("Family");
                if (family is null) return null;
                return new FirmamentV2StandardPartRecord(family, RecipeFields(f));
            case "ExactCoaxialPart": return new FirmamentV2ExactCoaxialPartRecord(RecipeFields(f));
            default: return null;
        }
    }

    private static Dictionary<string, string> RecipeFields(FirmamentSyntaxFields f)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var field in f.Declaration.Body?.Statements.OfType<FieldSyntax>() ?? [])
        {
            var value = f.Take(field.Name.Text);
            if (field.Name.Text == "Family") continue;
            result[field.Name.Text] = value switch
            {
                LiteralSyntax literal => literal.Raw,
                QuantitySyntax { Value: LiteralSyntax literal } q => literal.Raw + q.Unit.Text,
                _ => FirmamentSyntaxValues.Reference(value) ?? ""
            };
        }
        return result;
    }

    private static FirmamentV2SemanticHoleDecl? BindMechanicalHole(FirmamentSyntaxFields f, List<string> diagnostics)
    {
        var d = f.Declaration;
        var variantName = d.Type.Arguments.Count == 1 ? FirmamentSyntaxValues.Reference(d.Type.Arguments[0].Value) : null;
        if (!Enum.TryParse<FirmamentV2SemanticHoleVariant>(variantName, out var variant)) { diagnostics.Add(HoleVariantUnknown); return null; }
        var axis = f.Word("On"); var point = f.Take("Center"); var diameter = f.Number("Diameter", "mm");
        var endExpression = f.Take("End"); var end = FirmamentSyntaxValues.Reference(endExpression);
        f.Take("PatternIdentity");
        FirmamentV2SemanticHoleEnd? termination = end == "ThroughAll" ? new(FirmamentV2SemanticHoleEndKind.ThroughAll) : null;
        if (endExpression is CallSyntax { Target: ReferenceSyntax { Name.Text: "Blind" }, Arguments.Count: 1 } blind
            && FirmamentSyntaxValues.TryMeasure(blind.Arguments[0].Value, "mm", out var depth) && depth > 0) termination = new(FirmamentV2SemanticHoleEndKind.Depth, depth);
        double? cbDiameter = null, cbDepth = null, csDiameter = null, csAngle = null;
        if (variant == FirmamentV2SemanticHoleVariant.Counterbore) { cbDiameter = f.Number("CounterboreDiameter", "mm"); cbDepth = f.Number("CounterboreDepth", "mm"); }
        if (variant == FirmamentV2SemanticHoleVariant.Countersink) { csDiameter = f.Number("CountersinkDiameter", "mm"); csAngle = f.Number("CountersinkAngle", "deg"); }
        if (point is not CallSyntax { Target: ReferenceSyntax { Name.Text: "Point2" } } || !FirmamentSyntaxValues.Vector(point, "mm", out var center) || center.Length != 2) { diagnostics.Add(CanonicalPoint2Invalid); return null; }
        if (axis is not ("+X" or "-X" or "+Y" or "-Y" or "+Z" or "-Z") || termination is null || d.Name is null) { diagnostics.Add(CanonicalModifyMalformed); return null; }
        if (!(diameter > 0)) { diagnostics.Add(HoleDiameterInvalid); return null; }
        if (cbDiameter is not null && (!(cbDiameter > diameter) || !(cbDepth > 0))) { diagnostics.Add(HoleCounterboreInvalid); return null; }
        if (csDiameter is not null && (!(csDiameter > diameter) || !(csAngle > 0 && csAngle < 180))) { diagnostics.Add(HoleCountersinkInvalid); return null; }
        var face = FirmamentV2FaceTarget.Direct(axis);
        return new(d.Name.Text, variant, face, new(center[0], center[1], FirmamentV2FaceLocalPoint2D.ConventionFor(axis)), diameter, termination,
            cbDiameter, cbDepth, csDiameter, csAngle, SourceSpan: d.Span, AuthoredFields: f.AuthoredFields);
    }

    private static FirmamentV2EdgeFinishDecl? BindMechanicalFinish(FirmamentSyntaxFields f, List<string> diagnostics)
    {
        if (f.Declaration.Type.Arguments.Count != 0) { diagnostics.Add(CanonicalModifyMalformed); return null; }
        var axis = f.Word("Face"); var target = f.Word("Target"); var kind = f.Word("Kind");
        var distance = f.Take("Distance"); var radius = f.Take("Radius");
        if ((distance is not null && radius is not null) || f.Declaration.Name is null || axis is null || target is null || kind is null
            || !FirmamentSyntaxValues.TryMeasure(distance ?? radius, "mm", out var value) || value <= 0)
        { diagnostics.Add(CanonicalModifyMalformed); return null; }
        return new(f.Declaration.Name.Text, axis, target, kind, value, f.Declaration.Span);
    }

    private static FirmamentV2PerforationDecl? BindMechanicalPerforation(FirmamentSyntaxFields f, List<string> diagnostics)
    {
        var on = f.Word("On"); var layout = f.Word("Layout");
        var diameter = f.Number("Diameter", "mm"); var pitch = f.Number("Pitch", "mm");
        var margin = f.Number("Margin", "mm", 0); var ligament = f.Number("MinimumLigament", "mm", 0);
        var offsetX = f.Number("OffsetX", "mm", 0); var offsetY = f.Number("OffsetY", "mm", 0);
        var circumferential = f.Number("CircumferentialPitch", "mm");
        var top = f.Number("MarginTop", "mm"); var bottom = f.Number("MarginBottom", "mm"); var angle = f.Number("StartAngle", "deg", 0);
        if (on is null || layout is null || !(diameter > 0 && pitch > 0 && margin >= 0 && ligament >= 0) || f.Declaration.Name is null)
        { diagnostics.Add("perforation-field-invalid"); return null; }
        return new(f.Declaration.Name.Text, on, layout, diameter, pitch, margin, ligament, offsetX, offsetY, f.Declaration.Span,
            double.IsNaN(circumferential) ? null : circumferential, double.IsNaN(top) ? null : top, double.IsNaN(bottom) ? null : bottom, angle);
    }

    private static void BindMechanicalScope(IReadOnlyList<StatementSyntax> statements, List<string> diagnostics)
    {
        foreach (var statement in statements)
        {
            if (statement is FieldSyntax field)
            {
                if (!FirmamentSyntaxFields.SameField(field.Name.Text, "Units") && !FirmamentSyntaxFields.SameField(field.Name.Text, "Material"))
                    diagnostics.Add($"{CanonicalFieldUnknown}:Model:{field.Name.Text}");
                continue;
            }
            if (statement is not DeclarationSyntax declaration)
            {
                diagnostics.Add(CanonicalDeclarationUnrecognized); continue;
            }
            if (declaration.Modifiers.Any(m => m.Name.Text == "Assert")) continue;
            switch (declaration.Type.Name.Text)
            {
                case "Struct" when declaration.Annotation is not null: break;
                case "Struct" when !declaration.Modifiers.Any(m => m.Name.Text == "Concept"):
                    BindMechanicalScope(declaration.Body?.Statements ?? [], diagnostics); break;
                case "Box" or "Cylinder" or "Cone" or "Sphere" or "Torus" or "RoundedBox" or "Frustum" or "StandardPart" or "ExactCoaxialPart":
                case "Plane" or "Axis" or "Axis2" or "Point2" or "Line2" or "CubicBezier2" or "Rect2" or "Square2" or "Triangle2" or "Polygon2" or "RegularPolygon2" or "Circle2" or "Ellipse2" or "Ellipse2Guide" or "Slot2" or "RoundedRect2" or "SmoothRoundedRect2" or "Path":
                case "Plateau" or "Concept" or "Struct" or "Profile" or "Span" or "Compose" or "Boss" or "Pocket" or "AddOffset" or "RemoveOffset" or "EdgeFinish" or "Extrude":
                case "Expose" or "Record" or "Static" or "Template" or "template" or "Feature" or "ProfileDelta" or "Selection" or "InlineStep" or "Recognize" or "Replace" or "Pmi" or "Modify" or "Match" or "Require" or "Assert" or "Thread":
                    break;
                case "Solid": diagnostics.Add(CanonicalConstructNotYetSupported + ":Solid"); break;
                default: diagnostics.Add(CanonicalDeclarationUnrecognized); diagnostics.Add($"{CanonicalDeclarationUnknown}:{declaration.Type.Name.Text}"); break;
            }
        }
    }
}
