using System.Text;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Diagnostics;
using Aetheris.Kernel.Core.Air;
using Aetheris.Kernel.Core.Results;
using Aetheris.Kernel.Core.Diagnostics;
using Aetheris.Kernel.Core.Step242;
using Aetheris.Kernel.Core.Brep;
using Aetheris.Kernel.Core.Brep.Verification;
using Aetheris.Kernel.Core.Brep.Boolean;
using Aetheris.Kernel.Core.Brep.Features;
using Aetheris.Kernel.Core.Geometry;
using Aetheris.Kernel.Core.Geometry.Curves;
using Aetheris.Kernel.Core.Geometry.Surfaces;
using Aetheris.Kernel.Core.Math;
using Aetheris.Kernel.Core.Numerics;
using Aetheris.Kernel.Core.Topology;
using Aetheris.Kernel.Firmament.Execution;
using Aetheris.Kernel.Firmament.Lowering;
using Aetheris.Kernel.Firmament.FirmamentV2;
using Aetheris.Kernel.Firmament.Materializer;
using Aetheris.Kernel.StandardLibrary;
using Aetheris.Kernel.Firmament.Structural;
using Aetheris.Kernel.Firmament.Piping;

namespace Aetheris.Kernel.Firmament;

public static class FirmamentBuildAndExport
{
    public const string EdgeFinishProfileComposeBoundaryUnsupported = "EdgeFinishProfileComposeBoundaryUnsupported";
    private enum ExportRouteDisposition { Declined, Failed, Succeeded }
    private sealed record ExportRouteResult(string Route, ExportRouteDisposition Disposition, KernelResult<FirmamentStepExportResult>? Artifact = null)
    {
        public static ExportRouteResult Decline(string route) => new(route, ExportRouteDisposition.Declined);
        public static ExportRouteResult Complete(string route, KernelResult<FirmamentStepExportResult> artifact) => new(route, artifact.IsSuccess ? ExportRouteDisposition.Succeeded : ExportRouteDisposition.Failed, artifact);
    }

    public static KernelResult<FirmamentBuildAndExportResult> Run(string sourcePath, string? outputPath = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(sourcePath);

        var fullSourcePath = Path.GetFullPath(sourcePath);
        var sourceText = NormalizeLf(File.ReadAllText(fullSourcePath, Encoding.UTF8));
        var frontend = FirmamentFrontendSchemas.Select(sourceText);
        if (!frontend.IsSuccess) return KernelResult<FirmamentBuildAndExportResult>.Failure(frontend.Diagnostics.Select(SchemaDiagnostic).ToArray());
        sourceText = frontend.Source;
        if (PipingAuthoring.IsPipingSource(sourceText))
        {
            var piping = PipingAuthoring.Compile(sourceText, fullSourcePath);
            if (!piping.IsSuccess || piping.StepText is null || piping.Report is null)
                return KernelResult<FirmamentBuildAndExportResult>.Failure(piping.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "Piping.X3")).ToArray());
            var pipingOutputPath = string.IsNullOrWhiteSpace(outputPath) ? ResolveDefaultOutputPath(fullSourcePath) : Path.GetFullPath(outputPath);
            Directory.CreateDirectory(Path.GetDirectoryName(pipingOutputPath)!);
            File.WriteAllText(pipingOutputPath, piping.StepText, new UTF8Encoding(false));
            var stem = Path.Combine(Path.GetDirectoryName(pipingOutputPath)!, Path.GetFileNameWithoutExtension(pipingOutputPath));
            var routingPath = stem + ".routing.json"; var cutListPath = stem + ".cutlist.json"; var bomPath = stem + ".bom.json";
            File.WriteAllText(routingPath, PipingAuthoring.RoutingJson(piping.Report), new UTF8Encoding(false));
            File.WriteAllText(cutListPath, PipingAuthoring.CutListJson(piping.Report), new UTF8Encoding(false));
            File.WriteAllText(bomPath, PipingAuthoring.BomJson(piping.Report), new UTF8Encoding(false));
            var report = piping.Report with { RoutingReportArtifactPath = routingPath, CutListArtifactPath = cutListPath, BomArtifactPath = bomPath };
            return KernelResult<FirmamentBuildAndExportResult>.Success(new(fullSourcePath, pipingOutputPath,
                new(piping.StepText, "piping-system:" + report.PipingSystem, -1, "Assembly", "PipingSystem", Piping: report)));
        }
        if (StructuralAuthoring.IsStructuralSource(sourceText))
        {
            var structural = StructuralAuthoring.Compile(sourceText, fullSourcePath);
            if (!structural.IsSuccess || structural.StepText is null || structural.Report is null)
                return KernelResult<FirmamentBuildAndExportResult>.Failure(structural.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "Structural.X2")).ToArray());
            var structuralOutputPath = string.IsNullOrWhiteSpace(outputPath) ? ResolveDefaultOutputPath(fullSourcePath) : Path.GetFullPath(outputPath);
            Directory.CreateDirectory(Path.GetDirectoryName(structuralOutputPath)!);
            File.WriteAllText(structuralOutputPath, structural.StepText, new UTF8Encoding(false));
            var cutListPath = Path.Combine(Path.GetDirectoryName(structuralOutputPath)!, Path.GetFileNameWithoutExtension(structuralOutputPath) + ".cutlist.json");
            File.WriteAllText(cutListPath, StructuralAuthoring.CutListJson(structural.Report), new UTF8Encoding(false));
            var report = structural.Report with { CutListArtifactPath = cutListPath };
            var structuralExport = new FirmamentStepExportResult(structural.StepText, "structure:" + report.Structure, -1, "Assembly", "Structure", Structural: report);
            return KernelResult<FirmamentBuildAndExportResult>.Success(new(fullSourcePath, structuralOutputPath, structuralExport));
        }
        var library = FirmamentStandardLibraryResolver.Resolve(sourceText, out var libraryDiagnostics);
        if (library is null)
            return KernelResult<FirmamentBuildAndExportResult>.Failure(LibraryDiagnostics(libraryDiagnostics));
        sourceText = library.Source;
        var exportResult = ExportSource(sourceText, Path.GetDirectoryName(fullSourcePath), allowV1Compatibility: true, frontend.Schema);
        if (!exportResult.IsSuccess)
        {
            return KernelResult<FirmamentBuildAndExportResult>.Failure(exportResult.Diagnostics);
        }

        var enrichedExport = AttachAuthoredFeatureReports(sourceText, Path.GetDirectoryName(fullSourcePath), exportResult.Value);
        var pmiParity = VerifyV2PmiExportParity(sourceText, Path.GetDirectoryName(fullSourcePath), enrichedExport);
        if (!pmiParity.IsSuccess)
        {
            return KernelResult<FirmamentBuildAndExportResult>.Failure(pmiParity.Diagnostics);
        }

        var assertions = EvaluateVolumeAssertions(sourceText, Path.GetDirectoryName(fullSourcePath), enrichedExport);
        if (!assertions.IsSuccess)
        {
            return KernelResult<FirmamentBuildAndExportResult>.Failure(assertions.Diagnostics);
        }
        var export = enrichedExport with { Assertions = assertions.Value };
        var resolvedOutputPath = string.IsNullOrWhiteSpace(outputPath)
            ? ResolveDefaultOutputPath(fullSourcePath)
            : Path.GetFullPath(outputPath);

        Directory.CreateDirectory(Path.GetDirectoryName(resolvedOutputPath)!);
        File.WriteAllText(resolvedOutputPath, export.StepText, new UTF8Encoding(false));

        return KernelResult<FirmamentBuildAndExportResult>.Success(
            new FirmamentBuildAndExportResult(
                fullSourcePath,
                resolvedOutputPath,
                export),
            exportResult.Diagnostics);
    }

    /// <summary>
    /// Compiles an already-resolved in-memory module through the same materialization and
    /// validation path as file builds. Forge uses this after typed Template specialization.
    /// </summary>
    public static KernelResult<FirmamentStepExportResult> CompileSource(
        string sourceText,
        string? sourceDirectory = null)
    {
        ArgumentNullException.ThrowIfNull(sourceText);
        var normalized = NormalizeLf(sourceText);
        var frontend = FirmamentFrontendSchemas.Select(normalized);
        if (!frontend.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(frontend.Diagnostics.Select(SchemaDiagnostic).ToArray());
        normalized = frontend.Source;
        if (PipingAuthoring.IsPipingSource(normalized))
        {
            var piping = PipingAuthoring.Compile(normalized, sourceDirectory ?? "memory");
            return piping.IsSuccess && piping.StepText is not null && piping.Report is not null
                ? KernelResult<FirmamentStepExportResult>.Success(new(piping.StepText, "piping-system:" + piping.Report.PipingSystem, -1, "Assembly", "PipingSystem", Piping: piping.Report))
                : KernelResult<FirmamentStepExportResult>.Failure(piping.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "Piping.X3")).ToArray());
        }
        if (StructuralAuthoring.IsStructuralSource(normalized))
        {
            var structural = StructuralAuthoring.Compile(normalized, sourceDirectory ?? "memory");
            return structural.IsSuccess && structural.StepText is not null && structural.Report is not null
                ? KernelResult<FirmamentStepExportResult>.Success(new(structural.StepText, "structure:" + structural.Report.Structure, -1, "Assembly", "Structure", Structural: structural.Report))
                : KernelResult<FirmamentStepExportResult>.Failure(structural.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "Structural.X2")).ToArray());
        }
        var library = FirmamentStandardLibraryResolver.Resolve(normalized, out var libraryDiagnostics);
        if (library is null)
            return KernelResult<FirmamentStepExportResult>.Failure(LibraryDiagnostics(libraryDiagnostics));
        normalized = library.Source;
        // In-memory compilation is the canonical V2 boundary used by Forge,
        // assemblies, and drawings. Historical V1 execution is intentionally
        // available only to the explicitly versioned file compatibility route.
        var export = ExportSource(normalized, sourceDirectory, allowV1Compatibility: false, frontend.Schema);
        if (!export.IsSuccess) return export;
        var enrichedExport = AttachAuthoredFeatureReports(normalized, sourceDirectory, export.Value);
        var pmiParity = VerifyV2PmiExportParity(normalized, sourceDirectory, enrichedExport);
        if (!pmiParity.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(pmiParity.Diagnostics);
        var assertions = EvaluateVolumeAssertions(normalized, sourceDirectory, enrichedExport);
        return assertions.IsSuccess
            ? KernelResult<FirmamentStepExportResult>.Success(enrichedExport with { Assertions = assertions.Value }, export.Diagnostics)
            : KernelResult<FirmamentStepExportResult>.Failure(assertions.Diagnostics);
    }

    private static FirmamentStepExportResult AttachAuthoredFeatureReports(
        string source,
        string? sourceDirectory,
        FirmamentStepExportResult export)
    {
        var parsed = ParseSemanticSource(source, sourceDirectory);
        if (!parsed.IsSuccess || parsed.Document is null) return export;
        export = export with { DocumentName = parsed.Document.ModelName };

        var edgeFinishes = (parsed.Document.ModifyBlocks ?? [])
            .SelectMany(modification => (modification.EdgeFinishes ?? []).Select(finish => new FirmamentEngineeringFeatureReport(
                finish.Name,
                "EdgeFinish",
                $"edgefinish:{finish.Name}",
                modification.TargetSolid,
                finish.FaceAxis,
                finish.Target,
                finish.Distance,
                string.Equals(finish.Kind, "Fillet", StringComparison.Ordinal) ? "Radius" : "Distance",
                "Remove",
                PolicySource: finish.Kind,
                MaterializationRoute: "SemanticEdgeFinish")))
            .ToArray();
        var patterns = (parsed.Document.StaticAuthoring?.Patterns ?? [])
            .Select(pattern => new FirmamentSemanticPatternReport(
                pattern.Name,
                pattern.Source,
                pattern.Template,
                pattern.GeneratedCount,
                pattern.GeneratedIds,
                pattern.Associations is null ? "FiniteStaticArray" : "NamedSetAuthoredSourceOrder",
                Associations: pattern.Associations))
            .OrderBy(pattern => pattern.Name, StringComparer.Ordinal)
            .ToArray();
        if (edgeFinishes.Length == 0 && patterns.Length == 0) return export;

        var existing = export.EngineeringFeatures ?? [];
        return export with
        {
            EngineeringFeatures = existing
                .Concat(edgeFinishes)
                .DistinctBy(feature => feature.FeatureId, StringComparer.Ordinal)
                .OrderBy(feature => feature.FeatureId, StringComparer.Ordinal)
                .ToArray(),
            Patterns = patterns
        };
    }

    private static KernelResult<IReadOnlyList<FirmamentV2VolumeAssertionResult>> EvaluateVolumeAssertions(string source, string? sourceDirectory, FirmamentStepExportResult export)
    {
        var parsed = ParseSemanticSource(source, sourceDirectory);
        if (!parsed.IsSuccess || parsed.Document?.VolumeAssertions is not { Count: > 0 } assertions) return KernelResult<IReadOnlyList<FirmamentV2VolumeAssertionResult>>.Success([]);
        var imported = Step242Importer.ImportBody(export.StepText);
        if (!imported.IsSuccess || imported.Value is null)
        {
            return KernelResult<IReadOnlyList<FirmamentV2VolumeAssertionResult>>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                "firmament-v2-assert-volume-measurement-unavailable: STEP reimport failed", "FirmamentV2.AssertVolume")]);
        }
        var mass = BrepMassProperties.Evaluate(imported.Value);
        var results = assertions.Select(assertion => FirmamentV2VolumeAssertionComparer.Compare(assertion, mass)).ToArray();
        // Display-tessellation estimates remain useful evidence, but they do
        // not gate a production build as the definition of occupied volume.
        // Analytic B-rep recognizers retain their existing bounded gate until
        // the post-Preview-1 CIR authority path is implemented.
        var failures = results.Where(result => result.MeasurementAuthoritative && !result.Passed).Select(result => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            result.Diagnostic ?? "firmament-v2-assert-volume-failed", "FirmamentV2.AssertVolume")).ToArray();
        return failures.Length == 0
            ? KernelResult<IReadOnlyList<FirmamentV2VolumeAssertionResult>>.Success(results)
            : KernelResult<IReadOnlyList<FirmamentV2VolumeAssertionResult>>.Failure(failures);
    }

    private static KernelResult<bool> VerifyV2PmiExportParity(string source, string? sourceDirectory, FirmamentStepExportResult export)
    {
        var parsed = ParseSemanticSource(source, sourceDirectory);
        if (!parsed.IsSuccess || parsed.Document is null || parsed.Document.Pmi is not { Count: > 0 } pmi)
            return KernelResult<bool>.Success(true);

        var support = ValidateV2PmiExportSupport(parsed.Document);
        if (!support.IsSuccess) return support;

        var expectedDatums = pmi.Count(record => record.Kind == FirmamentV2PmiKind.DatumPlane);
        var expectedDiameters = pmi.Count(record => record.Kind == FirmamentV2PmiKind.HoleDiameter);
        var inspection = Step242SemanticPmiInspector.Inspect(export.StepText);
        if (inspection.Success && inspection.DatumCount == expectedDatums && inspection.DimensionCount == expectedDiameters)
            return KernelResult<bool>.Success(true);

        var actualDatums = inspection.Success ? inspection.DatumCount : 0;
        var actualDiameters = inspection.Success ? inspection.DimensionCount : 0;
        var detail = inspection.Success ? string.Empty : $" Inspector diagnostics: {string.Join("; ", inspection.Diagnostics)}";
        return KernelResult<bool>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            $"firmament-v2-pmi-export-evidence-mismatch: validation admitted {expectedDatums} datum and {expectedDiameters} diameter PMI records, but AP242 reinspection found {actualDatums} datum and {actualDiameters} diameter records.{detail}",
            "FirmamentV2.PmiExportParity")]);
    }


    private static KernelResult<FirmamentStepExportResult> ExportSource(
        string sourceText,
        string? sourceDirectory = null,
        bool allowV1Compatibility = false,
        FirmamentFrontendSchema? explicitSchema = null)
    {
        if (GearAuthoring.IsGearSource(sourceText))
        {
            return ExportGearSource(sourceText);
        }
        if (explicitSchema == FirmamentFrontendSchema.SectionChain)
        {
            var authored = SectionChainAuthoringParser.Compile(sourceText);
            if (!authored.IsSuccess || authored.Materialization?.Body is null)
                return KernelResult<FirmamentStepExportResult>.Failure(authored.Diagnostics.Select(SchemaDiagnostic).ToArray());
            var step = Step242Exporter.ExportBody(authored.Materialization.Body, new Step242ExportOptions { ProductName = authored.Chain!.StableId });
            return step.IsSuccess
                ? KernelResult<FirmamentStepExportResult>.Success(new(step.Value, authored.Chain!.StableId, 0, "section-chain", "section-chain"))
                : KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        }
        // The V2 parser owns canonical-root admission.  Profile/composition
        // materializers consume only the extracted normalized declaration body,
        // so their historical top-level spelling is no longer author-visible.
        // Static authoring is intentionally erased before this boundary, too:
        // parser admission alone is insufficient because the profile/composition
        // materializers read source declarations directly.
        var staticDiagnostics = new List<string>();
        sourceText = ProfileModificationTemplateLibrary.ResolveImports(sourceText);
        var boundaryExpansion = ClosedBoundary2Authoring.Expand(sourceText, staticDiagnostics);
        if (boundaryExpansion is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(staticDiagnostics.Select(diagnostic => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, diagnostic, "FirmamentV2.ClosedBoundary2")).ToArray());
        }
        var templateBindWatch = System.Diagnostics.Stopwatch.StartNew();
        var templateExpansion = FirmamentV2TemplateExpansion.Expand(boundaryExpansion.Source, staticDiagnostics);
        templateBindWatch.Stop();
        if (templateExpansion is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(staticDiagnostics.Select(diagnostic => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, diagnostic, "FirmamentV2.TemplateExpansion")).ToArray());
        }
        var featureExpansion = FirmamentV2FeatureExpansion.Expand(templateExpansion.Source, staticDiagnostics);
        if (featureExpansion is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(staticDiagnostics.Select(diagnostic => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, diagnostic, "FirmamentV2.FeatureExpansion")).ToArray());
        }
        var specializedBoundaries = ClosedBoundary2Authoring.Expand(featureExpansion.Source, staticDiagnostics);
        if (specializedBoundaries is null)
            return KernelResult<FirmamentStepExportResult>.Failure(staticDiagnostics.Select(SchemaDiagnostic).ToArray());
        var staticExpansion = CanonicalStaticAuthoring.Expand(specializedBoundaries.Source, staticDiagnostics);
        if (staticExpansion is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(staticDiagnostics
                .Distinct(StringComparer.Ordinal)
                .Order(StringComparer.Ordinal)
                .Select(diagnostic => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
                    Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                    diagnostic,
                    "FirmamentV2.StaticAuthoring"))
                .ToArray());
        }
        var materializerInput = staticExpansion.Source;
        // Parse the canonical document before selecting the materializer.  Advanced
        // Profile/Compose hosts still use their bounded section-stack materializer,
        // but their normalized PMI records must follow the same AP242 route.
        var canonicalParseWatch = System.Diagnostics.Stopwatch.StartNew();
        var v2Parse = FirmamentV2Parser.Parse(sourceText, sourceDirectory);
        canonicalParseWatch.Stop();
        var canonicalAdvanced = FirmamentV2Parser.TryGetCanonicalAdvancedBody(materializerInput, out var canonicalBody);
        var materializerSource = canonicalAdvanced ? canonicalBody : materializerInput;
        if (PlateauAuthoring.IsSource(materializerSource))
        {
            if (!v2Parse.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(v2Parse.Diagnostics.Select(SchemaDiagnostic).ToArray());
            return PlateauAuthoring.Compile(materializerSource);
        }
        if (RevolveAuthoringParser.IsRevolveSource(materializerSource))
        {
            var authored = RevolveAuthoringParser.Parse(materializerSource, out var revolveDiagnostics);
            if (authored is null)
                return KernelResult<FirmamentStepExportResult>.Failure(revolveDiagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "FirmamentV2.Revolve")).ToArray());
            var built = ResolvedProfileRevolveEmitter.TryEmit(authored);
            if (!built.Succeeded || built.Body is null || built.Plan is null)
                return KernelResult<FirmamentStepExportResult>.Failure(built.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "FirmamentV2.Revolve")).ToArray());
            var step = Step242Exporter.ExportBody(built.Body, new Step242ExportOptions { ProductName = authored.Name });
            if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            var reimport = Step242Importer.ImportBody(step.Value);
            if (!reimport.IsSuccess || reimport.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
            var reimportedManifold = reimport.Value.Topology.Edges.All(edge => reimport.Value.Topology.Coedges.Count(use => use.EdgeId == edge.Id) == 2);
            if (!reimportedManifold)
                return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                    $"firmament-revolve-step-reimport-not-manifold:{authored.Name}", "FirmamentV2.Revolve")]);
            var surfaces = built.Body.Topology.Faces.Select(face => built.Body.GetFaceSurface(face.Id).Kind).ToArray();
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))).ToLowerInvariant();
            var report = new FirmamentRevolveReport(authored.Profile.Name, authored.AxisName, authored.SweepRadians,
                authored.SweepRadians * 180d / Math.PI, authored.AuthoredAlias, authored.SweepRadians < 0d ? "Negative" : "Positive",
                built.Plan.IsFull ? "Full" : "Partial", built.Plan.DeterministicSignature, built.Plan.SurfaceRoles,
                built.Body.Topology.Vertices.Count(), built.Body.Topology.Edges.Count(), built.Body.Topology.Faces.Count(),
                surfaces.Count(kind => kind == SurfaceGeometryKind.Plane), surfaces.Count(kind => kind == SurfaceGeometryKind.Cylinder),
                surfaces.Count(kind => kind == SurfaceGeometryKind.Cone), surfaces.Count(kind => kind == SurfaceGeometryKind.Sphere),
                surfaces.Count(kind => kind == SurfaceGeometryKind.Torus), surfaces.Count(kind => kind == SurfaceGeometryKind.SurfaceOfRevolution),
                reimportedManifold, hash);
            return KernelResult<FirmamentStepExportResult>.Success(new(step.Value, authored.Name, 0, "bounded-revolve", "revolve", Revolve: report,
                EngineeringFeatures: [new(authored.Name, "Revolve", authored.StableId, authored.Name, authored.Axis.StableId, authored.Profile.Name,
                    authored.SweepRadians, "SweepRadians", "Base", PolicySource: "ResolvedProfileRevolveEmitter", MaterializationRoute: "RevolveBRepPlan")]));
        }
        if (explicitSchema == FirmamentFrontendSchema.WireForm || WireFormAuthoring.IsWireFormSource(materializerSource))
        {
            var parsePhase = BuildPerfTrace.Phase("firmament.wire-parse-and-bind");
            var authored = WireFormAuthoring.Parse(materializerSource);
            parsePhase.Dispose();
            if (!authored.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(authored.Diagnostics);
            var buildPhase = BuildPerfTrace.Phase("firmament.wire-brep-materialize");
            var built = WireFormBRepMaterializer.Build(authored.Value);
            buildPhase.Dispose();
            if (!built.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(built.Diagnostics);
            var stepPhase = BuildPerfTrace.Phase("firmament.step-export");
            var step = Step242Exporter.ExportBody(built.Value.Body, new Step242ExportOptions { ProductName = authored.Value.Name });
            stepPhase.Dispose();
            if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            var importPhase = BuildPerfTrace.Phase("firmament.step-reimport");
            var reimport = Step242Importer.ImportBody(step.Value);
            importPhase.Dispose();
            if (!reimport.IsSuccess || reimport.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
            var manifold = reimport.Value.Topology.Edges.All(edge => reimport.Value.Topology.Coedges.Count(use => use.EdgeId == edge.Id) == 2);
            if (!manifold) return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                "wireform-step-reimport-not-manifold: exported WireForm did not reimport as an enclosed manifold.", "FirmamentV2.WireForm")]);
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))).ToLowerInvariant();
            var reportPhase = BuildPerfTrace.Phase("firmament.wire-report-validation");
            var report = WireFormReportFactory.Create(built.Value, hash, manifold);
            reportPhase.Dispose();
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, authored.Value.Name, 0,
                "wire-form", "wireform", WireForm: report,
                EngineeringFeatures: authored.Value.Operations.Select(operation => new FirmamentEngineeringFeatureReport(
                    operation.Name, operation switch { WireStraightAir => "Straight", WireBendAir => "Bend", WireAxisCoilAir => "Helix", WireSurfaceCoilAir => "SurfaceCoil", WireKnotPathAir => "KnotPath", _ => "Unknown" }, operation.StableId(authored.Value.Name),
                    authored.Value.Name, "WireState", "CircularSection", operation.LengthMm, "CenterlineLength", "Add",
                    PolicySource: "WireFormFeatureAir", MaterializationRoute: "WireFormCenterlineAir->CircularSweepBRepPlan")).ToArray())
                { RuntimeBody = reimport.Value }, []);
        }
        if (explicitSchema == FirmamentFrontendSchema.Sweep || CircularSweepAuthoring.IsSweepSource(materializerSource))
        {
            var airWatch = System.Diagnostics.Stopwatch.StartNew();
            var authored = CircularSweepAuthoring.Parse(materializerSource);
            airWatch.Stop();
            if (!authored.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(authored.Diagnostics);
            var brepWatch = System.Diagnostics.Stopwatch.StartNew();
            var built = CircularSweepBRepMaterializer.Build(authored.Value);
            brepWatch.Stop();
            if (!built.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(built.Diagnostics);
            var stepWatch = System.Diagnostics.Stopwatch.StartNew();
            var step = Step242Exporter.ExportBody(built.Value.Body, new Step242ExportOptions { ProductName = authored.Value.Name });
            stepWatch.Stop();
            if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            var reimportWatch = System.Diagnostics.Stopwatch.StartNew();
            var reimport = Step242Importer.ImportBody(step.Value);
            reimportWatch.Stop();
            if (!reimport.IsSuccess || reimport.Value is null)
                return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
            var reimportedManifold = reimport.Value.Topology.Edges.All(edge => reimport.Value.Topology.Coedges.Count(use => use.EdgeId == edge.Id) == 2);
            if (!reimportedManifold)
                return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                    "firmament-sweep-step-reimport-not-manifold: exported Sweep did not reimport as an enclosed manifold.", "FirmamentV2.Sweep")]);
            var surfaces = built.Value.Body.Topology.Faces.Select(face => built.Value.Body.GetFaceSurface(face.Id).Kind).ToArray();
            var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))).ToLowerInvariant();
            var report = new FirmamentSweepReport(
                authored.Value.Path.Name, authored.Value.Path.Segments.Count, authored.Value.Diameter, built.Value.CenterlineLength,
                built.Value.Volume, built.Value.MassKilograms, built.Value.Bounds, authored.Value.Material.Identity.FirmamentPath,
                surfaces.Count(kind => kind == SurfaceGeometryKind.Cylinder), surfaces.Count(kind => kind == SurfaceGeometryKind.Torus),
                surfaces.Count(kind => kind == SurfaceGeometryKind.Plane), true, hash, true, true,
                "Nonadjacent line pairs are exact; arc-involving clearance uses a deterministic conservative chord witness.",
                new(templateBindWatch.Elapsed.TotalMilliseconds, canonicalParseWatch.Elapsed.TotalMilliseconds,
                    airWatch.Elapsed.TotalMilliseconds, brepWatch.Elapsed.TotalMilliseconds, stepWatch.Elapsed.TotalMilliseconds,
                    reimportWatch.Elapsed.TotalMilliseconds));
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, authored.Value.Name, 0,
                "circular-sweep", "sweep", Sweep: report,
                EngineeringFeatures: [new(authored.Value.Name, "Sweep", "sweep:" + authored.Value.Name, authored.Value.Name,
                    authored.Value.Path.StableId, "Circle", authored.Value.Diameter, "Diameter", "Add", PolicySource: "CircularSweepFeatureAir", MaterializationRoute: "CircularSweepBRepPlan")]),
                []);
        }
        // Mechanical Model syntax and semantic binding are authoritative for both
        // validate and build. Execution receives the bound engineering inputs.
        if (v2Parse.ParserRoute == "UnifiedMechanical" && !v2Parse.IsSuccess)
            return V2ParseFailure(v2Parse);
        if (v2Parse.BoundComposition is not null || (v2Parse.ParserRoute != "UnifiedMechanical" && PrismaticProfileCompositionParser.IsCompositionSource(materializerSource)))
        {
            var parsed = v2Parse.BoundComposition ?? PrismaticProfileCompositionParser.Parse(materializerSource);
            var stack = PrismaticSectionStackCompiler.Normalize(parsed, out var diagnostics);
            if (stack is null)
                return KernelResult<FirmamentStepExportResult>.Failure(diagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.ProfileComposition")).ToArray());
            var emitted = PrismaticSectionStackEmitter.Emit(stack);
            if (emitted.Body is null)
                return KernelResult<FirmamentStepExportResult>.Failure(emitted.Diagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.ProfileComposition")).ToArray());
            if ((stack.Feature.ConstructionPlaneBlindDrills?.Count ?? 0) > 0)
            {
                var finalPlan = SectionStackBlindDrillComposeBridge.TryApply(stack, emitted.Plan!, out var bridgeDiagnostics, out _);
                if (finalPlan?.TopologyPlan is null)
                    return KernelResult<FirmamentStepExportResult>.Failure(bridgeDiagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.ProfileComposition.BlindDrill")).ToArray());
                var materialized = PrismaticSectionStackBrepMaterializer.TryMaterialize(finalPlan.TopologyPlan);
                if (materialized.Body is null)
                    return KernelResult<FirmamentStepExportResult>.Failure(materialized.Diagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.ProfileComposition.BlindDrill")).ToArray());
                emitted = new PrismaticSectionStackEmissionResult(materialized.Body, finalPlan, emitted.Diagnostics.Concat(bridgeDiagnostics).ToArray(), finalPlan.Correspondence);
            }
            if (materializerSource.Contains("EdgeFinish", StringComparison.Ordinal))
                return ExportComposedSemanticTopBoundaryChamfer(materializerSource, parsed, stack, emitted, v2Parse.Document);
            // The composition route either retained the checked body above or
            // replaced it with a checked blind-drill materialization.
            var completedBody = emitted.Body;
            if (completedBody is null)
                return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, "profile-composition-materialization-missing-body", "FirmamentV2.ProfileComposition")]);
            var semanticPmi = Array.Empty<Step242SemanticPmi>();
            if (v2Parse.IsSuccess && v2Parse.Document is not null)
            {
                var support = ValidateV2PmiExportSupport(v2Parse.Document);
                if (!support.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(support.Diagnostics);
                var features = (stack.Feature.ShaftHoles ?? []).ToDictionary(hole => hole.Name, hole => hole.StableId, StringComparer.Ordinal);
                foreach (var hole in stack.Feature.CounterboreHoles ?? []) features[hole.Name] = hole.StableId;
                semanticPmi = BuildV2SemanticPmi(v2Parse.Document, [], stack.Feature.Name, features, emitted.Correspondence).ToArray();
            }
            var step = Step242Exporter.ExportBody(completedBody, semanticPmi);
            if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, stack.Feature.Name, 0, "prismatic-section-stack", "line-arc-profile-composition",
                DatumInspection: v2Parse.Document?.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
                DimensionInspection: v2Parse.Document?.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.HoleDiameter).Select(p => new FirmamentPmiInspectionDimension("Diameter", p.Target, null, p.Value ?? 0d, "explicit-v2-record-pmi", p.Name)).ToArray() ?? [],
                Features: CompositionHoleReports(stack.Feature),
                EngineeringFeatures: EngineeringFeatureReports(stack.Feature)));
        }
        if (v2Parse.BoundProfile is not null || (v2Parse.ParserRoute != "UnifiedMechanical" && ProfileAuthoringParser.IsProfileSource(materializerSource)))
        {
            var parsed = v2Parse.BoundProfile is { } boundProfile
                ? (Profile: (ResolvedProfile2D?)boundProfile, Height: v2Parse.ExtrusionHeight, Diagnostics: (IReadOnlyList<string>)[])
                : ProfileAuthoringParser.Parse(materializerSource);
            if (parsed.Profile is null) return KernelResult<FirmamentStepExportResult>.Failure(parsed.Diagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.Profile")).ToArray());
            var emitted = ResolvedProfile2DValidator.Extrude(parsed.Profile, parsed.Height);
            if (emitted.Status != LineArcProfileExtrudeStatus.Succeeded || emitted.Body is null) return KernelResult<FirmamentStepExportResult>.Failure(emitted.Diagnostics.Select(x => new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, x, "FirmamentV2.Profile")).ToArray());
            if (materializerSource.Contains("EdgeFinish", StringComparison.Ordinal))
                return ExportProfileSemanticTopBoundaryChamfer(materializerSource, parsed.Profile, parsed.Height, emitted);
            var step = Step242Exporter.ExportBody(emitted.Body); if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, parsed.Profile.Name, 0, "profile-extrude", "line-arc-profile"));
        }
        if (v2Parse.IsSuccess && v2Parse.Document is not null)
        {
            if (v2Parse.Document.Solids.Count == 0 && v2Parse.Document.Panels is { Count: > 0 })
            {
                return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.NotImplemented,
                    Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                    "firmament-panel-only-step-materialization-unsupported: the document contains authored Panels but no solid body. Panel geometry remains available to public pre-realization predicates; the ordinary STEP build route does not yet define a shell/product export contract.",
                    "FirmamentV2.Panel")]);
            }

            var dfm = FirmamentV2DfmEnforcement.Validate(v2Parse.Document);
            if (!dfm.IsSuccess)
            {
                return KernelResult<FirmamentStepExportResult>.Failure(dfm.Diagnostics);
            }

            if (TryExportV2StandaloneCubicLattice(v2Parse.Document) is { } latticeExport)
            {
                return latticeExport;
            }

            if (TryExportV2HollowBody(v2Parse.Document) is { } hollowExport)
            {
                return hollowExport;
            }

            if (TryExportV2RoundedBoxBody(v2Parse.Document) is { } roundedBoxExport)
            {
                return roundedBoxExport;
            }

            if (TryExportV2ThreadBody(v2Parse.Document) is { } threadExport)
            {
                return threadExport;
            }

            if (TryExportV2ExactCoaxialPart(v2Parse.Document) is { } exactCoaxialExport)
            {
                return exactCoaxialExport;
            }

            if (TryExportV2StandardPart(v2Parse.Document) is { } standardPartExport)
            {
                return standardPartExport;
            }
            if (TryExportV2PerforationBody(v2Parse.Document) is { } perforationExport)
            {
                return perforationExport;
            }

            // Do not let the existing semantic-hole route silently export the unmodified host.
            // M9 has an explicit AIR/graph contract, but the authoritative single-body merge
            // (retained box-with-void plus analytic struts/nodes/bonds) is not yet materialized.
            if (v2Parse.Document.LatticeFills is { Count: > 0 })
            {
                return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                    Kernel.Core.Diagnostics.KernelDiagnosticCode.NotImplemented,
                    Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                    "lattice-fill-brep-plan-not-materialized: M9 parsed and DFM-validated the explicit FillRegion, but the current BRep backend cannot emit the required single authoritative body combining an internal box cavity, a preserved through-hole, and bonded analytic lattice members. No STEP artifact was emitted.",
                    "FirmamentV2.LatticeFill")]);
            }

            var routed = DispatchV2Routes(v2Parse.Document,
                ("CombinedHoleEdgeFinish", TryExportV2CombinedHoleEdgeFinishBody),
                ("AirChamfer", TryExportV2AirChamferBody),
                ("SemanticHole", TryExportV2SemanticHoleBody),
                ("ControlledSideHole", TryExportV2ControlledSideHoleBody),
                ("InlineStepReplacement", TryExportV2InlineStepReplacementBody),
                ("InlineStep", TryExportV2InlineStepBody));
            if (routed is not null)
            {
                return routed;
            }

            var lowering = FirmamentV2BuildLowering.LowerPrimitiveBridge(v2Parse.Document);
            if (!lowering.IsSuccess)
            {
                return KernelResult<FirmamentStepExportResult>.Failure(lowering.Diagnostics);
            }

            var execution = FirmamentPrimitiveExecutor.Execute(lowering.Value);
            if (!execution.IsSuccess)
            {
                return KernelResult<FirmamentStepExportResult>.Failure(execution.Diagnostics);
            }

            var executedPrimitive = execution.Value.ExecutedPrimitives.LastOrDefault();
            if (executedPrimitive is null)
            {
                return KernelResult<FirmamentStepExportResult>.Failure(execution.Diagnostics);
            }

            var semanticPmi = BuildV2SemanticPmi(v2Parse.Document, [], executedPrimitive.FeatureId);
            var step = Step242Exporter.ExportBody(executedPrimitive.Body, semanticPmi);
            if (!step.IsSuccess)
            {
                return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
            }

            var primitiveExport = new FirmamentStepExportResult(
                    step.Value,
                    executedPrimitive.FeatureId,
                    executedPrimitive.OpIndex,
                    "primitive",
                    v2Parse.Document.Solid.RecordType.ToLowerInvariant(),
                    DatumInspection: v2Parse.Document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
                    DimensionInspection: [])
            {
                RuntimeBody = executedPrimitive.Body,
                Cir = FirmamentCirRetention.FromRoot(execution.Value.NativeGeometryState.CirMirror.RuntimeRoot, step.Value)
            };
            if (executedPrimitive.Kind == FirmamentLoweredPrimitiveKind.Box
                && executedPrimitive.BoxConstructionTopology is { } boxTopology
                && v2Parse.Document.Solids.Count == 1
                && execution.Value.ExecutedBooleans.Count == 0)
                primitiveExport = primitiveExport with
                {
                    RuntimeBody = executedPrimitive.Body,
                    RuntimeCorrespondence = BoxConstructionCorrespondence.Create(executedPrimitive.FeatureId, boxTopology,
                        v2Parse.Document.Solids.Single(s => s.Name == executedPrimitive.FeatureId).SourceSpan)
                };
            return KernelResult<FirmamentStepExportResult>.Success(primitiveExport);
        }

        if (v2Parse.Diagnostics.Contains(FirmamentV2Parser.InlineStepRequiresCanonical, StringComparer.Ordinal))
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
                Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                "firmament-inline-step-requires-aetheris-canonical-step: Inline STEP requires an Aetheris-canonical AP242 file. Run `aetheris canon <input.step> --out <canonical.step>` first.",
                "FirmamentV2.InlineStep")]);
        }

        if (v2Parse.Diagnostics.Any(d => d.StartsWith("firmament-v2-inline-step-", StringComparison.Ordinal)))
        {
            return KernelResult<FirmamentStepExportResult>.Failure(v2Parse.Diagnostics.Select(d => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
                Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                d,
                "FirmamentV2.InlineStep")).ToArray());
        }

        if (v2Parse.Disposition == FirmamentV2ParseDisposition.RecognizedInvalid)
            return V2ParseFailure(v2Parse);

        if (!allowV1Compatibility)
        {
            return V2SourceRequired(v2Parse);
        }

        // V1 is not a peer authoring route. File builds admit it only when the
        // historical reader proves that the document explicitly declares version 1.
        // This prevents V1's permissive serialization parser from accepting malformed
        // or serialization-shaped V2 input.
        var compatibility = new Compatibility.V1.LegacyFirmamentV1SourceReader().ReadAuto(sourceText);
        if (!compatibility.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(compatibility.Diagnostics);
        }
        if (!string.Equals(compatibility.Value.Firmament.Version, "1", StringComparison.Ordinal))
        {
            return V2SourceRequired(v2Parse);
        }

        return ExportV1CompatibilitySource(sourceText);
    }

    private static KernelResult<FirmamentStepExportResult> ExportGearSource(string sourceText)
    {
        var authored = GearAuthoring.Parse(sourceText);
        if (!authored.IsSuccess)
            return KernelResult<FirmamentStepExportResult>.Failure(authored.Diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                message, "Firmament.GearAir")).ToArray());
        if (authored.Gears.Count != 1)
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                $"{GearAuthoring.Prefix}build-body-count-invalid:expected=1:actual={authored.Gears.Count}:use-Assembly-for-a-gear-train",
                "Firmament.GearAir")]);
        var gear = authored.Gears[0];
        var materialized = GearAuthoring.Materialize(gear, out var materializationDiagnostics);
        if (materialized is null)
            return KernelResult<FirmamentStepExportResult>.Failure(materializationDiagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                message, "Firmament.GearBRep")).ToArray());
        var step = Step242Exporter.ExportBody(materialized.Body, new Step242ExportOptions
        {
            ProductName = gear.Name,
            ApplicationName = "Aetheris.Firmament.GearLibrary.X0"
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        var reimportedManifold = reimport.IsSuccess && reimport.Value is not null && FirmamentManifoldChecker.IsManifold(reimport.Value);
        if (!reimportedManifold)
            return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics.Append(new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                $"{GearAuthoring.Prefix}step-reimport-not-manifold:{gear.Name}", "Firmament.GearBRep")).ToArray());
        var surfaces = materialized.Body.Topology.Faces.Select(face => materialized.Body.GetFaceSurface(face.Id).Kind).ToArray();
        var item = new FirmamentGearItemReport(gear.Name, gear.Family.ToString(), gear.Teeth, gear.ModuleMm, gear.PressureAngleDegrees,
            gear.PitchDiameterMm, gear.BaseDiameterMm, gear.AddendumDiameterMm, gear.RootDiameterMm, gear.FaceWidthMm,
            gear.BoreDiameterMm, gear.PhaseDegrees, gear.BacklashMm, gear.PitchConeAngleDegrees, gear.Axis,
            materialized.ToothProfileCurveCount, materialized.InvoluteSpanCount, materialized.MaximumInvoluteApproximationErrorMm,
            materialized.ToothConstruction, materialized.StableToothIds);
        var interfaces = authored.Interfaces.Select(value => new FirmamentGearInterfaceReport(value.Name, value.A.Name, value.B.Name,
            value.Kind, value.Compatible, value.ExpectedCenterDistanceMm, value.Ratio, value.RotationSign,
            value.AxisRelation, value.ShaftAngleDegrees, value.EngagementPhaseDegrees, value.AllowedDirection, value.RejectionReasons)).ToArray();
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))).ToLowerInvariant();
        var report = new FirmamentGearReport(authored.ModelName, [item], interfaces,
            materialized.Body.Topology.Vertices.Count(), materialized.Body.Topology.Edges.Count(), materialized.Body.Topology.Faces.Count(),
            surfaces.Count(kind => kind == SurfaceGeometryKind.Plane), surfaces.Count(kind => kind == SurfaceGeometryKind.Cylinder),
            surfaces.Count(kind => kind == SurfaceGeometryKind.Cone), surfaces.Count(kind => kind == SurfaceGeometryKind.BSplineSurfaceWithKnots),
            surfaces.Count(kind => kind == SurfaceGeometryKind.LinearExtrusion), FirmamentManifoldChecker.IsManifold(materialized.Body),
            true, true, hash, "DeterministicExactBRepAP242", gear.Family is GearFamily.BevelGear or GearFamily.MiterGear ? "BoundedStraightBevel" : "QualifiedX0");
        return KernelResult<FirmamentStepExportResult>.Success(new(step.Value, $"gear:{gear.Name}", 0, "gear", gear.Family.ToString(), Gear: report));
    }

    private static FirmamentV2ParseResult ParseSemanticSource(string source, string? sourceDirectory)
        => FirmamentV2Parser.Parse(source, sourceDirectory);

    private static Kernel.Core.Diagnostics.KernelDiagnostic SchemaDiagnostic(string message) => new(
        Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
        Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
        message,
        "Firmament.Schema");

    private static IReadOnlyList<Kernel.Core.Diagnostics.KernelDiagnostic> LibraryDiagnostics(IEnumerable<string> diagnostics) =>
        diagnostics.Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            message,
            "FirmamentV2.LibraryResolution")).ToArray();

    private static KernelResult<FirmamentStepExportResult> V2ParseFailure(FirmamentV2ParseResult parse)
    {
        var errors = parse.Diagnostics.Where(FirmamentV2Parser.IsFatalDiagnosticCode).Distinct(StringComparer.Ordinal).ToArray();
        if (errors.Length == 0) errors = ["firmament-v2-parse-failed"];
        return KernelResult<FirmamentStepExportResult>.Failure(errors.Select(code => new KernelDiagnostic(
            KernelDiagnosticCode.ValidationFailed, KernelDiagnosticSeverity.Error, code, "FirmamentV2.Parse")).ToArray());
    }

    private static KernelResult<FirmamentStepExportResult> V2SourceRequired(FirmamentV2ParseResult parse)
    {
        var fatal = parse.Diagnostics
            .Where(FirmamentV2Parser.IsFatalDiagnosticCode)
            .Distinct(StringComparer.Ordinal)
            .Select(code => new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
                Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                code,
                "FirmamentV2.Parse"))
            .ToList();
        fatal.Add(new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            "firmament-v2-source-required: canonical in-memory compilation requires Firmament V2; historical V1 is accepted only from an explicitly versioned file compatibility input.",
            "FirmamentV2.CompatibilityFirewall"));
        return KernelResult<FirmamentStepExportResult>.Failure(fatal);
    }

    private static KernelResult<FirmamentStepExportResult> ExportV1CompatibilitySource(string sourceText)
    {
        var legacy = FirmamentStepExporter.Export(new FirmamentCompileRequest(new FirmamentSourceDocument(sourceText)));
        if (!legacy.IsSuccess)
        {
            return legacy;
        }

        return KernelResult<FirmamentStepExportResult>.Success(legacy.Value, [
            .. legacy.Diagnostics,
            new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
                Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Warning,
                "firmament-v1-compatibility-input: historical Firmament V1 source was accepted through the compatibility build route; Firmament V2 is the canonical authoring language.",
                "FirmamentV1.Compatibility")]);
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2StandardPart(FirmamentV2Document document)
    {
        if (document.Solids.Count != 1 || document.Solid.StandardPart is not { } authored) return null;
        var definition = StandardLibraryReusableParts.TryCreate(authored.Family, authored.Parameters, deferMakerMarkToCompiler: true);
        if (!definition.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(definition.Diagnostics);
        if (definition.Value.HexBolt is not { } bolt)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(
                Kernel.Core.Diagnostics.KernelDiagnosticCode.NotImplemented,
                Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
                $"Firmament V2 StandardPart family '{authored.Family}' does not publish a typed part definition.",
                "FirmamentV2.StandardPart")]);
        }

        var step = Step242Exporter.ExportBody(definition.Value.Body);
        if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var semantics = bolt.Semantics.Descendants.Select(descendant => new FirmamentStandardPartSemanticReport(
            descendant.StableId,
            descendant.Kind.ToString(),
            descendant.ParentStableId,
            descendant.Face?.Value,
            descendant.Metadata)).ToArray();
        var report = new FirmamentStandardPartReport(
            authored.Family,
            document.StaticAuthoring?.Templates.SingleOrDefault()?.Name,
            bolt.DeterministicSignature,
            authored.Parameters,
            semantics);
        return ApplyHexBoltMakerMark(new FirmamentStepExportResult(
            step.Value,
            bolt.Semantics.BodyStableId,
            0,
            "standard-part",
            authored.Family,
            ConceptIr: document.ConceptIr,
            StandardPart: report) { RuntimeBody = bolt.Body });
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2ThreadBody(FirmamentV2Document document)
    {
        if (document.Threads is not { Count: > 0 }) return null;
        KernelResult<FirmamentStepExportResult> Failure(string code, string message) =>
            KernelResult<FirmamentStepExportResult>.Failure([new KernelDiagnostic(
                KernelDiagnosticCode.ValidationFailed, KernelDiagnosticSeverity.Error,
                $"thread-{code}: {message}", "FirmamentV2.Thread")]);
        if (document.Threads.Count != 1 || document.Solids.Count != 1 || (document.ModifyBlocks?.Count ?? 0) != 0)
            return Failure("composition-unsupported", "X1 admits one Thread on one unmodified cylindrical support.");
        var feature = document.Threads[0];
        var solid = document.Solid;
        if (feature.SupportSolid != solid.Name)
            return Failure("support-unresolved", $"Surface refers to '{feature.SupportSolid}', but the authored solid is '{solid.Name}'.");
        if (solid.StandardPart is { } authoredPart && feature.SupportRole == "Shank")
            return TryExportV2HexBoltThread(document, feature, authoredPart);
        if (solid.Cylinder is not { } support || feature.SupportRole != "OuterWall")
            return Failure("support-not-cylinder", "Surface must bind to face(<Cylinder>.OuterWall), an analytic cylindrical support.");
        if (!double.IsFinite(feature.MajorDiameterMm) || feature.MajorDiameterMm <= 0d ||
            double.Abs(feature.MajorDiameterMm - 2d * support.Radius) > 1e-6d)
            return Failure("major-diameter-incompatible", "MajorDiameter must be positive and equal to the cylindrical precursor stock diameter.");
        if (!double.IsFinite(feature.PitchMm) || feature.PitchMm <= 0d)
            return Failure("pitch-invalid", "Pitch must be finite and positive.");
        if (!double.IsFinite(feature.LengthMm) || feature.LengthMm <= 0d)
            return Failure("length-invalid", "Length must be finite and positive.");
        if (feature.StartOffsetMm is { } authoredOffset && (!double.IsFinite(authoredOffset) || authoredOffset < 0d))
            return Failure("start-offset-invalid", "StartOffset must be finite and nonnegative.");

        // External 60-degree truncated profile: root width 5P/6 and crest P/8.
        // Each flank has axial run 17P/48, giving depth 17*sqrt(3)*P/48.
        var rootWidth = 5d * feature.PitchMm / 6d;
        var crestWidth = feature.PitchMm / 8d;
        var depth = (rootWidth - crestWidth) * double.Sqrt(3d) / 2d;
        var rootRadius = feature.MajorDiameterMm / 2d - depth;
        if (rootRadius <= 0d)
            return Failure("profile-self-intersection", "The 60-degree profile depth consumes the support radius.");
        var grooveWidth = feature.PitchMm - crestWidth;
        var grooveBottomWidth = feature.PitchMm - rootWidth;
        var start = feature.StartOffsetMm ?? grooveWidth / 2d + 1d;
        var end = start + feature.LengthMm;
        if (start - grooveWidth / 2d <= 1e-6d || end + grooveWidth / 2d >= support.Height - 1e-6d)
            return Failure("support-bounds", "Thread footprint requires exposed cylindrical stock before and after its finite span.");
        var buildStart = Stopwatch.GetTimestamp();
        var rib = HelicalRibGeometry.Create(new HelicalRibParameters(Point3D.Origin,
            Direction3D.Create(new Vector3D(0d, 0d, 1d)), Direction3D.Create(new Vector3D(1d, 0d, 0d)),
            0d, support.Height, feature.MajorDiameterMm / 2d, rootRadius, feature.PitchMm,
            start, end, grooveWidth, grooveBottomWidth, Intent: HelicalProfileIntent.RemoveGroove));
        if (!rib.IsSuccess) return Failure("geometry-invalid", string.Join(" | ", rib.Diagnostics.Select(d => d.Message)));
        var built = BrepHelicalRib.Create(rib.Value);
        if (!built.IsSuccess) return Failure("brep-invalid", string.Join(" | ", built.Diagnostics.Select(d => d.Message)));
        var constructionMs = Stopwatch.GetElapsedTime(buildStart).TotalMilliseconds;
        var featureId = $"{solid.Name}.{feature.Name}";
        var exportStart = Stopwatch.GetTimestamp();
        var step = Step242Exporter.ExportBody(built.Value.Body, new Step242ExportOptions
        {
            ProductName = featureId,
            ApplicationName = "Aetheris.Firmament.Thread.External.X1",
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce
        });
        if (!step.IsSuccess) return Failure("step-export-failed", string.Join(" | ", step.Diagnostics.Select(d => d.Message)));
        var exportMs = Stopwatch.GetElapsedTime(exportStart).TotalMilliseconds;
        var faceDescendants = built.Value.FaceRoles.Select(pair => new SemanticTopologyDescendant(
            $"{featureId}.Face[{pair.Key.Value}]", "Face", pair.Value switch
            {
                var role when role.StartsWith("LeadingFlank", StringComparison.Ordinal) => SemanticTopologyRole.ThreadLeadingFlank,
                var role when role.StartsWith("TrailingFlank", StringComparison.Ordinal) => SemanticTopologyRole.ThreadTrailingFlank,
                var role when role.StartsWith("Crest", StringComparison.Ordinal) => SemanticTopologyRole.ThreadRootFace,
                var role when role.StartsWith("RootCylinderSkin", StringComparison.Ordinal) => SemanticTopologyRole.ThreadCrest,
                "StartCap" => SemanticTopologyRole.ThreadStartCap,
                "EndCap" => SemanticTopologyRole.ThreadEndCap,
                _ => SemanticTopologyRole.ThreadRootFace
            }, featureId, Face: pair.Key, ParentStableId: featureId,
            Addressability: SemanticTopologyAddressability.DerivedStable));
        var edgeDescendants = built.Value.EdgeRoles.Select(pair => new SemanticTopologyDescendant(
            $"{featureId}.Edge[{pair.Key.Value}]", "Edge", SemanticTopologyRole.ThreadBoundaryEdge,
            featureId, Edge: pair.Key, ParentStableId: featureId,
            Addressability: SemanticTopologyAddressability.DerivedStable));
        var descendants = faceDescendants.Concat(edgeDescendants).ToArray();
        var correspondence = new SemanticTopologyCorrespondence(featureId, descendants,
            ["Thread", "HelicalRib", "BrepHelicalRib"],
            new Dictionary<string, FirmamentV2SourceSpan> { [featureId] = feature.SourceSpan });
        var report = new FirmamentThreadReport(featureId, $"face({solid.Name}.{feature.SupportRole})",
            feature.MajorDiameterMm, 2d * rootRadius, feature.PitchMm, feature.PitchMm, feature.LengthMm,
            start, start, feature.Hand, "metric-60-degree-truncated", (int)double.Round(rib.Value.Turns), built.Value.Body.Topology.Faces.Count(),
            built.Value.Body.Topology.Edges.Count(), built.Value.Body.Topology.Vertices.Count(),
            built.Value.SeamSplits, constructionMs, exportMs,
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))))
        { HeadSideLandMm = start - grooveWidth / 2d, TipSideLandMm = support.Height - end - grooveWidth / 2d };
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(
            step.Value, featureId, 0, "thread-external", "metric-60-degree", Thread: report)
        { RuntimeBody = built.Value.Body, RuntimeCorrespondence = correspondence });
    }

    private static KernelResult<FirmamentStepExportResult> TryExportV2HexBoltThread(
        FirmamentV2Document document, FirmamentV2ThreadDecl feature, FirmamentV2StandardPartRecord authoredPart)
    {
        KernelResult<FirmamentStepExportResult> Failure(string code, string message) =>
            KernelResult<FirmamentStepExportResult>.Failure([new KernelDiagnostic(
                KernelDiagnosticCode.ValidationFailed, KernelDiagnosticSeverity.Error,
                $"thread-{code}: {message}", "FirmamentV2.Thread")]);
        if (authoredPart.Family != "HexBolt")
            return Failure("support-not-hexbolt", "face(Bolt.Shank) is admitted only for the HexBolt standard part.");
        var definition = StandardLibraryReusableParts.TryCreate(authoredPart.Family, authoredPart.Parameters, deferMakerMarkToCompiler: true);
        if (!definition.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(definition.Diagnostics);
        var bolt = definition.Value.HexBolt!;
        if (!double.IsFinite(feature.MajorDiameterMm) || feature.MajorDiameterMm <= 0d ||
            Math.Abs(feature.MajorDiameterMm - bolt.Spec.NominalDiameter) > 1e-6d)
            return Failure("major-diameter-incompatible", "MajorDiameter must equal the HexBolt precursor shank diameter.");
        if (!double.IsFinite(feature.PitchMm) || feature.PitchMm <= 0d)
            return Failure("pitch-invalid", "Pitch must be finite and positive.");
        if (!double.IsFinite(feature.LengthMm) || feature.LengthMm <= 0d)
            return Failure("length-invalid", "Length must be finite and positive.");
        if (feature.StartOffsetMm is { } authoredOffset && (!double.IsFinite(authoredOffset) || authoredOffset < 0d))
            return Failure("start-offset-invalid", "StartOffset must be finite and nonnegative from the under-head shank start.");
        var rootWidth = 5d * feature.PitchMm / 6d;
        var crestWidth = feature.PitchMm / 8d;
        var depth = (rootWidth - crestWidth) * Math.Sqrt(3d) / 2d;
        var rootRadius = feature.MajorDiameterMm / 2d - depth;
        if (rootRadius <= 0d)
            return Failure("profile-self-intersection", "The 60-degree profile depth consumes the support radius.");
        var supportStart = bolt.Spec.UnderHeadRadius;
        var supportEnd = bolt.Dimensions.TipChamferStartX;
        var grooveWidth = feature.PitchMm - crestWidth;
        var grooveBottomWidth = feature.PitchMm - rootWidth;
        var start = supportStart + (feature.StartOffsetMm ?? grooveWidth / 2d + 1d);
        var end = start + feature.LengthMm;
        if (start - grooveWidth / 2d <= supportStart + 1e-6d || end + grooveWidth / 2d >= supportEnd - 1e-6d)
            return Failure("support-bounds", "Thread footprint requires stock margins inside the HexBolt shank, before the tip chamfer.");
        var buildStart = Stopwatch.GetTimestamp();
        var rib = HelicalRibGeometry.Create(new HelicalRibParameters(Point3D.Origin,
            Direction3D.Create(new Vector3D(1d, 0d, 0d)), Direction3D.Create(new Vector3D(0d, 1d, 0d)),
            supportStart, supportEnd, feature.MajorDiameterMm / 2d, rootRadius, feature.PitchMm,
            start, end, grooveWidth, grooveBottomWidth, Intent: HelicalProfileIntent.RemoveGroove));
        if (!rib.IsSuccess) return Failure("geometry-invalid", string.Join(" | ", rib.Diagnostics.Select(d => d.Message)));
        var built = BrepHelicalRib.Create(rib.Value, splitStockRims: true);
        if (!built.IsSuccess) return Failure("brep-invalid", string.Join(" | ", built.Diagnostics.Select(d => d.Message)));
        HexBoltThreadComposition.Result stitched;
        try { stitched = HexBoltThreadComposition.Create(bolt, built.Value); }
        catch (InvalidOperationException ex) { return Failure("hexbolt-stitch-invalid", ex.Message); }
        var constructionMs = Stopwatch.GetElapsedTime(buildStart).TotalMilliseconds;
        var featureId = $"{document.Solid.Name}.{feature.Name}";
        var exportStart = Stopwatch.GetTimestamp();
        var step = Step242Exporter.ExportBody(stitched.Body, new Step242ExportOptions
        {
            ProductName = featureId,
            ApplicationName = "Aetheris.Firmament.Thread.External.X1",
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce
        });
        if (!step.IsSuccess) return Failure("step-export-failed", string.Join(" | ", step.Diagnostics.Select(d => d.Message)));
        var exportMs = Stopwatch.GetElapsedTime(exportStart).TotalMilliseconds;
        var descendants = built.Value.FaceRoles
            .Where(pair => stitched.ThreadFaces.ContainsKey(pair.Key))
            .Select(pair => new SemanticTopologyDescendant(
                $"{featureId}.Face[{pair.Key.Value}]", "Face", pair.Value switch
                {
                    var role when role.StartsWith("LeadingFlank", StringComparison.Ordinal) => SemanticTopologyRole.ThreadLeadingFlank,
                    var role when role.StartsWith("TrailingFlank", StringComparison.Ordinal) => SemanticTopologyRole.ThreadTrailingFlank,
                    var role when role.StartsWith("Crest", StringComparison.Ordinal) => SemanticTopologyRole.ThreadRootFace,
                    var role when role.StartsWith("RootCylinderSkin", StringComparison.Ordinal) => SemanticTopologyRole.ThreadCrest,
                    "StartCap" => SemanticTopologyRole.ThreadStartCap,
                    "EndCap" => SemanticTopologyRole.ThreadEndCap,
                    _ => SemanticTopologyRole.ThreadRootFace
                }, featureId, Face: stitched.ThreadFaces[pair.Key], ParentStableId: featureId,
                Addressability: SemanticTopologyAddressability.DerivedStable))
            .Concat(built.Value.EdgeRoles.Where(pair => stitched.ThreadEdges.ContainsKey(pair.Key))
                .Select(pair => new SemanticTopologyDescendant(
                    $"{featureId}.Edge[{pair.Key.Value}]", "Edge", SemanticTopologyRole.ThreadBoundaryEdge,
                    featureId, Edge: stitched.ThreadEdges[pair.Key], ParentStableId: featureId,
                    Addressability: SemanticTopologyAddressability.DerivedStable))).ToArray();
        var correspondence = new SemanticTopologyCorrespondence(featureId, descendants,
            ["Thread", "HelicalRib", "HexBoltThreadComposition"],
            new Dictionary<string, FirmamentV2SourceSpan> { [featureId] = feature.SourceSpan });
        var boltSemantics = bolt.Semantics.Descendants
            .Where(item => !item.StableId.Contains(".ThreadRegion", StringComparison.Ordinal)
                && (item.Face is null || stitched.BoltFaces.ContainsKey(item.Face.Value)))
            .Select(item => new FirmamentStandardPartSemanticReport(item.StableId, item.Kind.ToString(),
                item.ParentStableId, item.Face is { } face ? stitched.BoltFaces[face].Value : null,
                item.Metadata)).ToArray();
        var boltReport = new FirmamentStandardPartReport(authoredPart.Family,
            document.StaticAuthoring?.Templates.SingleOrDefault()?.Name,
            bolt.DeterministicSignature, authoredPart.Parameters, boltSemantics);
        var report = new FirmamentThreadReport(featureId, $"face({document.Solid.Name}.Shank)",
            feature.MajorDiameterMm, 2d * rootRadius, feature.PitchMm, feature.PitchMm, feature.LengthMm,
            start - supportStart, start, feature.Hand, "metric-60-degree-truncated", (int)Math.Round(rib.Value.Turns),
            stitched.Body.Topology.Faces.Count(), stitched.Body.Topology.Edges.Count(),
            stitched.Body.Topology.Vertices.Count(), built.Value.SeamSplits, constructionMs, exportMs,
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))))
        { HeadSideLandMm = start - supportStart - grooveWidth / 2d, TipSideLandMm = supportEnd - end - grooveWidth / 2d };
        return ApplyHexBoltMakerMark(new FirmamentStepExportResult(
            step.Value, featureId, 0, "thread-external-hexbolt", "metric-60-degree",
            StandardPart: boltReport, Thread: report)
        { RuntimeBody = stitched.Body, RuntimeCorrespondence = correspondence });
    }

    private static KernelResult<FirmamentStepExportResult> ApplyHexBoltMakerMark(FirmamentStepExportResult result)
    {
        var part = result.StandardPart!;
        if (!part.Parameters.TryGetValue("MakerMark", out var content))
            return KernelResult<FirmamentStepExportResult>.Success(result);
        try
        {
            var top = part.SemanticDescendants.Single(d => d.StableId.EndsWith(".Head.TopFlat", StringComparison.Ordinal)).FaceId!.Value;
            var height = double.Parse(part.Parameters["MakerMarkHeight"].Trim()[..^2], System.Globalization.CultureInfo.InvariantCulture);
            var depth = double.Parse(part.Parameters["MakerMarkDepth"].Trim()[..^2], System.Globalization.CultureInfo.InvariantCulture);
            var mark = PlanarCapEngraving.Engrave(result.RuntimeBody!, new FaceId(top),
                HexBoltParameterBinding.Text(content), height, depth);
            var composition = mark.Composition!;
            var semantics = part.SemanticDescendants.Select(d => d.FaceId is { } id
                ? d with { FaceId = id == top ? composition.ReplacementCap.Value : composition.HostFaces[new FaceId(id)].Value }
                : d).ToArray();
            var correspondence = result.RuntimeCorrespondence;
            if (correspondence is not null)
                correspondence = correspondence with
                {
                    Descendants = correspondence.Descendants.Select(d => d with
                    {
                        Face = d.Face is { } face ? composition.HostFaces[face] : null,
                        Edge = d.Edge is { } edge ? composition.HostEdges[edge] : null
                    }).ToArray()
                };
            var thread = result.Thread is { } t ? t with
            {
                Faces = mark.Body.Topology.Faces.Count(), Edges = mark.Body.Topology.Edges.Count(),
                Vertices = mark.Body.Topology.Vertices.Count(),
                StepSha256 = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(mark.StepText)))
            } : null;
            return KernelResult<FirmamentStepExportResult>.Success(result with
            {
                RuntimeBody = mark.Body, RuntimeCorrespondence = correspondence, StepText = mark.StepText,
                Thread = thread, StandardPart = part with { SemanticDescendants = semantics },
                MakerMark = new(HexBoltParameterBinding.Text(content), height, depth, mark.Text.CounterCount)
            });
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new KernelDiagnostic(
                KernelDiagnosticCode.ValidationFailed, KernelDiagnosticSeverity.Error,
                "hexbolt-maker-mark-invalid: " + ex.Message, "FirmamentV2.StandardPart")]);
        }
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2ExactCoaxialPart(FirmamentV2Document document)
    {
        if (document.Solids.Count != 1 || document.Solid.ExactCoaxialPart is not { } authored) return null;
        var recipe = ExactCoaxialPartBuilder.Bind(authored.Parameters);
        if (!recipe.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(recipe.Diagnostics);
        var built = ExactCoaxialPartBuilder.Create(recipe.Value);
        if (!built.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(built.Diagnostics);
        var step = Step242Exporter.ExportBody(built.Value.Body);
        if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var instantiation = document.ConceptIr?.TemplateInstantiations?.SingleOrDefault();
        var record = instantiation?.RecordArguments?.SingleOrDefault().Value;
        // A nested standards Record is still ordinary static data. Publish its leaf fields
        // alongside instance fields so existing construction reports remain ergonomic.
        var parameters = record is null ? authored.Parameters : record.Members
            .Where(pair => !pair.Key.Contains('.', StringComparison.Ordinal) || pair.Key.StartsWith("Standard.", StringComparison.Ordinal))
            .ToDictionary(pair => pair.Key.StartsWith("Standard.", StringComparison.Ordinal) ? pair.Key["Standard.".Length..] : pair.Key, pair => pair.Value, StringComparer.Ordinal);
        var semantics = built.Value.Semantics.Descendants.Select(descendant => new FirmamentStandardPartSemanticReport(
            descendant.StableId, descendant.Kind.ToString(), descendant.ParentStableId, descendant.Face?.Value, descendant.Metadata)).ToArray();
        var report = new FirmamentStandardPartReport("ExactCoaxialPart", instantiation?.Template, built.Value.DeterministicSignature, parameters, semantics);
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, built.Value.Semantics.BodyStableId, 0,
            "template-exact-construction", "ExactCoaxialPart", ConceptIr: document.ConceptIr, StandardPart: report));
    }

    private static KernelResult<FirmamentStepExportResult> ExportComposedSemanticTopBoundaryChamfer(
        string source, PrismaticProfileCompositionParseResult parsed, PrismaticSectionStackConstruction stack, PrismaticSectionStackEmissionResult emitted,
        FirmamentV2Document? canonicalDocument)
    {
        KernelResult<FirmamentStepExportResult> Fail(string code) => KernelResult<FirmamentStepExportResult>.Failure([
            new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, code, "FirmamentV2.ComposeSemanticSelection")]);
        if (ProfileBoundaryChamferSourceBinder.HasSemanticProfileBoundaryFinish(source))
        {
            if (ProfileBoundaryChamferSourceBinder.HasProfileBoundaryFillet(source))
            {
                ProfileBoundaryChamferTarget? filletTarget = null; ResolvedProfile2D? filletProfile = null; double radius = 0d; double clearance = 0d; string? filletDiagnostic = null;
                foreach (var candidate in parsed.Profiles.Values.OrderBy(x => x.Name, StringComparer.Ordinal))
                    if (ProfileBoundaryChamferSourceBinder.TryBindFillet(source, candidate, stack.Feature.Name, out filletTarget, out radius, out clearance, out filletDiagnostic)) { filletProfile = candidate; break; }
                if (filletProfile is null || filletTarget is null) return Fail(filletDiagnostic ?? "ProfileBoundaryFilletProfileUnknown");
                var filletAdmission = ProfileStraightEdgeFilletAdmissionChecker.Check(stack, filletProfile, filletTarget, radius, clearance);
                if (!filletAdmission.Disjoint) return Fail(filletAdmission.Diagnostics.FirstOrDefault() ?? "ProfileBoundaryFilletCavityInteractionUnsupported");
                return Fail("ProfileBoundaryFilletComposeUnsupported");
            }
            ProfileBoundaryChamferTarget? target = null; double distance = 0d; string? bindingDiagnostic = null; ResolvedProfile2D? profile = null;
            foreach (var candidate in parsed.Profiles.Values.OrderBy(x => x.Name, StringComparer.Ordinal))
            {
                if (ProfileBoundaryChamferSourceBinder.TryBind(source, candidate, stack.Feature.Name, out target, out distance, out bindingDiagnostic)) { profile = candidate; break; }
            }
            if (profile is null || target is null) return Fail(bindingDiagnostic ?? "ProfileBoundaryChamferProfileUnknown");
            var admission = ComposedProfileBoundaryChamferAdmissionChecker.Check(stack, profile, target, distance);
            if (!admission.Admitted) return Fail(admission.Diagnostics.FirstOrDefault() ?? "ProfileBoundaryChamferCavityInteractionUnsupported");
            var adjusted = ComposedProfileBoundaryChamferStackPlanner.TryApply(stack, profile, target, distance, out var planDiagnostics);
            if (adjusted is null) return Fail(planDiagnostics.FirstOrDefault() ?? "ProfileBoundaryChamferComposeTopologyPlanNotMaterialized");
            var plannedEmission = PrismaticSectionStackEmitter.Emit(adjusted);
            if (plannedEmission.Body is null) return Fail(plannedEmission.Diagnostics.FirstOrDefault() ?? "ProfileBoundaryChamferComposeMaterializationFailed");
            if (!FirmamentManifoldChecker.IsManifold(plannedEmission.Body)) return Fail("ProfileBoundaryChamferNonManifold");
            var semanticPmi = Array.Empty<Step242SemanticPmi>();
            if (canonicalDocument is not null)
            {
                var support = ValidateV2PmiExportSupport(canonicalDocument);
                if (!support.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(support.Diagnostics);
                var features = (stack.Feature.ShaftHoles ?? []).ToDictionary(hole => hole.Name, hole => hole.StableId, StringComparer.Ordinal);
                foreach (var hole in stack.Feature.CounterboreHoles ?? []) features[hole.Name] = hole.StableId;
                semanticPmi = BuildV2SemanticPmi(canonicalDocument, [], stack.Feature.Name, features, plannedEmission.Correspondence).ToArray();
            }
            var plannedStep = Step242Exporter.ExportBody(plannedEmission.Body, semanticPmi, new Step242ExportOptions { ProductName = target.StableId, ApplicationName = "Aetheris.Firmament.ComposedProfileBoundaryChamfer.M3", BrepExportPreflightMode = BrepExportPreflightMode.Enforce, BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute });
            if (!plannedStep.IsSuccess || plannedStep.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(plannedStep.Diagnostics);
            var plannedReimport = Step242Importer.ImportBody(plannedStep.Value);
            if (!plannedReimport.IsSuccess || plannedReimport.Value is null || !FirmamentManifoldChecker.IsManifold(plannedReimport.Value)) return Fail("ProfileBoundaryChamferStepReimportFailed");
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(plannedStep.Value, target.StableId, 0, "composed-profile-boundary-chamfer-section-stack", "source-grounded-composed-profile-boundary-chamfer",
                DatumInspection: canonicalDocument?.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
                DimensionInspection: canonicalDocument?.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.HoleDiameter).Select(p => new FirmamentPmiInspectionDimension("Diameter", p.Target, null, p.Value ?? 0d, "explicit-v2-record-pmi", p.Name)).ToArray() ?? [],
                Features: CompositionHoleReports(stack.Feature),
                EngineeringFeatures: EngineeringFeatureReports(stack.Feature).Append(new FirmamentEngineeringFeatureReport(
                    target.StableId["edgefinish:".Length..],
                    "EdgeFinish",
                    target.StableId,
                    target.HostBodyId,
                    target.Side.ToString(),
                    $"{target.ProfileId}.{target.LoopId}",
                    distance,
                    "Distance",
                    "Remove",
                    PolicySource: "Chamfer",
                    MaterializationRoute: "ComposedProfileBoundaryChamfer")).ToArray()));
        }
        if (emitted.Body is null || emitted.Correspondence is null) return Fail("MissingCorrespondenceEvidence");
        var composedCurves = stack.Slabs.MaxBy(s => s.To)!.Region.Outer.Loops.Single().Segments.Select(segment => segment.Geometry).ToArray();
        if (!IsAdmittedPrimitiveBoundary(composedCurves))
            return Fail($"{EdgeFinishProfileComposeBoundaryUnsupported}:host={stack.Feature.Name}:construction=Compose:face=+Z:target=Boundary:supported=primitive-box-or-explicit-semantic-chain:Profile/Compose polygon-boundary materialization is not implemented.");
        var selections = SemanticSelectionSourceParser.Parse(source, parsed.Profiles.Values.First(), stack.Feature.Name, out var diagnostics);
        if (diagnostics.Count != 0 || selections.Count != 1) return Fail(diagnostics.FirstOrDefault() ?? "SemanticSourceNotFound");
        var selection = SemanticTopologySelectionResolver.Resolve(emitted.Body, emitted.Correspondence, selections[0]);
        if (!selection.Succeeded) return Fail(string.Join("; ", selection.Diagnostics.Select(diagnostic => $"{diagnostic.Code}: {diagnostic.Message}")));
        if (!selection.IsClosed || selection.Request.Require != SemanticSelectionRequirement.ClosedLoop) return Fail("SelectionConsumerMismatch: EdgeFinish requires a closed semantic boundary loop.");
        var finish = Regex.Match(source, @"\bEdgeFinish\s+(?<name>\w+)\s*\{\s*Target\s*:\s*(?<target>\w+)\s*;?\s*Kind\s*:\s*(?<kind>Chamfer)\s*;?\s*Distance\s*:\s*(?<amount>[-+.\d]+)mm", RegexOptions.Singleline | RegexOptions.CultureInvariant);
        if (!finish.Success || finish.Groups["target"].Value != selection.Request.Label) return Fail("SelectionConsumerMismatch");
        var topSlab = stack.Slabs.MaxBy(s => s.To)!;
        var curves = topSlab.Region.Outer.Loops.Single().Segments.Select(x => x.Geometry).ToArray();
        if (curves.Length < 4 || curves.Any(x => x is not LineArcLineSegment2D)) return Fail("UnsupportedTopologyChange");
        var points = curves.Cast<LineArcLineSegment2D>().SelectMany(x => new[] { x.Start, x.End }).ToArray();
        var minX = points.Min(x => x.X); var maxX = points.Max(x => x.X); var minY = points.Min(x => x.Y); var maxY = points.Max(x => x.Y);
        if (points.Any(p => p.X != minX && p.X != maxX && p.Y != minY && p.Y != maxY)) return Fail("UnsupportedTopologyChange");
        var compiled = AirTopFaceBoundaryChamferCompiler.Compile(new(stack.Feature.Name, $"{stack.Feature.Name}.{finish.Groups["name"].Value}", finish.Groups["name"].Value, maxX - minX, maxY - minY, stack.Feature.CriticalLevels.Max() - stack.Feature.CriticalLevels.Min(), "+Z", "Boundary", "Chamfer", double.Parse(finish.Groups["amount"].Value, System.Globalization.CultureInfo.InvariantCulture), new AirSourceSpan(finish.Index, finish.Length, stack.Feature.Name)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.BRepPlan?.RealizationPlan is null) return Fail(compiled.Diagnostics.FirstOrDefault() ?? "UnsupportedTopologyChange");
        var step = Step242Exporter.ExportBody(compiled.Body, new Step242ExportOptions { ProductName = compiled.Feature.FeatureName, ApplicationName = AirTopFaceBoundaryChamferCompileResult.ProductionRoute, BrepExportPreflightMode = BrepExportPreflightMode.Enforce, BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value)) return Fail("semantic-compose-finish-step-reimport-failed");
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, compiled.Feature.FeatureId, 0, "semantic-compose-edge-finish", "source-grounded-composed-top-boundary-chamfer"));
    }

    private static KernelResult<FirmamentStepExportResult> ExportProfileSemanticTopBoundaryChamfer(
        string source,
        ResolvedProfile2D profile,
        double height,
        LineArcProfileExtrudeResult emitted)
    {
        KernelResult<FirmamentStepExportResult> Fail(string code) => KernelResult<FirmamentStepExportResult>.Failure([
            new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, code, "FirmamentV2.SemanticSelection")]);
        if (ProfileBoundaryChamferSourceBinder.HasSemanticProfileBoundaryFinish(source))
        {
            if (ProfileBoundaryChamferSourceBinder.HasProfileBoundaryFillet(source))
            {
                if (!ProfileBoundaryChamferSourceBinder.TryBindFillet(source, profile, profile.Name, out var filletTarget, out var radius, out var clearance, out var filletDiagnostic))
                    return Fail(filletDiagnostic ?? "ProfileBoundaryFilletBindingFailed");
                var fillet = ProfileFilletShellPlanner.TryPlan(profile, filletTarget!, radius, clearance);
                if (!fillet.Succeeded || fillet.Body is null || fillet.Correspondence is null)
                    return Fail(fillet.Diagnostics.FirstOrDefault() ?? "ProfileBoundaryFilletPlanningFailed");
                if (!FirmamentManifoldChecker.IsManifold(fillet.Body)) return Fail("ProfileBoundaryFilletNonManifold");
                var filletStep = Step242Exporter.ExportBody(fillet.Body, new Step242ExportOptions
                {
                    ProductName = filletTarget!.StableId,
                    ApplicationName = fillet.Plan is null
                        ? "Aetheris.Firmament.ProfileStraightEdgeFillet.M1"
                        : fillet.Plan.Junction is ProfileReflexFilletJunctionPlan
                            ? "Aetheris.Firmament.ProfileReflexFilletJunction.M3"
                            : fillet.Plan.Junction is ProfileReflexSphereSeamCompatibilityJunctionPlan
                                ? "Aetheris.Firmament.ProfileReflexSphereSeamCompatibility.M3"
                                : "Aetheris.Firmament.ProfileConvexFilletJunction.M2",
                    BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
                    BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute
                });
                if (!filletStep.IsSuccess || filletStep.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(filletStep.Diagnostics);
                var filletReimport = Step242Importer.ImportBody(filletStep.Value);
                if (!filletReimport.IsSuccess || filletReimport.Value is null || !FirmamentManifoldChecker.IsManifold(filletReimport.Value)) return Fail("ProfileBoundaryFilletStepReimportFailed");
                var route = fillet.Plan is null
                    ? "profile-straight-edge-fillet"
                    : fillet.Plan.Junction is ProfileReflexFilletJunctionPlan
                        ? "profile-reflex-toroidal-fillet-junction"
                        : fillet.Plan.Junction is ProfileReflexSphereSeamCompatibilityJunctionPlan
                            ? "profile-reflex-sphere-seam-compatibility"
                            : "profile-convex-fillet-junction";
                return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(filletStep.Value, filletTarget.StableId, fillet.Correspondence.Descendants.Count, route, "source-grounded-profile-fillet"));
            }
            if (!ProfileBoundaryChamferSourceBinder.TryBind(source, profile, profile.Name, out var target, out var distance, out var bindingDiagnostic))
                return Fail(bindingDiagnostic ?? "ProfileBoundaryChamferBindingFailed");
            var planned = ProfileBoundaryChamferPlanner.TryPlan(profile, target!, distance);
            if (!planned.Succeeded || planned.Body is null || planned.Correspondence is null)
                return Fail(planned.Diagnostics.FirstOrDefault() ?? "ProfileBoundaryChamferPlanningFailed");
            if (!FirmamentManifoldChecker.IsManifold(planned.Body)) return Fail("ProfileBoundaryChamferNonManifold");
            var plannedStep = Step242Exporter.ExportBody(planned.Body, new Step242ExportOptions
            {
                ProductName = target!.StableId,
                ApplicationName = "Aetheris.Firmament.ProfileBoundaryChamfer.M1",
                BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
                BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute
            });
            if (!plannedStep.IsSuccess || plannedStep.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(plannedStep.Diagnostics);
            var plannedReimport = Step242Importer.ImportBody(plannedStep.Value);
            if (!plannedReimport.IsSuccess || plannedReimport.Value is null || !FirmamentManifoldChecker.IsManifold(plannedReimport.Value)) return Fail("ProfileBoundaryChamferStepReimportFailed");
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(plannedStep.Value, target.StableId, 0, "profile-boundary-chamfer-section-stack", "source-grounded-profile-boundary-chamfer"));
        }
        if (emitted.Body is null || emitted.Correspondence is null) return Fail("NoMaterializedDescendants");
        if (!IsAdmittedPrimitiveBoundary(profile.Loops.Single().Segments.Select(segment => segment.Geometry).ToArray()))
            return Fail($"{EdgeFinishProfileComposeBoundaryUnsupported}:host={profile.Name}:construction=Profile:face=+Z:target=Boundary:supported=primitive-box-or-explicit-semantic-chain:Profile/Compose polygon-boundary materialization is not implemented.");
        var selections = SemanticSelectionSourceParser.Parse(source, profile, profile.Name, out var selectionDiagnostics);
        if (selectionDiagnostics.Count > 0 || selections.Count != 1) return Fail(selectionDiagnostics.FirstOrDefault() ?? "SemanticSourceNotFound");
        var selection = SemanticTopologySelectionResolver.Resolve(emitted.Body, emitted.Correspondence, selections[0]);
        if (!selection.Succeeded) return Fail(string.Join("; ", selection.Diagnostics.Select(diagnostic => $"{diagnostic.Code}: {diagnostic.Message}")));
        var finish = Regex.Match(source, @"\bEdgeFinish\s+(?<name>\w+)\s*\{\s*Target\s*:\s*(?<target>\w+)\s*;?\s*Kind\s*:\s*(?<kind>Chamfer|Fillet)\s*;?\s*(?:Distance|Radius)\s*:\s*(?<amount>[-+.\d]+)mm", RegexOptions.Singleline | RegexOptions.CultureInvariant);
        if (!finish.Success || !string.Equals(finish.Groups["target"].Value, selection.Request.Label, StringComparison.Ordinal)) return Fail("SelectionConsumerMismatch");
        if (!string.Equals(finish.Groups["kind"].Value, "Chamfer", StringComparison.Ordinal) || selection.Request.Require != SemanticSelectionRequirement.ClosedLoop || !selection.IsClosed) return Fail("SelectionConsumerMismatch");
        var lines = profile.Loops.Single().Segments.Select(x => x.Geometry).OfType<LineArcLineSegment2D>().ToArray();
        if (lines.Length != 4 || profile.Loops.Single().Segments.Count != 4) return Fail("UnsupportedTopologyChange");
        var points = lines.SelectMany(x => new[] { x.Start, x.End }).ToArray();
        var minX = points.Min(x => x.X); var maxX = points.Max(x => x.X); var minY = points.Min(x => x.Y); var maxY = points.Max(x => x.Y);
        if (lines.Any(x => Math.Abs(x.Start.X - x.End.X) > 1e-9 && Math.Abs(x.Start.Y - x.End.Y) > 1e-9)) return Fail("UnsupportedTopologyChange");
        var compiled = AirTopFaceBoundaryChamferCompiler.Compile(new(
            profile.Name, $"{profile.Name}.{finish.Groups["name"].Value}", finish.Groups["name"].Value,
            maxX - minX, maxY - minY, height, "+Z", "Boundary", "Chamfer",
            double.Parse(finish.Groups["amount"].Value, System.Globalization.CultureInfo.InvariantCulture),
            new AirSourceSpan(finish.Index, finish.Length, profile.Name)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.BRepPlan?.RealizationPlan is null) return Fail(compiled.Diagnostics.FirstOrDefault() ?? "UnsupportedTopologyChange");
        if (!FirmamentManifoldChecker.IsManifold(compiled.Body)) return Fail("semantic-selection-finish-nonmanifold");
        var step = Step242Exporter.ExportBody(compiled.Body, new Step242ExportOptions { ProductName = compiled.Feature.FeatureName, ApplicationName = AirTopFaceBoundaryChamferCompileResult.ProductionRoute, BrepExportPreflightMode = BrepExportPreflightMode.Enforce, BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value)) return Fail("semantic-selection-finish-step-reimport-failed");
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, compiled.Feature.FeatureId, 0, "semantic-profile-edge-finish", "source-grounded-top-boundary-chamfer"));
    }

    private static bool IsAdmittedPrimitiveBoundary(IReadOnlyList<LineArcProfileCurve2D> curves) =>
        curves.Count == 4
        && curves.All(curve => curve is LineArcLineSegment2D)
        && curves.Cast<LineArcLineSegment2D>().All(line => Math.Abs(line.Start.X - line.End.X) < 1e-9 || Math.Abs(line.Start.Y - line.End.Y) < 1e-9);

    private static KernelResult<FirmamentStepExportResult>? TryExportV2StandaloneCubicLattice(FirmamentV2Document document)
    {
        var fills = document.StandaloneLatticeFills ?? [];
        if (fills.Count == 0) return null;
        if (fills.Count != 1)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, "standalone-fill-multiple-unsupported", "FirmamentV2.CubicLattice")]);
        }

        var fill = fills[0];
        var center = new Point3D(fill.Region.Center[0], fill.Region.Center[1], fill.Region.Center[2]);
        var realization = CubicLatticeBRepPlanner.Create(fill.CellsX, fill.CellsY, fill.CellsZ, fill.CellSize, fill.StrutRadius, fill.NodeRadius, center);
        if (!realization.IsSuccess || realization.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(realization.Diagnostics);
        var body = realization.Value.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid || !FirmamentManifoldChecker.IsManifold(body))
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, "lattice-topology-verification-failed", "FirmamentV2.CubicLattice")]);
        }

        var mass = BrepMassProperties.Evaluate(body);
        if (mass.Status == BrepMassPropertiesStatus.Unavailable || mass.AbsoluteVolume <= 0d || mass.Centroid is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, "lattice-topology-verification-failed: BRep mass properties unavailable", "FirmamentV2.CubicLattice")]);
        }

        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = fill.Name,
            ApplicationName = "Aetheris.Firmament.CubicTruss.M9R",
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
            EmitFullCircleTrimmedCurves = true,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
        {
            return KernelResult<FirmamentStepExportResult>.Failure(reimport.IsSuccess
                ? [new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, "lattice-topology-verification-failed: STEP reimport is not manifold", "FirmamentV2.CubicLattice")]
                : reimport.Diagnostics);
        }

        var template = FirmamentManufacturingPolicyResolver.Resolve(document, "Additive").Single();
        var graph = realization.Value.Plan.Construction;
        var centroid = mass.Centroid.Value;
        var report = new FirmamentStandaloneLatticeReport(
            template.Name, fill.Pattern, [fill.CellsX, fill.CellsY, fill.CellsZ], fill.CellSize, fill.StrutRadius, fill.NodeRadius, fill.Region.Size, fill.Placement,
            graph.Nodes.Count, graph.Members.Count, realization.Value.Plan.SeamCount,
            graph.Nodes.Count(node => node.Valence == 3), graph.Nodes.Count(node => node.Valence == 4), graph.Nodes.Count(node => node.Valence == 5), graph.Nodes.Count(node => node.Valence == 6),
            realization.Value.Plan.IsAuthoritative, realization.Value.Plan.Signature,
            body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(),
            body.Geometry.Surfaces.Count(pair => pair.Value.Kind == SurfaceGeometryKind.Sphere), body.Geometry.Surfaces.Count(pair => pair.Value.Kind == SurfaceGeometryKind.Cylinder),
            realization.Value.AnalyticVolume, mass.AbsoluteVolume, double.Abs(realization.Value.AnalyticVolume - mass.AbsoluteVolume), mass.SurfaceArea,
            [centroid.X, centroid.Y, centroid.Z], Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))).ToLowerInvariant(), true, true);
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, fill.Name, 0, "standalone-lattice", "cubic-truss", Lattice: report));
    }

    /// <summary>
    /// Converts the historical nullable TryExport routes into one explicit dispatcher
    /// contract.  A null is only a Declined route; a non-null failed result has claimed
    /// the document and is terminal.  This keeps route order from deciding feature
    /// composition policy.
    /// </summary>
    private static KernelResult<FirmamentStepExportResult>? DispatchV2Routes(
        FirmamentV2Document document,
        params (string Name, Func<FirmamentV2Document, KernelResult<FirmamentStepExportResult>?> Execute)[] routes)
    {
        foreach (var route in routes)
        {
            var raw = route.Execute(document);
            var result = raw is null ? ExportRouteResult.Decline(route.Name) : ExportRouteResult.Complete(route.Name, raw);
            if (result.Disposition == ExportRouteDisposition.Declined)
            {
                continue;
            }

            return result.Artifact!;
        }

        return null;
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2CombinedHoleEdgeFinishBody(FirmamentV2Document document)
    {
        var modifies = document.ModifyBlocks ?? [];
        var holesDeclared = modifies.SelectMany(m => m.SemanticHoles).ToArray();
        var finishes = modifies.SelectMany(m => (m.EdgeFinishes ?? [])).ToArray();
        if (holesDeclared.Length == 0 || finishes.Length == 0)
        {
            return null;
        }

        if (document.Solids.Count != 1 || modifies.Count != 1 || modifies[0].Regions.Count != 0 || modifies[0].TargetSolid != document.Solids[0].Name)
        {
            return CombinedFailure("CombinedFeatureHostUnsupported: CombinedHoleEdgeFinish requires one Box host and one empty-of-Regions Modify context.");
        }

        var modify = modifies[0];
        var solid = document.Solids[0];
        if (solid.Primitive is not FirmamentV2BoxRecord box || box.Size.Count != 3)
        {
            return CombinedFailure($"CombinedFeatureHostUnsupported: host '{solid.Name}' is not an admitted Box.");
        }

        if (finishes.Length != 1)
        {
            return CombinedFailure($"CombinedFeatureThirdFamilyUnsupported: CombinedHoleEdgeFinish X1 admits exactly one EdgeFinish (actual={finishes.Length}).");
        }

        var finish = finishes[0];
        if (!string.Equals(finish.FaceAxis, "+Z", StringComparison.Ordinal) || !string.Equals(finish.Target, "Boundary", StringComparison.Ordinal) || !string.Equals(finish.Kind, "Chamfer", StringComparison.Ordinal))
        {
            return CombinedFailure($"CombinedFeatureSelectionLost: EdgeFinish '{finish.Name}' must select the +Z outer Boundary with Kind Chamfer.");
        }

        var holes = FirmamentV2SemanticHoleLowering.LowerSemanticHoles(document);
        if (holes.Count != holesDeclared.Length || holes.Count == 0)
        {
            return CombinedFailure("CombinedFeaturePlanChainInvalid: semantic Hole lowering did not preserve the admitted source hole set.");
        }

        // Hole is intentionally the first construction stage.  Existing materialization
        // is used as the semantic/host proof; the bounded final plan below then consumes
        // its same source intent alongside the admitted outer-boundary finish.
        var host = FirmamentStockFrame.ForBox(box.Size[0], box.Size[1], box.Size[2]).CreateHoleHost();
        var holeStages = holes.Select(h => AirHoleSimpleShaftMaterializer.Execute(h, host)).ToArray();
        if (holeStages.Any(stage => !stage.Succeeded || stage.Plan is null))
        {
            return CombinedFailure("CombinedFeatureMaterializerDiverged: admitted semantic Hole stage did not materialize its authoritative plan.", holeStages.SelectMany(stage => stage.Diagnostics));
        }

        var combinedHoles = new List<CombinedTopBoundaryChamferThroughHole>(holes.Count);
        foreach (var (hole, stage) in holes.Zip(holeStages))
        {
            if (hole.EndCondition is not AirHoleEndCondition.ThroughAll || hole.Stack.Kind is not (AirHoleStackKind.SimpleShaft or AirHoleStackKind.Counterbore) || hole.Placement is not AirFaceLocalHolePlacement placement || hole.Axis.Direction.Z < 1d - 1e-9)
            {
                return CombinedFailure($"CombinedFeaturePlanChainInvalid: Hole '{hole.FeatureId}' is outside the shared combined route; only top/+Z shaft or counterbore ThroughAll holes are admitted.");
            }
            var counterbore=hole.Stack.Components.OfType<AirHoleCounterboreComponent>().SingleOrDefault();
            combinedHoles.Add(new CombinedTopBoundaryChamferThroughHole(hole.FeatureId, placement.U, placement.V, hole.Shaft.Radius,counterbore?.Radius,counterbore?.Depth));
        }

        // Resolve and admit the exact EdgeFinish family after the Hole stage.  X1's
        // interaction classification is geometric-plan evidence, not a raw BRep ID or
        // coordinate search: the selected descendant is the known outer boundary role.
        var compiledFinish = AirTopFaceBoundaryChamferCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{finish.Name}", finish.Name,
            box.Size[0], box.Size[1], box.Size[2], finish.FaceAxis, finish.Target, finish.Kind, finish.Distance,
            new AirSourceSpan(finish.SourceSpan.Start, finish.SourceSpan.Length, document.ModelName)));
        if (!compiledFinish.Succeeded || compiledFinish.BRepPlan?.RealizationPlan is null)
        {
            return CombinedFailure("CombinedFeatureSelectionLost: post-Hole outer boundary selection did not admit the exact chamfer planner.", compiledFinish.Diagnostics);
        }

        var parentHolePlan = string.Join(",", holeStages.Select(s => s.Plan!.HoleBRepPlan?.StableId ?? s.Plan!.SemanticFeatureId));
        var finalPlan = new CombinedTopBoundaryChamferThroughHolePlan(
            $"brep-plan:combined-hole-edgefinish:{solid.Name}:{finish.Name}",
            $"brep-plan:host:{solid.Name}->[{parentHolePlan}]",
            ["HostBRepPlan", "HoleChangedBRepPlan", "EdgeFinishChangedBRepPlan"],
            box.Size[0], box.Size[1], host.ZMin, host.ZMax, finish.Distance, combinedHoles);
        var materialized = CombinedTopBoundaryChamferThroughHoleBuilder.Build(finalPlan);
        if (!materialized.IsSuccess || materialized.Value is null)
        {
            return CombinedFailure("CombinedFeatureInteractionUnsupported: Hole descendants and EdgeFinish target are not Disjoint in X1.", materialized.Diagnostics.Select(d => d.Message));
        }

        var body = materialized.Value;
        if (!FirmamentManifoldChecker.IsManifold(body))
        {
            return CombinedFailure("CombinedFeaturePlanChainInvalid: final combined plan did not produce one enclosed manifold body.");
        }
        var pmiSupport = ValidateV2PmiExportSupport(document);
        if (!pmiSupport.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(pmiSupport.Diagnostics);
        }
        var semanticPmi = BuildV2SemanticPmi(document, holes, solid.Name);
        var step = Step242Exporter.ExportBody(body, semanticPmi);
        if (!step.IsSuccess || step.Value is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        }
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
        {
            return CombinedFailure("CombinedFeatureMaterializerDiverged: final STEP reimport did not preserve one enclosed manifold body.", reimport.Diagnostics.Select(d => d.Message));
        }

        var descendants = new List<SemanticTopologyDescendant>();
        var finalTop = body.Topology.Faces.Single(f => f.Id.Value == 2);
        var finalBottom = body.Topology.Faces.Single(f => f.Id.Value == 1);
        var wallFaceId=11;
        for (var i = 0; i < holes.Count; i++)
        {
            var source = $"hole:{holes[i].FeatureId}";
            descendants.Add(new($"combined:{source}:mouth-loop", "Loop", SemanticTopologyRole.HoleEntryLoop, source, Loop: finalTop.LoopIds[i + 1], ParentStableId: holes[i].FeatureId));
            descendants.Add(new($"combined:{source}:exit-loop", "Loop", SemanticTopologyRole.HoleExitLoop, source, Loop: finalBottom.LoopIds[i + 1], ParentStableId: holes[i].FeatureId));
            descendants.Add(new($"combined:{source}:shaft-wall", "Face", SemanticTopologyRole.HoleWallFace, source, Face: new FaceId(wallFaceId++), ParentStableId: holes[i].FeatureId));
            if(combinedHoles[i].IsCounterbore)
                descendants.Add(new($"combined:{source}:counterbore-wall", "Face", SemanticTopologyRole.HoleWallFace, source, Face: new FaceId(wallFaceId++), ParentStableId: holes[i].FeatureId));
        }
        descendants.Add(new($"combined:edgefinish:{finish.Name}:replacement", "Face", SemanticTopologyRole.EdgeFinishReplacementFace, $"edgefinish:{finish.Name}", Face: new FaceId(7), ParentStableId: finish.Name));
        var correspondence = new SemanticTopologyCorrespondence(solid.Name, descendants, ["HostBRepPlan", "HoleChangedBRepPlan", "EdgeFinishChangedBRepPlan", "AuthoritativeBRepPlan"]);
        if (correspondence.Descendants.Count(d => d.Role == SemanticTopologyRole.HoleEntryLoop) != holes.Count || correspondence.Descendants.Count(d => d.Role == SemanticTopologyRole.HoleExitLoop) != holes.Count)
        {
            return CombinedFailure("CombinedFeaturePlanChainInvalid: final plan lost Hole mouth or exit correspondence.");
        }

        var holeRemoved = combinedHoles.Sum(h => System.Math.PI * h.Radius * h.Radius * (host.ZMax - host.ZMin)
            +(h.CounterboreRadius is { } reliefRadius&&h.CounterboreDepth is { } reliefDepth?System.Math.PI*(reliefRadius*reliefRadius-h.Radius*h.Radius)*reliefDepth:0d));
        var report = new FirmamentCombinedFeaturePlanReport(
            "CombinedHoleEdgeFinish", "Succeeded", finalPlan.ParentHostPlanId!, finalPlan.AppliedFeatureIds, finalPlan.PlanId, "Disjoint",
            descendants.Count(d => d.SourceStableId.StartsWith("hole:", StringComparison.Ordinal)), 1,
            box.Size[0] * box.Size[1] * (host.ZMax - host.ZMin), holeRemoved, finalPlan.AnalyticVolume,
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(),
            body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Plane), body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Cylinder), true, true);
        var featureReports = holes.Select(h => new FirmamentHoleFeatureReport(h.Name, "Hole", h.FeatureId, h.Shaft.Diameter, h.Placement.U, h.Placement.V, null, null, null, null, "top", null, nameof(AirHoleSimpleShaftMaterializer), "HoleChangedBRepPlan", h.Stack.Kind.ToString(), "CombinedHoleEdgeFinish", h.Stack.Kind==AirHoleStackKind.Counterbore?2:1, 0, h.Stack.Kind==AirHoleStackKind.Counterbore?1:0, report.StepSha256, true)).ToArray();
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(
            step.Value,
            finish.Name,
            0,
            "combined-hole-edgefinish",
            "CombinedHoleEdgeFinish",
            DatumInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
            DimensionInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.HoleDiameter).Select(p => new FirmamentPmiInspectionDimension("Diameter", p.Target, null, p.Value ?? 0d, "explicit-v2-semantic-pmi", p.Name)).ToArray() ?? [],
            ConceptIr: document.ConceptIr,
            Features: featureReports,
            Combined: report));
    }

    private static KernelResult<FirmamentStepExportResult> CombinedFailure(string message, IEnumerable<string>? details = null) =>
        KernelResult<FirmamentStepExportResult>.Failure((new[] { message }).Concat(details ?? []).Distinct().Select(detail => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            detail,
            "FirmamentV2.CombinedHoleEdgeFinish")).ToArray());

    private static KernelResult<FirmamentStepExportResult>? TryExportV2AirChamferBody(FirmamentV2Document document)
    {
        var finishes = (document.ModifyBlocks ?? []).SelectMany(m => (m.EdgeFinishes ?? []).Select(f => (Modify: m, Finish: f))).ToArray();
        if (finishes.Length == 0) return null;
        // A narrow finish-only route never owns a document that also has semantic holes.
        // CombinedHoleEdgeFinish is the only X1 route permitted to claim that shape.
        if ((document.ModifyBlocks ?? []).Any(m => m.SemanticHoles.Count > 0)) return null;
        if (finishes.Length == 2 && finishes.All(x => string.Equals(x.Finish.Kind, "Chamfer", StringComparison.Ordinal)))
        {
            if (document.Solids.Count != 1 || document.ModifyBlocks!.Count != 1 || document.ModifyBlocks[0].Regions.Count != 0 || document.ModifyBlocks[0].SemanticHoles.Count != 0)
                return AirChamferFailure("localized-junction-production-route-requires-one-box-and-one-modify-block");
            var junctionSolid = document.Solids.SingleOrDefault(s => s.Name == finishes[0].Modify.TargetSolid);
            if (junctionSolid?.Primitive is not FirmamentV2BoxRecord junctionBox || junctionBox.Size.Count != 3)
                return AirChamferFailure("localized-junction-unsupported-history:expected-history-known-box");
            return ExportV2LocalizedEdgeJunctionChamfer(document, junctionSolid, finishes[0].Finish, finishes[1].Finish, junctionBox);
        }
        if (finishes.Length == 2 && finishes.All(x => string.Equals(x.Finish.Kind, "Fillet", StringComparison.Ordinal)))
        {
            if (document.Solids.Count != 1 || document.ModifyBlocks!.Count != 1 || document.ModifyBlocks[0].Regions.Count != 0 || document.ModifyBlocks[0].SemanticHoles.Count != 0)
                return AirChamferFailure("localized-fillet-junction-production-route-requires-one-box-and-one-modify-block");
            var junctionSolid = document.Solids.SingleOrDefault(s => s.Name == finishes[0].Modify.TargetSolid);
            if (junctionSolid?.Primitive is not FirmamentV2BoxRecord junctionBox || junctionBox.Size.Count != 3)
                return AirChamferFailure("localized-fillet-junction-unsupported-history:expected-history-known-box");
            return ExportV2LocalizedEdgeJunctionFillet(document, junctionSolid, finishes[0].Finish, finishes[1].Finish, junctionBox);
        }
        if (finishes.Length == 3 && finishes.All(x => string.Equals(x.Finish.Kind, "Fillet", StringComparison.Ordinal)))
        {
            if (document.Solids.Count != 1 || document.ModifyBlocks!.Count != 1 || document.ModifyBlocks[0].Regions.Count != 0 || document.ModifyBlocks[0].SemanticHoles.Count != 0)
                return AirChamferFailure("localized-trihedral-fillet-production-route-requires-one-box-and-one-modify-block");
            var junctionSolid = document.Solids.SingleOrDefault(s => s.Name == finishes[0].Modify.TargetSolid);
            if (junctionSolid?.Primitive is not FirmamentV2BoxRecord junctionBox || junctionBox.Size.Count != 3)
                return AirChamferFailure("localized-trihedral-fillet-unsupported-history:expected-history-known-box");
            return ExportV2LocalizedTrihedralFillet(document, junctionSolid, finishes.Select(x => x.Finish).ToArray(), junctionBox);
        }
        if (finishes.Length == 3)
            return AirChamferFailure("localized-trihedral-fillet-unsupported-finish-combination:mixed-families");
        if (finishes.Length == 2)
            return AirChamferFailure("localized-junction-unsupported-finish-combination:mixed-families");
        if (finishes.Length > 2)
            return AirChamferFailure("localized-trihedral-fillet-unsupported-valence:three-selected-edges-maximum");
        if (finishes.Length != 1 || document.Solids.Count != 1 || document.ModifyBlocks!.Count != 1
            || document.ModifyBlocks[0].Regions.Count != 0 || document.ModifyBlocks[0].SemanticHoles.Count != 0)
            return AirChamferFailure("air-chamfer-production-route-requires-one-box-and-one-edge-finish");

        var (modify, finish) = finishes[0];
        var solid = document.Solids.SingleOrDefault(s => s.Name == modify.TargetSolid);
        if (solid?.Primitive is FirmamentV2CylinderRecord cylinder)
            return ExportV2CircularRimChamfer(document, solid, finish, cylinder);
        if (solid?.Primitive is not FirmamentV2BoxRecord box || box.Size.Count != 3)
            return AirChamferFailure("chamfer-unsupported-history:expected-history-known-box-or-right-circular-cylinder");

        // AIR-FILLET-LOCALIZED-M1: semantic support-face selection only; emitted BRep IDs never enter Firmament.
        if (string.Equals(finish.Kind, "Fillet", StringComparison.Ordinal))
            return ExportV2LocalizedTangentBlendSingleEdgeFillet(document, solid, finish, box);

        // AIR-CHAMFER-LOCALIZED-PLAN-A1: a semantic face-pair selector, never an emitted edge id.
        if (string.Equals(finish.FaceAxis, "+X", StringComparison.Ordinal)
            && string.Equals(finish.Target, "SharedEdgePlusZ", StringComparison.Ordinal))
            return ExportV2LocalizedPlanarSingleEdgeChamfer(document, solid, finish, box);

        var compiled = AirTopFaceBoundaryChamferCompiler.Compile(new(
            solid.Name,
            $"{solid.Name}.{finish.Name}",
            finish.Name,
            box.Size[0], box.Size[1], box.Size[2],
            finish.FaceAxis, finish.Target, finish.Kind, finish.Distance,
            new AirSourceSpan(finish.SourceSpan.Start, finish.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.RealizationPlan is null || compiled.Topology is null)
            return AirChamferFailure(compiled.Feature.AdmissionReason, compiled.Diagnostics);

        var manifold = FirmamentManifoldChecker.IsManifold(compiled.Body);
        if (!manifold) return AirChamferFailure("air-chamfer-emitted-body-is-not-manifold", compiled.Diagnostics);

        var step = Step242Exporter.ExportBody(compiled.Body, new Step242ExportOptions
        {
            ProductName = compiled.Feature.FeatureName,
            ApplicationName = AirTopFaceBoundaryChamferCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);

        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
        var reimported = reimport.Value;
        var reimportedManifold = FirmamentManifoldChecker.IsManifold(reimported);
        if (!reimportedManifold) return AirChamferFailure("air-chamfer-step-reimport-is-not-manifold");

        var plan = compiled.BRepPlan.RealizationPlan;
        var top = plan.Vertices.Where(v => v.SectionIndex == 2).Select(v => v.Point).ToArray();
        var sourceBounds = Bounds(compiled.Body);
        var reimportedBounds = Bounds(reimported);
        var featureProvenance = new Dictionary<string, string>(StringComparer.Ordinal);
        if (solid.Provenance?.TryGetValue("Bounds", out var boundsProvenance) == true) featureProvenance["Bounds"] = boundsProvenance;
        if (finish.Provenance?.TryGetValue("Face", out var faceProvenance) == true) featureProvenance["Selection"] = faceProvenance;
        if (finish.Provenance?.TryGetValue("Distance", out var distanceProvenance) == true) featureProvenance["Distance"] = distanceProvenance;
        var report = new FirmamentAirChamferReport(
            new("Chamfer", compiled.Feature.BodyId, compiled.Feature.FeatureId, compiled.Feature.FeatureName, $"FaceBoundary({compiled.Feature.Selection.FaceAxis})", compiled.Feature.Rule.Distance, compiled.Feature.Rule.Unit, $"{compiled.Feature.SourceSpan.Start}:{compiled.Feature.SourceSpan.Length}", compiled.Feature.Admission.ToString(), compiled.Feature.AdmissionReason, featureProvenance),
            new("SectionTransition", compiled.Construction.Profiles.Count, compiled.Construction.Profiles.Select(p => p.Z).ToArray(), compiled.Construction.Transition.Correspondence, compiled.Construction.Transition.SplitPolicy),
            new(compiled.BRepPlan.IsAuthoritative, plan.Vertices.Count, plan.Edges.Count, plan.Faces.Count, plan.ExpectedLoopCount, plan.ExpectedCoedgeCount, compiled.BRepPlan.Summary.ChamferFaceCount, plan.SplitPolicy, plan.DeterministicSignature),
            new(AirTopFaceBoundaryChamferCompileResult.ProductionRoute, false, manifold, compiled.Topology.VertexCount, compiled.Topology.EdgeCount, compiled.Topology.FaceCount, sourceBounds,
                top.Min(p => p.X) - (-box.Size[0] / 2d), top.Min(p => p.Y) - (-box.Size[1] / 2d)),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true,
                reimported.Topology.Vertices.Count(), reimported.Topology.Edges.Count(), reimported.Topology.Faces.Count(), reimportedBounds, reimportedManifold));

        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(
            step.Value, compiled.Feature.FeatureId, 0, "air-chamfer", "top-face-boundary-chamfer", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2LocalizedPlanarSingleEdgeChamfer(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        FirmamentV2EdgeFinishDecl finish,
        FirmamentV2BoxRecord box)
    {
        var compiled = AirLocalizedPlanarReplacementChamferCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{finish.Name}", finish.Name, box.Size[0], box.Size[1], box.Size[2],
            finish.FaceAxis, "+Z", finish.Kind, finish.Distance,
            new AirSourceSpan(finish.SourceSpan.Start, finish.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.LocalizedEdgeReplacementRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? compiled.Feature.AdmissionReason, compiled.Diagnostics);

        var body = compiled.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return AirChamferFailure("localized-chamfer-preflight-verification-failed", preflight.Diagnostics.Select(d => d.Code));
        if (!FirmamentManifoldChecker.IsManifold(body)) return AirChamferFailure("localized-chamfer-emitted-body-is-not-manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = compiled.Feature.FeatureName,
            ApplicationName = AirLocalizedPlanarReplacementChamferCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return AirChamferFailure("localized-chamfer-step-reimport-verification-failed");

        var plan = compiled.Construction.TopologyPlan;
        var witness = compiled.Construction.Witness;
        var planes = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Plane);
        var report = new FirmamentAirChamferReport(
            new("Chamfer", compiled.Feature.BodyId, compiled.Feature.FeatureId, compiled.Feature.FeatureName, "SharedEdge(+X,+Z)", finish.Distance, "mm",
                $"{compiled.Feature.SourceSpan.Start}:{compiled.Feature.SourceSpan.Length}", compiled.Feature.Admission.ToString(), compiled.Feature.AdmissionReason,
                new Dictionary<string, string> { ["Selection"] = "semantic Face(+X),Face(+Z)", ["MaterialSide"] = witness.MaterialSide }),
            new("LocalizedPlanarReplacement", 0, [], "ordered-explicit-loops", "ExplicitOwnedEndpoints",
                $"retainedFaces=2;replacementFaces=1;endpointPolicy={witness.EndpointPolicy}", true),
            new(true, plan.ExpectedVertexCount, plan.ExpectedEdgeCount, plan.ExpectedFaceCount, plan.ExpectedLoopCount, plan.ExpectedCoedgeCount, 1,
                "ExplicitOwnedEndpoints", plan.DeterministicSignature, "LocalizedPlanarReplacement"),
            new(AirLocalizedPlanarReplacementChamferCompileResult.ProductionRoute, false, true, body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), Bounds(body), finish.Distance, finish.Distance, 0, 0, planes),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), Bounds(reimport.Value), true),
            new("SharedEdge(+X,+Z)", "LocalizedPlanarReplacement", "Direct", 2, 1, "ExplicitOwnedEndpoints", new(true, plan.DeterministicSignature), "valid", false),
            LocalizedEdgeFinish: new("Chamfer", "SharedEdge(+X,+Z)", "EqualDistance", finish.Distance, "LocalizedEdgeReplacement", "PlanarChamfer", "Direct", 2, 1, "ExplicitOwnedEndpoints", new(true, plan.DeterministicSignature), "valid", false));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, compiled.Feature.FeatureId, 0, "air-chamfer", "localized-planar-single-edge-chamfer", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2LocalizedEdgeJunctionChamfer(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        FirmamentV2EdgeFinishDecl first,
        FirmamentV2EdgeFinishDecl second,
        FirmamentV2BoxRecord box)
    {
        var compiled = AirLocalizedEdgeJunctionChamferCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{first.Name}.{second.Name}", $"{first.Name}+{second.Name}", box.Size[0], box.Size[1], box.Size[2],
            first.FaceAxis, first.Target, second.FaceAxis, second.Target, first.Distance, second.Distance,
            new AirSourceSpan(first.SourceSpan.Start, first.SourceSpan.Length + second.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.LocalizedEdgeJunctionRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? "localized-junction-construction-witness-required", compiled.Diagnostics);

        var body = compiled.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return AirChamferFailure("localized-junction-chamfer-preflight-verification-failed", preflight.Diagnostics.Select(d => d.Code));
        if (!FirmamentManifoldChecker.IsManifold(body)) return AirChamferFailure("localized-junction-chamfer-emitted-body-is-not-manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = compiled.Construction.ConstructionId,
            ApplicationName = AirLocalizedEdgeJunctionChamferCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return AirChamferFailure("localized-junction-chamfer-step-reimport-verification-failed");

        var topology = compiled.Construction.TopologyPlan;
        var planes = body.Geometry.Surfaces.Count(surface => surface.Value.Kind == SurfaceGeometryKind.Plane);
        var report = new FirmamentAirChamferReport(
            new("Chamfer", solid.Name, $"{solid.Name}.{first.Name}.{second.Name}", $"{first.Name}+{second.Name}", "SharedEdge(+X,+Z),SharedEdge(+Y,+Z)", first.Distance, "mm",
                $"{first.SourceSpan.Start}:{first.SourceSpan.Length}|{second.SourceSpan.Start}:{second.SourceSpan.Length}", "Admitted", "localized-junction-direct-single-miter-candidate",
                new Dictionary<string, string> { ["Selection"] = "semantic Face(+X),Face(+Z); Face(+Y),Face(+Z)", ["MaterialSide"] = compiled.Construction.MaterialSide }),
            new("LocalizedEdgeJunction", 0, [], "ordered-explicit-loops", "SharedMiterEdge",
                $"replacementFaces=2;junctionFaces=0;cornerPatch={compiled.Construction.CornerPatch.Kind};boundaryOwnership={compiled.Construction.BoundaryOwnership}", true),
            new(true, topology.ExpectedVertexCount, topology.ExpectedEdgeCount, topology.ExpectedFaceCount, topology.ExpectedLoopCount, topology.ExpectedCoedgeCount, 2,
                "SharedMiterEdge", topology.DeterministicSignature, "LocalizedEdgeJunction"),
            new(AirLocalizedEdgeJunctionChamferCompileResult.ProductionRoute, false, true, body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), Bounds(body), first.Distance, first.Distance, 0, 0, planes),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), Bounds(reimport.Value), true),
            LocalizedEdgeJunction: new(["SharedEdge(+X,+Z)", "SharedEdge(+Y,+Z)"], "Chamfer", "EqualDistance", first.Distance, "Direct", "LocalizedEdgeJunction", compiled.Construction.CornerPatch.Kind, 2, 0,
                new(true, topology.DeterministicSignature), "valid", false, 1, 1));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, $"{solid.Name}.{first.Name}.{second.Name}", 0, "air-chamfer", "localized-edge-junction-chamfer", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2LocalizedEdgeJunctionFillet(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        FirmamentV2EdgeFinishDecl first,
        FirmamentV2EdgeFinishDecl second,
        FirmamentV2BoxRecord box)
    {
        var compiled = AirLocalizedEdgeJunctionFilletCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{first.Name}.{second.Name}", $"{first.Name}+{second.Name}", box.Size[0], box.Size[1], box.Size[2],
            first.FaceAxis, first.Target, second.FaceAxis, second.Target, first.Distance, second.Distance,
            new AirSourceSpan(first.SourceSpan.Start, first.SourceSpan.Length + second.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.LocalizedEdgeJunctionRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? "localized-fillet-junction-direct-intersection-required", compiled.Diagnostics);

        var body = compiled.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return AirChamferFailure("localized-fillet-junction-preflight-verification-failed", preflight.Diagnostics.Select(d => d.Code));
        if (!FirmamentManifoldChecker.IsManifold(body)) return AirChamferFailure("localized-fillet-junction-emitted-body-is-not-manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = compiled.Construction.ConstructionId,
            ApplicationName = AirLocalizedEdgeJunctionFilletCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return AirChamferFailure("localized-fillet-junction-step-reimport-verification-failed");

        var topology = compiled.Construction.TopologyPlan;
        var cylinders = body.Geometry.Surfaces.Count(surface => surface.Value.Kind == SurfaceGeometryKind.Cylinder);
        var planes = body.Geometry.Surfaces.Count(surface => surface.Value.Kind == SurfaceGeometryKind.Plane);
        var report = new FirmamentAirChamferReport(
            new("Fillet", solid.Name, $"{solid.Name}.{first.Name}.{second.Name}", $"{first.Name}+{second.Name}", "SharedEdge(+X,+Z),SharedEdge(+Y,+Z)", first.Distance, "mm",
                $"{first.SourceSpan.Start}:{first.SourceSpan.Length}|{second.SourceSpan.Start}:{second.SourceSpan.Length}", "Admitted", "localized-fillet-junction-direct-intersection-candidate",
                new Dictionary<string, string> { ["Selection"] = "semantic Face(+X),Face(+Z); Face(+Y),Face(+Z)", ["MaterialSide"] = compiled.Construction.MaterialSide, ["Branch"] = compiled.Construction.Closure.Branch }),
            new("LocalizedEdgeJunction", 0, [], "ordered-explicit-loops", "DirectIntersectionEllipse",
                $"replacementFaces=2;junctionFaces=0;sharedEdges=1;curve=Ellipse;branch={compiled.Construction.Closure.Branch}", true),
            new(true, topology.ExpectedVertexCount, topology.ExpectedEdgeCount, topology.ExpectedFaceCount, topology.ExpectedLoopCount, topology.ExpectedCoedgeCount, 0,
                "DirectIntersectionEllipse", topology.DeterministicSignature, "LocalizedEdgeJunction"),
            new(AirLocalizedEdgeJunctionFilletCompileResult.ProductionRoute, false, true, body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), Bounds(body), first.Distance, first.Distance, cylinders, 0, planes),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), Bounds(reimport.Value), true),
            LocalizedEdgeJunction: new(["SharedEdge(+X,+Z)", "SharedEdge(+Y,+Z)"], "Fillet", "ConstantRadius", first.Distance, "Direct", "LocalizedEdgeJunction", "None(DirectIntersection)", 2, 0,
                new(true, topology.DeterministicSignature), "valid", false, 1, 1,
                new("DirectIntersection", "Cylinder", "Cylinder", "Ellipse", true, 1, compiled.Construction.Closure.Branch)));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, $"{solid.Name}.{first.Name}.{second.Name}", 0, "air-fillet", "localized-edge-junction-fillet", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2HollowBody(FirmamentV2Document document)
    {
        if (document.Solids.Count != 1 || document.Solid.ConstructionPolicy != FirmamentV2ConstructionPolicy.Hollow)
            return null;
        // A parsed Perforation must reach its own topology route. Exporting the
        // unmodified Hollow here would silently lose the authored openings.
        if ((document.ModifyBlocks ?? []).Any(block => (block.Perforations?.Count ?? 0) > 0)) return null;
        var solid = document.Solid;
        if (solid.Hollow is null || solid.Hollow.Openings.Count != 1 || solid.Hollow.Openings[0] != "Top")
            return HollowFailure("UnsupportedOpening");

        KernelResult<ThinWalledBodyRealization> realization = solid.Primitive switch
        {
            FirmamentV2RoundedBoxRecord rounded when rounded.Size.Count == 3 => ThinWalledBodyBRepPlanner.CreateRoundedBox(rounded.Size[0], rounded.Size[1], rounded.Size[2], rounded.CornerRadius, solid.Hollow.WallThickness),
            FirmamentV2FrustumRecord frustum => ThinWalledBodyBRepPlanner.CreateFrustum(frustum.BottomRadius, frustum.TopRadius, frustum.Height, solid.Hollow.WallThickness),
            FirmamentV2CylinderRecord cylinder => ThinWalledBodyBRepPlanner.CreateCylinder(cylinder.Radius, cylinder.Height, solid.Hollow.WallThickness, solid.Hollow.BottomBlendRadius),
            _ => throw new InvalidOperationException("Parser admitted a Hollow policy without a HollowConstructible witness.")
        };
        if (!realization.IsSuccess || realization.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(realization.Diagnostics);
        var body = realization.Value.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return HollowFailure("VerificationFailure");
        if (!FirmamentManifoldChecker.IsManifold(body)) return HollowFailure("VerificationFailure: vessel boundary is not a closed manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = solid.Name,
            ApplicationName = "Aetheris.Firmament.Primitive<Hollow>",
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
        var reimportedManifold = FirmamentManifoldChecker.IsManifold(reimport.Value);
        if (!reimportedManifold) return HollowFailure("VerificationFailure: STEP reimport vessel boundary is not manifold");
        var surfaces = body.Geometry.Surfaces.Select(x => x.Value.Kind).ToArray();
        var r = realization.Value;
        var volume = solid.Primitive switch
        {
            FirmamentV2RoundedBoxRecord rounded => RoundedHollowVolume(rounded, r.Feature.WallThickness),
            FirmamentV2FrustumRecord frustum => FrustumHollowVolume(frustum, r.Feature.WallThickness),
            FirmamentV2CylinderRecord cylinder => CylinderHollowVolume(cylinder, r.Feature.WallThickness, solid.Hollow.BottomBlendRadius),
            _ => throw new InvalidOperationException("Unsupported Hollow volume witness.")
        };
        var report = new FirmamentHollowBodyReport(r.Feature.PrimitiveKind, "Hollow", r.Feature.WallThickness, r.Feature.Openings, r.Feature.Witness.Kind, r.Feature.Witness.Exact,
            r.Feature.ThicknessPolicy, r.Construction.ThicknessWitnesses.All(w => w.Exact && double.Abs(w.Distance - r.Feature.WallThickness) <= 1e-9), r.Plan.Kind, r.Plan.IsAuthoritative, r.Plan.DeterministicSignature,
            body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), surfaces.Count(x => x == SurfaceGeometryKind.Plane), surfaces.Count(x => x == SurfaceGeometryKind.Cylinder), surfaces.Count(x => x == SurfaceGeometryKind.Cone), r.Plan.RimFaces.Count,
            volume, Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimportedManifold);
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, solid.Name, 0, "air-hollow", "thin-walled-body", Hollow: report));
    }

    private static string RoundedHollowVolume(FirmamentV2RoundedBoxRecord rounded, double t)
    {
        var outerArea = RoundedRectangleArea(rounded.Size[0], rounded.Size[1], rounded.CornerRadius);
        var innerArea = RoundedRectangleArea(rounded.Size[0] - 2d * t, rounded.Size[1] - 2d * t, rounded.CornerRadius - t);
        var analytic = outerArea * rounded.Size[2] - innerArea * (rounded.Size[2] - t);
        var numerical = RoundedRectangleAreaNumerical(rounded.Size[0], rounded.Size[1], rounded.CornerRadius) * rounded.Size[2]
            - RoundedRectangleAreaNumerical(rounded.Size[0] - 2d * t, rounded.Size[1] - 2d * t, rounded.CornerRadius - t) * (rounded.Size[2] - t);
        return FormattableString.Invariant($"analytic={analytic:R};numericalSimpson={numerical:R};delta={double.Abs(analytic - numerical):R}");
    }

    private static string CylinderHollowVolume(FirmamentV2CylinderRecord cylinder, double t, double blendRadius)
    {
        var innerRadius = cylinder.Radius - t;
        var analytic = blendRadius == 0
            ? double.Pi * (cylinder.Radius * cylinder.Radius * cylinder.Height - innerRadius * innerRadius * (cylinder.Height - t))
            : BlendedCylinderVolume(cylinder.Radius, innerRadius, cylinder.Height, t, blendRadius);
        return FormattableString.Invariant($"analytic={analytic:R}");
    }

    private static double BlendedCylinderVolume(double outerRadius, double innerRadius, double height, double thickness, double blendRadius)
    {
        var major = outerRadius - blendRadius;
        static double QuarterProfileIntegral(double majorRadius, double minorRadius) =>
            majorRadius * majorRadius * minorRadius + majorRadius * double.Pi * minorRadius * minorRadius / 2d +
            2d * minorRadius * minorRadius * minorRadius / 3d;
        return double.Pi * (QuarterProfileIntegral(major, blendRadius) - QuarterProfileIntegral(major, blendRadius - thickness) +
            (outerRadius * outerRadius - innerRadius * innerRadius) * (height - blendRadius));
    }

    private static string FrustumHollowVolume(FirmamentV2FrustumRecord frustum, double t)
    {
        var k = (frustum.TopRadius - frustum.BottomRadius) / frustum.Height;
        var q = t * double.Sqrt(1d + k * k);
        var ib = frustum.BottomRadius + k * t - q; var it = frustum.TopRadius - q;
        var outer = double.Pi * frustum.Height * (frustum.BottomRadius * frustum.BottomRadius + frustum.BottomRadius * frustum.TopRadius + frustum.TopRadius * frustum.TopRadius) / 3d;
        var innerHeight = frustum.Height - t;
        var inner = double.Pi * innerHeight * (ib * ib + ib * it + it * it) / 3d;
        var analytic = outer - inner;
        var numerical = Simpson(0d, frustum.Height, z => double.Pi * double.Pow(frustum.BottomRadius + k * z, 2d))
            - Simpson(t, frustum.Height, z => double.Pi * double.Pow(frustum.BottomRadius + k * z - q, 2d));
        return FormattableString.Invariant($"analytic={analytic:R};numericalSimpson={numerical:R};delta={double.Abs(analytic - numerical):R}");
    }

    private static double RoundedRectangleArea(double width, double depth, double radius) => width * depth - (4d - double.Pi) * radius * radius;

    private static double RoundedRectangleAreaNumerical(double width, double depth, double radius)
    {
        // Parameterizing each quarter-circle by theta avoids the square-root endpoint singularity
        // of direct Cartesian sampling, while still providing an independent numerical integral.
        var straight = (width - 2d * radius) * depth;
        var cornerBands = 4d * radius * (depth / 2d - radius);
        var quarterCircleIntegral = Simpson(0d, double.Pi / 2d, theta => double.Cos(theta) * double.Cos(theta));
        return straight + cornerBands + 4d * radius * radius * quarterCircleIntegral;
    }

    private static double Simpson(double start, double end, Func<double, double> f)
    {
        const int segments = 16384; // even; deterministic numerical evidence, independent of closed-form volume.
        var step = (end - start) / segments; var sum = f(start) + f(end);
        for (var i = 1; i < segments; i++) sum += (i % 2 == 0 ? 2d : 4d) * f(start + i * step);
        return sum * step / 3d;
    }

    private static KernelResult<FirmamentStepExportResult> HollowFailure(string message) =>
        KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "FirmamentV2.Hollow")]);

    private static KernelResult<FirmamentStepExportResult>? TryExportV2RoundedBoxBody(FirmamentV2Document document)
    {
        if (document.Solids.Count != 1 || document.Solids[0].Primitive is not FirmamentV2RoundedBoxRecord rounded || rounded.Size.Count != 3)
            return null;
        var solid = document.Solids[0];
        var finishes = (document.ModifyBlocks ?? []).SelectMany(m => m.EdgeFinishes ?? []).ToArray();
        if (finishes.Length > 1) return RoundedBoxFailure("unsupported top/whole-body or mixed edge-finish request");
        double? fillet = null;
        if (finishes.Length == 1)
        {
            var finish = finishes[0];
            if (!string.Equals(finish.FaceAxis, "+Z", StringComparison.Ordinal) || !string.Equals(finish.Target, "Boundary", StringComparison.Ordinal) || !string.Equals(finish.Kind, "Fillet", StringComparison.Ordinal))
                return RoundedBoxFailure("UnsupportedSupportPair");
            fillet = finish.Distance;
        }
        var realization = RoundedBoxBRepPlanner.Create(rounded.Size[0], rounded.Size[1], rounded.Size[2], rounded.CornerRadius, fillet);
        if (!realization.IsSuccess || realization.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(realization.Diagnostics);
        var body = realization.Value.Body; var plan = realization.Value.Plan;
        if (!FirmamentManifoldChecker.IsManifold(body)) return RoundedBoxFailure("VerificationFailure: rounded-box body is not manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = solid.Name,
            ApplicationName = "AIR-ROUNDED-BOX-M6",
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var imported = Step242Importer.ImportBody(step.Value);
        if (!imported.IsSuccess || imported.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(imported.Diagnostics);
        if (!FirmamentManifoldChecker.IsManifold(imported.Value)) return RoundedBoxFailure("VerificationFailure: STEP reimport is not manifold");
        var surfaces = body.Geometry.Surfaces.Select(x => x.Value.Kind).ToArray();
        var preflight = BrepExportPreflight.Validate(body);
        var report = new FirmamentRoundedBoxReport(
            new("RoundedBoxFeature", "RoundedRectangleProfile -> LinearSweep", rounded.Size[0], rounded.Size[1], rounded.Size[2], rounded.CornerRadius,
                4, surfaces.Count(x => x == SurfaceGeometryKind.Cylinder) - (fillet is null ? 0 : 4), false),
            fillet is null ? null : new("TopBoundary", "Fillet", fillet.Value, 4, 4, rounded.CornerRadius - fillet.Value, fillet.Value,
                $"torus axis=+Z; center is each corner cylinder axis at z=top-{fillet.Value:R}; major=Rc-Rf={rounded.CornerRadius - fillet.Value:R}; minor=Rf={fillet.Value:R}; v=pi/2 is the top-plane trim and v=0 is the retained corner-cylinder trim."),
            new(plan.IsAuthoritative, plan.DeterministicSignature, plan.ExpectedVertexCount, plan.ExpectedEdgeCount, plan.ExpectedFaceCount, plan.ExpectedLoopCount, plan.ExpectedCoedgeCount, plan.FaceRoles),
            new(Bounds(body), true, surfaces.Count(x => x == SurfaceGeometryKind.Plane), surfaces.Count(x => x == SurfaceGeometryKind.Cylinder), surfaces.Count(x => x == SurfaceGeometryKind.Torus), RoundedBoxAnalyticVolume(rounded.Size[0], rounded.Size[1], rounded.Size[2], rounded.CornerRadius, fillet), preflight.IsValid ? "valid" : "invalid"),
            new(Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, true, imported.Value.Topology.Faces.Count(), Bounds(imported.Value)));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, solid.Name, 0, "air-rounded-box", fillet is null ? "rounded-box-primitive" : "rounded-box-top-boundary-fillet", RoundedBox: report));
    }

    private static KernelResult<FirmamentStepExportResult> RoundedBoxFailure(string message) =>
        KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, message, "FirmamentV2.RoundedBox")]);

    // Exact volume of the admitted family.  Each straight finish removes a
    // square-minus-quarter-circle section; each corner is that section swept
    // through a quadrant about the corner-cylinder axis.
    private static double RoundedBoxAnalyticVolume(double width, double depth, double height, double cornerRadius, double? topFilletRadius)
    {
        var primitive = (width * depth - ((4d - double.Pi) * cornerRadius * cornerRadius)) * height;
        if (topFilletRadius is not double r) return primitive;
        var section = r * r * (1d - double.Pi / 4d);
        var straightRemoval = section * (2d * ((width - 2d * cornerRadius) + (depth - 2d * cornerRadius)));
        var cornerFirstMoment = r * r * r * (5d / 6d - double.Pi / 4d);
        var cornerRemoval = 2d * double.Pi * ((cornerRadius * section) - cornerFirstMoment);
        return primitive - straightRemoval - cornerRemoval;
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2LocalizedTrihedralFillet(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        IReadOnlyList<FirmamentV2EdgeFinishDecl> finishes,
        FirmamentV2BoxRecord box)
    {
        // The compiler owns canonical classification; source order carries no topology meaning.
        var xz = finishes.SingleOrDefault(f => string.Equals(f.FaceAxis, "+X", StringComparison.Ordinal) && string.Equals(f.Target, "SharedEdgePlusZ", StringComparison.Ordinal));
        var yz = finishes.SingleOrDefault(f => string.Equals(f.FaceAxis, "+Y", StringComparison.Ordinal) && string.Equals(f.Target, "SharedEdgePlusZ", StringComparison.Ordinal));
        var xy = finishes.SingleOrDefault(f => string.Equals(f.FaceAxis, "+X", StringComparison.Ordinal) && string.Equals(f.Target, "SharedEdgePlusY", StringComparison.Ordinal));
        if (xz is null || yz is null || xy is null)
            return AirChamferFailure("localized-trihedral-fillet-edges-do-not-share-canonical-vertex");
        var compiled = AirLocalizedTrihedralFilletCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{xz.Name}.{yz.Name}.{xy.Name}", $"{xz.Name}+{yz.Name}+{xy.Name}", box.Size[0], box.Size[1], box.Size[2],
            xz.FaceAxis, xz.Target, yz.FaceAxis, yz.Target, xy.FaceAxis, xy.Target, xz.Distance, yz.Distance, xy.Distance,
            new AirSourceSpan(xz.SourceSpan.Start, xz.SourceSpan.Length + yz.SourceSpan.Length + xy.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.LocalizedEdgeJunctionRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? "localized-trihedral-fillet-spherical-octant-required", compiled.Diagnostics);

        var body = compiled.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return AirChamferFailure("localized-trihedral-fillet-preflight-verification-failed", preflight.Diagnostics.Select(d => d.Code));
        if (!FirmamentManifoldChecker.IsManifold(body)) return AirChamferFailure("localized-trihedral-fillet-emitted-body-is-not-manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = compiled.Construction.ConstructionId,
            ApplicationName = AirLocalizedTrihedralFilletCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return AirChamferFailure("localized-trihedral-fillet-step-reimport-verification-failed", reimport.Diagnostics.Select(d => d.Message));

        var topology = compiled.Construction.TopologyPlan;
        var cylinders = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Cylinder);
        var spheres = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Sphere);
        var planes = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Plane);
        var report = new FirmamentAirChamferReport(
            new("Fillet", solid.Name, $"{solid.Name}.{xz.Name}.{yz.Name}.{xy.Name}", $"{xz.Name}+{yz.Name}+{xy.Name}", "SharedEdge(+X,+Z),SharedEdge(+Y,+Z),SharedEdge(+X,+Y)", xz.Distance, "mm",
                $"{xz.SourceSpan.Start}:{xz.SourceSpan.Length}|{yz.SourceSpan.Start}:{yz.SourceSpan.Length}|{xy.SourceSpan.Start}:{xy.SourceSpan.Length}", "Admitted", "localized-trihedral-fillet-spherical-octant-candidate",
                new Dictionary<string, string> { ["Selection"] = "semantic Face(+X),Face(+Z); Face(+Y),Face(+Z); Face(+X),Face(+Y)", ["MaterialSide"] = compiled.Construction.MaterialSide, ["SphereCenter"] = $"({compiled.Construction.SphericalCornerPatch.Center.X:R},{compiled.Construction.SphericalCornerPatch.Center.Y:R},{compiled.Construction.SphericalCornerPatch.Center.Z:R})", ["Continuity"] = "G0=Exact;G1=normal-deviation:0" }),
            new("LocalizedTrihedralFillet", 0, [], "ordered-explicit-loops", "SphereCylinderSharedSeams",
                "replacementFaces=3;junctionFaces=1;sharedEdges=3;patch=SphericalOctant;G0=Exact;G1=WithinTolerance", true),
            new(true, topology.ExpectedVertexCount, topology.ExpectedEdgeCount, topology.ExpectedFaceCount, topology.ExpectedLoopCount, topology.ExpectedCoedgeCount, 0,
                "SphereCylinderSharedSeams", topology.DeterministicSignature, "LocalizedEdgeJunction"),
            new(AirLocalizedTrihedralFilletCompileResult.ProductionRoute, false, true, body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), Bounds(body), xz.Distance, xz.Distance, cylinders, 0, planes, spheres),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), Bounds(reimport.Value), true),
            LocalizedEdgeJunction: new(["SharedEdge(+X,+Z)", "SharedEdge(+Y,+Z)", "SharedEdge(+X,+Y)"], "Fillet", "EqualConstantRadius", xz.Distance, "Direct", "LocalizedTrihedralFillet", "SphericalOctant", 3, 1,
                new(true, topology.DeterministicSignature), "valid", false, 1, 1,
                new("SphericalOctant", "Sphere", "Cylinder", "Circle", true, 3, "+X,+Y,+Z octant")));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, $"{solid.Name}.{xz.Name}.{yz.Name}.{xy.Name}", 0, "air-fillet", "localized-trihedral-fillet", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2LocalizedTangentBlendSingleEdgeFillet(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        FirmamentV2EdgeFinishDecl finish,
        FirmamentV2BoxRecord box)
    {
        var compiled = AirLocalizedTangentBlendFilletCompiler.Compile(new(
            solid.Name, $"{solid.Name}.{finish.Name}", finish.Name, box.Size[0], box.Size[1], box.Size[2],
            finish.FaceAxis, finish.Target switch { "SharedEdgePlusZ" => "+Z", "SharedEdgePlusY" => "+Y", _ => finish.Target }, finish.Kind, finish.Distance,
            new AirSourceSpan(finish.SourceSpan.Start, finish.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.LocalizedEdgeReplacementRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? compiled.Feature.AdmissionReason, compiled.Diagnostics);

        var body = compiled.Body;
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return AirChamferFailure("localized-fillet-preflight-verification-failed", preflight.Diagnostics.Select(d => d.Code));
        if (!FirmamentManifoldChecker.IsManifold(body)) return AirChamferFailure("localized-fillet-emitted-body-is-not-manifold");
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions
        {
            ProductName = compiled.Feature.FeatureName,
            ApplicationName = AirLocalizedTangentBlendFilletCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return AirChamferFailure("localized-fillet-step-reimport-verification-failed");

        var plan = compiled.Construction.TopologyPlan;
        var witness = compiled.Construction.Witness;
        var cylinders = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Cylinder);
        var planes = body.Geometry.Surfaces.Count(s => s.Value.Kind == SurfaceGeometryKind.Plane);
        var report = new FirmamentAirChamferReport(
            new("Fillet", compiled.Feature.BodyId, compiled.Feature.FeatureId, compiled.Feature.FeatureName, "SharedEdge(+X,+Z)", finish.Distance, "mm",
                $"{compiled.Feature.SourceSpan.Start}:{compiled.Feature.SourceSpan.Length}", compiled.Feature.Admission.ToString(), compiled.Feature.AdmissionReason,
                new Dictionary<string, string> { ["Selection"] = "semantic Face(+X),Face(+Z)", ["MaterialSide"] = witness.MaterialSide, ["History"] = witness.Provenance }),
            new("LocalizedTangentBlend", 0, [], "ordered-explicit-loops", "ExplicitOwnedEndpoints",
                $"profile=QuarterCircle;sweep=Linear;radius={witness.Radius:R};axis=+Y;retainedFaces=2;replacementFaces=1", true),
            new(true, plan.ExpectedVertexCount, plan.ExpectedEdgeCount, plan.ExpectedFaceCount, plan.ExpectedLoopCount, plan.ExpectedCoedgeCount, 0,
                "ExplicitOwnedEndpoints", plan.DeterministicSignature, "LocalizedTangentBlend"),
            new(AirLocalizedTangentBlendFilletCompileResult.ProductionRoute, false, true, body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), Bounds(body), finish.Distance, finish.Distance, cylinders, 0, planes),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true, reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), Bounds(reimport.Value), true),
            LocalizedFillet: new("SharedEdge(+X,+Z)", "ConstantRadius", finish.Distance, "LocalizedTangentBlend", "QuarterCircle", "Linear", "Direct", 2, 1, "ExplicitOwnedEndpoints", new(true, plan.DeterministicSignature), "valid", false),
            LocalizedEdgeFinish: new("Fillet", "SharedEdge(+X,+Z)", "ConstantRadius", finish.Distance, "LocalizedEdgeReplacement", "CylindricalFillet", "Direct", 2, 1, "ExplicitOwnedEndpoints", new(true, plan.DeterministicSignature), "valid", false));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, compiled.Feature.FeatureId, 0, "air-fillet", "localized-tangent-blend-single-edge-fillet", Air: report, ConceptIr: document.ConceptIr));
    }

    private static KernelResult<FirmamentStepExportResult> ExportV2CircularRimChamfer(
        FirmamentV2Document document,
        FirmamentV2SolidBinding solid,
        FirmamentV2EdgeFinishDecl finish,
        FirmamentV2CylinderRecord cylinder)
    {
        var compiled = AirCylinderTopRimChamferCompiler.Compile(new(
            solid.Name,
            $"{solid.Name}.{finish.Name}",
            finish.Name,
            cylinder.Radius,
            cylinder.Height,
            finish.FaceAxis,
            finish.Target,
            finish.Kind,
            finish.Distance,
            new AirSourceSpan(finish.SourceSpan.Start, finish.SourceSpan.Length, document.ModelName)));
        if (!compiled.Succeeded || compiled.Body is null || compiled.Construction is null || compiled.BRepPlan?.RevolvedRealizationPlan is null)
            return AirChamferFailure(compiled.Error?.Code ?? compiled.Feature.AdmissionReason, compiled.Diagnostics);

        var manifold = FirmamentManifoldChecker.IsManifold(compiled.Body);
        if (!manifold) return AirChamferFailure("chamfer-backend-circular-rim-body-is-not-manifold", compiled.Diagnostics);
        var step = Step242Exporter.ExportBody(compiled.Body, new Step242ExportOptions
        {
            ProductName = compiled.Feature.FeatureName,
            ApplicationName = AirCylinderTopRimChamferCompileResult.ProductionRoute,
            BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
            BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
        });
        if (!step.IsSuccess || step.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null) return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
        var reimportedManifold = FirmamentManifoldChecker.IsManifold(reimport.Value);
        if (!reimportedManifold) return AirChamferFailure("chamfer-verification-circular-rim-step-reimport-is-not-manifold");

        var topology = compiled.Construction.TopologyPlan;
        var surfaces = compiled.Body.Geometry.Surfaces.Select(s => s.Value.Kind).ToArray();
        var sharp = compiled.Construction.Witness.SharpProfile.Select(p => (IReadOnlyList<double>)new[] { p.X, p.Y }).ToArray();
        var replacement = compiled.Construction.Witness.ReplacementProfile.Select(p => (IReadOnlyList<double>)new[] { p.X, p.Y }).ToArray();
        var featureProvenance = new Dictionary<string, string>(StringComparer.Ordinal);
        if (solid.Provenance?.TryGetValue("Bounds", out var boundsProvenance) == true) featureProvenance["Bounds"] = boundsProvenance;
        if (finish.Provenance?.TryGetValue("Face", out var faceProvenance) == true) featureProvenance["Selection"] = faceProvenance;
        if (finish.Provenance?.TryGetValue("Distance", out var distanceProvenance) == true) featureProvenance["Distance"] = distanceProvenance;
        var report = new FirmamentAirChamferReport(
            new("Chamfer", compiled.Feature.BodyId, compiled.Feature.FeatureId, compiled.Feature.FeatureName, "FaceBoundary(+Z,circular,outer,complete)", compiled.Feature.Rule.Distance, compiled.Feature.Rule.Unit,
                $"{compiled.Feature.SourceSpan.Start}:{compiled.Feature.SourceSpan.Length}", compiled.Feature.Admission.ToString(), compiled.Feature.AdmissionReason, featureProvenance),
            new("RevolutionProfileRewrite", 0, [], "ordered-radial-profile", "preserve-profile-corners",
                $"axis={compiled.Construction.Witness.Axis};materialSide={compiled.Construction.Witness.MaterialSide}", compiled.Construction.Witness.CompilerGenerated, sharp, replacement),
            new(true, topology.ExpectedVertexCount, topology.ExpectedEdgeCount, topology.ExpectedFaceCount, topology.ExpectedLoopCount, topology.ExpectedCoedgeCount, 1,
                "preserve-profile-corners", topology.DeterministicSignature, "RevolvedProfile"),
            new(AirCylinderTopRimChamferCompileResult.ProductionRoute, false, manifold,
                compiled.Body.Topology.Vertices.Count(), compiled.Body.Topology.Edges.Count(), compiled.Body.Topology.Faces.Count(), CircularBounds(cylinder.Radius, cylinder.Height), finish.Distance, finish.Distance,
                surfaces.Count(k => k == SurfaceGeometryKind.Cylinder), surfaces.Count(k => k == SurfaceGeometryKind.Cone), surfaces.Count(k => k == SurfaceGeometryKind.Plane)),
            new("AP242", Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value))), true,
                reimport.Value.Topology.Vertices.Count(), reimport.Value.Topology.Edges.Count(), reimport.Value.Topology.Faces.Count(), CircularBounds(cylinder.Radius, cylinder.Height), reimportedManifold));
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(
            step.Value, compiled.Feature.FeatureId, 0, "air-chamfer", "circular-top-rim-chamfer", Air: report, ConceptIr: document.ConceptIr));
    }

    private static string CircularBounds(double radius, double height) =>
        FormattableString.Invariant($"[{-radius:0.###},{-radius:0.###},{-height / 2d:0.###}]..[{radius:0.###},{radius:0.###},{height / 2d:0.###}]");

    private static string Bounds(BrepBody body)
    {
        var points = body.Topology.Vertices.Select(v => body.TryGetVertexPoint(v.Id, out var point) ? point : throw new InvalidOperationException($"Missing point for vertex {v.Id}.")).ToArray();
        return FormattableString.Invariant($"[{points.Min(p => p.X):0.###},{points.Min(p => p.Y):0.###},{points.Min(p => p.Z):0.###}]..[{points.Max(p => p.X):0.###},{points.Max(p => p.Y):0.###},{points.Max(p => p.Z):0.###}]");
    }

    private static KernelResult<FirmamentStepExportResult> AirChamferFailure(string primary, IEnumerable<string>? details = null) =>
        KernelResult<FirmamentStepExportResult>.Failure((new[] { primary }).Concat(details ?? []).Distinct().Select(message => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            message,
            "FirmamentV2.AirChamfer")).ToArray());

    private static KernelResult<FirmamentStepExportResult>? TryExportV2InlineStepReplacementBody(FirmamentV2Document document)
    {
        if (document.Replacements is not { Count: 1 } replacements || document.Solids.Count != 1)
        {
            return null;
        }

        var replacement = replacements[0];
        var solid = document.Solids.SingleOrDefault(s => string.Equals(s.Name, replacement.ImportedBodyName, StringComparison.Ordinal));
        if (solid?.InlineStep is null || replacement.ReplacementKind != "holeShaft" || replacement.EndCondition != "throughAll")
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, FirmamentV2Parser.ReplacementVerificationFailed, "FirmamentV2.InlineStepReplacement")]);
        }

        var stepText = File.ReadAllText(solid.InlineStep.NormalizedPath, Encoding.UTF8);
        var import = Step242Importer.ImportBody(stepText);
        if (!import.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(import.Diagnostics);

        var cylFaceCount = import.Value.Geometry.Surfaces.Count(entry => entry.Value.Kind == SurfaceGeometryKind.Cylinder && Math.Abs((entry.Value.Cylinder?.Radius ?? 0d) - replacement.Radius) <= 1e-6);
        if (cylFaceCount != 1)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, FirmamentV2Parser.ReplacementVerificationFailed, "FirmamentV2.InlineStepReplacement")]);
        }

        var size = replacement.HostSize;
        var syntheticDocument = new FirmamentV2Document(
            document.ModelName,
            document.Units,
            [new FirmamentV2SolidBinding("replacementHost", "Box", new FirmamentV2BoxRecord(size, []))],
            [new FirmamentV2ModifyBlock("replacementHost", [], [new FirmamentV2SemanticHoleDecl(replacement.ReplacementFeatureName, FirmamentV2SemanticHoleVariant.Shaft, FirmamentV2FaceTarget.Direct("+Z"), replacement.Center with { Convention = FirmamentV2FaceLocalPoint2D.PlusZConvention }, replacement.Radius * 2d, new FirmamentV2SemanticHoleEnd(FirmamentV2SemanticHoleEndKind.ThroughAll))])],
            [],
            document.Pmi,
            document.RecognizedRegions,
            document.Replacements);

        var semanticHoles = FirmamentV2SemanticHoleLowering.LowerSemanticHoles(syntheticDocument);
        var feature = semanticHoles[0];
        var host = FirmamentStockFrame.ForBox(size[0], size[1], size[2]).CreateHoleHost();
        var materialized = AirHoleSimpleShaftMaterializer.Execute(feature, host);
        if (!materialized.Succeeded || materialized.Body is null) return SemanticHoleFailure(materialized.Diagnostics);

        var expectedVolume = size[0] * size[1] * size[2] - Math.PI * replacement.Radius * replacement.Radius * size[2];
        var rebuiltVolume = EstimateBoundingBoxVolume(materialized.Body) - Math.PI * replacement.Radius * replacement.Radius * size[2];
        if (Math.Abs(expectedVolume - rebuiltVolume) > 1e-6)
        {
            return KernelResult<FirmamentStepExportResult>.Failure([new Kernel.Core.Diagnostics.KernelDiagnostic(Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed, Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error, FirmamentV2Parser.ReplacementVerificationFailed, "FirmamentV2.InlineStepReplacement")]);
        }

        var step = Step242Exporter.ExportBody(materialized.Body, new Step242ExportOptions { ProductName = replacement.ReplacementFeatureName, ApplicationName = "Aetheris.Firmament.InlineStepReplacement" });
        if (!step.IsSuccess) return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);

        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, replacement.ReplacementFeatureName, 0, "inline-step-replacement", "holeShaft-bounded-rebuild", DatumInspection: [], DimensionInspection: [], InlineStepMigration: InlineStepMigrationReportBuilder.Build(document, solid, replacementsVerified: true, replacementsEmitted: true, emissionStrategy: "holeShaft-bounded-rebuild", residualSurgery: false),
                InlineStepReplacementAssist: InlineStepReplacementAssistReportBuilder.Build(document)));
    }

    private static double EstimateBoundingBoxVolume(BrepBody body)
    {
        var points = body.Topology.Vertices.Select(v => body.TryGetVertexPoint(v.Id, out var p) ? p : new Point3D(0, 0, 0)).ToArray();
        return (points.Max(p => p.X) - points.Min(p => p.X)) * (points.Max(p => p.Y) - points.Min(p => p.Y)) * (points.Max(p => p.Z) - points.Min(p => p.Z));
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2InlineStepBody(FirmamentV2Document document)
    {
        if (document.Solids.Count != 1)
        {
            return null;
        }

        var solid = document.Solids[0];
        if (solid.Primitive is not FirmamentV2InlineStepRecord inlineStep)
        {
            return null;
        }

        var stepText = File.ReadAllText(inlineStep.NormalizedPath, Encoding.UTF8);
        var import = Step242Importer.ImportBody(stepText);
        if (!import.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(import.Diagnostics);
        }

        var semanticPmiValidation = ValidateV2PmiExportSupport(document);
        if (!semanticPmiValidation.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(semanticPmiValidation.Diagnostics);
        }

        var semanticPmi = BuildV2SemanticPmi(document, [], solid.Name);
        var export = Step242Exporter.ExportBody(import.Value, semanticPmi, new Step242ExportOptions
        {
            ProductName = solid.Name,
            ApplicationName = "Aetheris.Firmament.InlineStep"
        });
        if (!export.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(export.Diagnostics);
        }

        return KernelResult<FirmamentStepExportResult>.Success(
            new FirmamentStepExportResult(
                export.Value,
                solid.Name,
                0,
                "inline-step",
                "aetheris-canonical-ap242",
                DatumInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
                DimensionInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.HoleDiameter).Select(p => new FirmamentPmiInspectionDimension("Diameter", p.Target, null, p.Value ?? 0d, "explicit-v2-record-pmi", p.Name)).ToArray() ?? [],
                InlineStepMigration: InlineStepMigrationReportBuilder.Build(document, solid, emissionStrategy: "canonical-reexport", residualSurgery: false),
                InlineStepReplacementAssist: InlineStepReplacementAssistReportBuilder.Build(document)));
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2ControlledSideHoleBody(FirmamentV2Document document)
    {
        if ((document.ModifyBlocks ?? []).Any(m => (m.EdgeFinishes?.Count ?? 0) > 0)) return null;
        var intent = document.SideHoleIntent;
        if (intent is null)
        {
            return null;
        }

        if (document.ModifyBlocks is not { Count: 1 }
            || document.ModifyBlocks[0].Regions.Count != 1
            || document.ModifyBlocks[0].SemanticHoles.Count != 0)
        {
            return null;
        }

        if (!string.Equals(intent.Tool, "Cylinder", StringComparison.Ordinal)
            || !string.Equals(intent.AttachFace, "+X", StringComparison.Ordinal)
            || !string.Equals(intent.ThroughFace, "-X", StringComparison.Ordinal))
        {
            return null;
        }

        var targetSolid = document.Solids.SingleOrDefault(s => string.Equals(s.Name, intent.TargetSolid, StringComparison.Ordinal));
        if (targetSolid?.Primitive is not FirmamentV2BoxRecord box || box.Size.Count != 3)
        {
            return null;
        }

        var sizeX = box.Size[0];
        var sizeY = box.Size[1];
        var sizeZ = box.Size[2];
        var zAxis = Direction3D.Create(new Vector3D(0, 0, 1));
        var xAxis = Direction3D.Create(new Vector3D(1, 0, 0));
        var extents = new AxisAlignedBoxExtents(-sizeY / 2d, sizeY / 2d, -sizeZ / 2d, sizeZ / 2d, -sizeX / 2d, sizeX / 2d);
        var cylinder = new RecognizedCylinder(new Point3D(intent.CenterU, intent.CenterV, 0), zAxis, intent.Radius, -sizeX / 2d, sizeX / 2d);
        var hole = new SupportedBooleanHole(
            intent.RegionName,
            new AnalyticSurface(AnalyticSurfaceKind.Cylinder, Cylinder: cylinder),
            intent.CenterU,
            intent.CenterV,
            new Point3D(intent.CenterU, intent.CenterV, -sizeX / 2d),
            new Point3D(intent.CenterU, intent.CenterV, sizeX / 2d),
            zAxis,
            xAxis,
            intent.Radius,
            intent.Radius,
            SupportedBooleanHoleSpanKind.Through,
            -sizeX / 2d,
            sizeX / 2d);
        var composition = new SafeBooleanComposition(extents, [hole], SafeBooleanRootDescriptor.FromBox(extents));
        var built = BrepBooleanBoxCylinderHoleBuilder.BuildComposition(composition, ToleranceContext.Default);
        if (!built.IsSuccess || built.Value is null)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(built.Diagnostics);
        }

        var body = ReorientCanonicalSideHoleBodyFromZToX(built.Value);
        var step = Step242Exporter.ExportBody(body, new Step242ExportOptions { ProductName = "firmament-v2-controlled-side-hole" });
        if (!step.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        }

        return KernelResult<FirmamentStepExportResult>.Success(
            new FirmamentStepExportResult(
                step.Value,
                intent.RegionName,
                0,
                "boolean",
                "side-hole-controlled-x",
                DatumInspection: [],
                DimensionInspection: []));
    }

    private static BrepBody ReorientCanonicalSideHoleBodyFromZToX(BrepBody body)
    {
        static Point3D P(Point3D p) => new(p.Z, p.X, p.Y);
        static Direction3D D(Direction3D d)
        {
            var v = d.ToVector();
            return Direction3D.Create(new Vector3D(v.Z, v.X, v.Y));
        }

        var geometry = new BrepGeometryStore();
        foreach (var entry in body.Geometry.Curves)
        {
            geometry.AddCurve(entry.Key, entry.Value.Kind switch
            {
                CurveGeometryKind.Line3 => CurveGeometry.FromLine(new Line3Curve(P(entry.Value.Line3!.Value.Origin), D(entry.Value.Line3.Value.Direction))),
                CurveGeometryKind.Circle3 => CurveGeometry.FromCircle(new Circle3Curve(P(entry.Value.Circle3!.Value.Center), D(entry.Value.Circle3.Value.Normal), entry.Value.Circle3.Value.Radius, D(entry.Value.Circle3.Value.XAxis))),
                CurveGeometryKind.Ellipse3 => CurveGeometry.FromEllipse(new Ellipse3Curve(P(entry.Value.Ellipse3!.Value.Center), D(entry.Value.Ellipse3.Value.Normal), entry.Value.Ellipse3.Value.MajorRadius, entry.Value.Ellipse3.Value.MinorRadius, D(entry.Value.Ellipse3.Value.XAxis))),
                _ => entry.Value
            });
        }

        foreach (var entry in body.Geometry.Surfaces)
        {
            geometry.AddSurface(entry.Key, entry.Value.Kind switch
            {
                SurfaceGeometryKind.Plane => SurfaceGeometry.FromPlane(new PlaneSurface(P(entry.Value.Plane!.Value.Origin), D(entry.Value.Plane.Value.Normal), D(entry.Value.Plane.Value.UAxis))),
                SurfaceGeometryKind.Cylinder => SurfaceGeometry.FromCylinder(new CylinderSurface(P(entry.Value.Cylinder!.Value.Origin), D(entry.Value.Cylinder.Value.Axis), entry.Value.Cylinder.Value.Radius, D(entry.Value.Cylinder.Value.XAxis))),
                _ => entry.Value
            });
        }

        var vertexPoints = new Dictionary<VertexId, Point3D>();
        foreach (var vertex in body.Topology.Vertices)
        {
            if (body.TryGetVertexPoint(vertex.Id, out var point))
            {
                vertexPoints[vertex.Id] = P(point);
            }
        }

        return new BrepBody(body.Topology, geometry, body.Bindings, vertexPoints, safeBooleanComposition: null, body.ShellRepresentation);
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2PerforationBody(FirmamentV2Document document)
    {
        var features = (document.ModifyBlocks ?? []).SelectMany(block => (block.Perforations ?? []).Select(feature => (block.TargetSolid, Feature: feature))).ToArray();
        if (features.Length == 0) return null;
        KernelResult<FirmamentStepExportResult> Failure(string diagnostic) =>
            KernelResult<FirmamentStepExportResult>.Failure([new KernelDiagnostic(KernelDiagnosticCode.ValidationFailed, KernelDiagnosticSeverity.Error, diagnostic, "FirmamentV2.Perforation")]);
        if (features.Length != 1 || document.Solids.Count != 1 || document.ModifyBlocks!.Any(block => block.SemanticHoles.Count > 0 || (block.EdgeFinishes?.Count ?? 0) > 0))
            return Failure("perforation-composition-unsupported: X0 admits one Perforation on one Box without other Modify features");
        var (target, feature) = features[0];
        if (document.Solid.Name == target && document.Solid.ConstructionPolicy == FirmamentV2ConstructionPolicy.Hollow &&
            document.Solid.Cylinder is { } cylinder && document.Solid.Hollow is { } hollow)
        {
            var cylindrical = FirmamentCylindricalPerforationPlanner.Plan(cylinder.Radius, cylinder.Height,
                hollow.WallThickness, feature);
            if (!cylindrical.Succeeded) return Failure(cylindrical.Diagnostic!);
            var patternBuildStart = Stopwatch.GetTimestamp();
            var hollowBody = ThinWalledBodyBRepPlanner.CreateCylinder(cylinder.Radius, cylinder.Height, hollow.WallThickness, hollow.BottomBlendRadius);
            if (!hollowBody.IsSuccess || hollowBody.Value is null)
                return Failure("perforation-cylindrical-host-invalid: " + string.Join(" | ", hollowBody.Diagnostics.Select(d => d.Message)));
            var cylindricalFeatureId = $"{target}.{feature.Name}";
            var placements = cylindrical.Instances.Select(instance => new HollowRadialCutPlacement(
                instance.StableId(cylindricalFeatureId), feature.Diameter / 2, instance.Z, instance.AngleRadians)).ToArray();
            var cut = BrepHollowRadialCutPattern.Build(hollowBody.Value, placements);
            if (!cut.IsSuccess || cut.Value is null)
                return Failure("perforation-cylindrical-brep-failed: " + string.Join(" | ", cut.Diagnostics.Select(d => $"{d.Source}: {d.Message}")));
            var patternBuildMilliseconds = Stopwatch.GetElapsedTime(patternBuildStart).TotalMilliseconds;
            var cylindricalBody = cut.Value.Body;
            if (!FirmamentManifoldChecker.IsManifold(cylindricalBody))
                return Failure("perforation-cylindrical-topology-invalid: the composed shell is not manifold");
            var stepExportStart = Stopwatch.GetTimestamp();
            var cylindricalStep = Step242Exporter.ExportBody(cylindricalBody, new Step242ExportOptions
            {
                ProductName = cylindricalFeatureId,
                ApplicationName = "Aetheris.Firmament.Perforation.Cylindrical",
                BrepExportPreflightMode = BrepExportPreflightMode.Enforce,
                BrepExportPreflightPolicy = BrepExportPreflightPolicy.TrustedProductionRoute,
            });
            if (!cylindricalStep.IsSuccess || cylindricalStep.Value is null)
                return Failure("perforation-cylindrical-step-export-failed: " + string.Join(" | ", cylindricalStep.Diagnostics.Select(d => d.Message)));
            var stepExportMilliseconds = Stopwatch.GetElapsedTime(stepExportStart).TotalMilliseconds;
            var stepReimportStart = Stopwatch.GetTimestamp();
            var cylindricalImport = Step242Importer.ImportBody(cylindricalStep.Value);
            if (!cylindricalImport.IsSuccess || cylindricalImport.Value is null || !FirmamentManifoldChecker.IsManifold(cylindricalImport.Value))
                return Failure("perforation-cylindrical-step-reimport-invalid: " + string.Join(" | ", cylindricalImport.Diagnostics.Select(d => d.Message)));
            var stepReimportMilliseconds = Stopwatch.GetElapsedTime(stepReimportStart).TotalMilliseconds;
            var importedCylinders = cylindricalImport.Value.Geometry.Surfaces
                .Where(pair => pair.Value.Kind == SurfaceGeometryKind.Cylinder)
                .Select(pair => pair.Value.Cylinder!.Value.Radius).ToArray();
            var importedPlanes = cylindricalImport.Value.Geometry.Surfaces
                .Where(pair => pair.Value.Kind == SurfaceGeometryKind.Plane)
                .Select(pair => pair.Value.Plane!.Value.Origin.Z).ToArray();
            var importedTori = cylindricalImport.Value.Geometry.Surfaces
                .Where(pair => pair.Value.Kind == SurfaceGeometryKind.Torus)
                .Select(pair => pair.Value.Torus!.Value).ToArray();
            if (cylindricalImport.Value.Topology.Faces.Count() != placements.Length + (hollow.BottomBlendRadius > 0 ? 7 : 5) ||
                importedCylinders.Length != placements.Length + 2 ||
                importedPlanes.Length != 3 ||
                importedTori.Length != (hollow.BottomBlendRadius > 0 ? 2 : 0) ||
                (hollow.BottomBlendRadius > 0 &&
                 (importedTori.Any(torus => System.Math.Abs(torus.MajorRadius - (cylinder.Radius - hollow.BottomBlendRadius)) > 1e-6) ||
                  !importedTori.Any(torus => System.Math.Abs(torus.MinorRadius - hollow.BottomBlendRadius) < 1e-6) ||
                  !importedTori.Any(torus => System.Math.Abs(torus.MinorRadius - (hollow.BottomBlendRadius - hollow.WallThickness)) < 1e-6))) ||
                !new[] { 0d, hollow.WallThickness, cylinder.Height }.All(z => importedPlanes.Any(p => System.Math.Abs(p - z) < 1e-6)) ||
                importedCylinders.Count(r => System.Math.Abs(r - feature.Diameter / 2) < 1e-6) != placements.Length ||
                importedCylinders.Count(r => System.Math.Abs(r - cylinder.Radius) < 1e-6) != 1 ||
                importedCylinders.Count(r => System.Math.Abs(r - (cylinder.Radius - hollow.WallThickness)) < 1e-6) != 1)
                return Failure("perforation-cylindrical-step-reimport-invalid: opening count or analytic radii changed");
            var cylindricalDescendants = placements.SelectMany(placement => new[]
            {
                new SemanticTopologyDescendant($"material:perforation:{placement.StableId}:wall", "Face", SemanticTopologyRole.HoleWallFace,
                    $"perforation:{placement.StableId}", Face: cut.Value.TopologyMap.Faces[$"{placement.StableId}.Wall"],
                    ParentStableId: cylindricalFeatureId, Addressability: SemanticTopologyAddressability.DerivedStable),
                new SemanticTopologyDescendant($"material:perforation:{placement.StableId}:outer-opening", "Loop", SemanticTopologyRole.HoleEntryLoop,
                    $"perforation:{placement.StableId}", Loop: cut.Value.TopologyMap.Loops[$"{placement.StableId}.OuterOpening"],
                    ParentStableId: cylindricalFeatureId, Addressability: SemanticTopologyAddressability.DerivedStable),
                new SemanticTopologyDescendant($"material:perforation:{placement.StableId}:inner-opening", "Loop", SemanticTopologyRole.HoleExitLoop,
                    $"perforation:{placement.StableId}", Loop: cut.Value.TopologyMap.Loops[$"{placement.StableId}.InnerOpening"],
                    ParentStableId: cylindricalFeatureId, Addressability: SemanticTopologyAddressability.DerivedStable),
            }).ToArray();
            var cylindricalCorrespondence = new SemanticTopologyCorrespondence(cylindricalFeatureId, cylindricalDescendants,
                ["Perforation", "BrepHollowRadialCutPattern"])
            {
                SourceSpans = new Dictionary<string, FirmamentV2SourceSpan> { [cylindricalFeatureId] = feature.SourceSpan }
            };
            var cylindricalHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(cylindricalStep.Value)));
            var realizedPitch = 2 * System.Math.PI * (cylinder.Radius - hollow.WallThickness / 2) / cylindrical.Columns;
            var cylindricalReport = new FirmamentPerforationReport(cylindricalFeatureId, feature.SupportFace, feature.Layout,
                feature.Diameter, feature.Pitch, feature.Margin, feature.MinimumLigament, placements.Length,
                placements.Select(p => p.StableId).ToArray(), cylindricalBody.Topology.Vertices.Count(),
                cylindricalBody.Topology.Edges.Count(), cylindricalBody.Topology.Faces.Count(), true, true, cylindricalHash)
            {
                Rows = cylindrical.Rows, Columns = cylindrical.Columns,
                AngularPitchRadians = cylindrical.AngularPitchRadians,
                RealizedCircumferentialPitch = realizedPitch,
                MarginTop = feature.MarginTop ?? feature.Margin, MarginBottom = feature.MarginBottom ?? feature.Margin,
                MaximumCurveBoundMm = cut.Value.Certificates.Values.Max(c => System.Math.Max(c.OuterCurveBoundMm, c.InnerCurveBoundMm)),
                MaximumPcurveBoundMm = cut.Value.Certificates.Values.Max(c => new[] { c.OuterHostPcurveBoundMm, c.OuterToolPcurveBoundMm,
                    c.InnerHostPcurveBoundMm, c.InnerToolPcurveBoundMm }.Max()),
                PatternBuildMilliseconds = patternBuildMilliseconds,
                StepExportMilliseconds = stepExportMilliseconds,
                StepReimportMilliseconds = stepReimportMilliseconds
            };
            return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(cylindricalStep.Value,
                cylindricalFeatureId, 0, "perforation-cylindrical", "local-radial-through-wall", Perforation: cylindricalReport)
            { RuntimeBody = cylindricalBody, RuntimeCorrespondence = cylindricalCorrespondence });
        }
        if (document.Solid.Name != target || document.Solid.Box is not { Size.Count: 3 } box)
            return Failure("perforation-cylindrical-topology-unavailable: the piping authority constructs constant-thickness annular stock, but the current BRep Boolean route does not materialize radial cylinder-to-cylinder intersections on its wall");
        var plan = FirmamentPerforationPlanner.Plan(box.Size[0], box.Size[1], feature);
        if (!plan.Succeeded) return Failure(plan.Diagnostic!);
        var featureId = $"{target}.{feature.Name}";
        var axis = Direction3D.Create(new Vector3D(0, 0, 1));
        var reference = Direction3D.Create(new Vector3D(1, 0, 0));
        var extents = new AxisAlignedBoxExtents(-box.Size[0] / 2, box.Size[0] / 2, -box.Size[1] / 2, box.Size[1] / 2, 0, box.Size[2]);
        var holes = plan.Instances.Select(instance =>
        {
            var center = new Point3D(instance.X, instance.Y, 0);
            var cylinder = new RecognizedCylinder(center, axis, feature.Diameter / 2, 0, box.Size[2]);
            return new SupportedBooleanHole(instance.StableId(featureId), new AnalyticSurface(AnalyticSurfaceKind.Cylinder, Cylinder: cylinder),
                instance.X, instance.Y, center, new Point3D(instance.X, instance.Y, box.Size[2]), axis, reference,
                feature.Diameter / 2, feature.Diameter / 2, SupportedBooleanHoleSpanKind.Through, 0, box.Size[2]);
        }).ToArray();
        var wallFaces = new Dictionary<string, FaceId>(StringComparer.Ordinal);
        var duplicate = false;
        // The regular layout planner proves non-interference and full edge clearance before this single topology build.
        var built = BrepBooleanBoxCylinderHoleBuilder.BuildComposition(new SafeBooleanComposition(extents, holes), ToleranceContext.Default,
            (id, face) => { if (!wallFaces.TryAdd(id, face)) duplicate = true; });
        if (!built.IsSuccess || built.Value is null)
            return Failure("perforation-brep-failed: " + string.Join(" | ", built.Diagnostics.Select(d => d.Message)));
        var body = built.Value;
        if (duplicate || wallFaces.Count != holes.Length || !FirmamentManifoldChecker.IsManifold(body))
            return Failure("perforation-topology-invalid: wall provenance or manifold check failed");
        var preflight = BrepExportPreflight.Validate(body);
        if (!preflight.IsValid) return Failure("perforation-export-preflight-failed: " + string.Join(" | ", preflight.Diagnostics.Take(4).Select(d => $"{d.Code}: {d.Context}")));
        var step = Step242Exporter.ExportBody(body);
        if (!step.IsSuccess || step.Value is null) return Failure("perforation-step-export-failed: " + string.Join(" | ", step.Diagnostics.Select(d => d.Message)));
        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null || !FirmamentManifoldChecker.IsManifold(reimport.Value))
            return Failure("perforation-step-reimport-invalid: production STEP did not reimport as a manifold");
        var descendants = holes.Select(hole => new SemanticTopologyDescendant(
            $"material:perforation:{hole.FeatureId}:wall", "Face", SemanticTopologyRole.HoleWallFace,
            $"perforation:{hole.FeatureId}", Face: wallFaces[hole.FeatureId!], ParentStableId: featureId,
            Addressability: SemanticTopologyAddressability.DerivedStable)).ToArray();
        var correspondence = new SemanticTopologyCorrespondence(featureId, descendants, ["Perforation", "BrepBooleanBoxCylinderHoleBuilder"])
        {
            SourceSpans = new Dictionary<string, FirmamentV2SourceSpan> { [featureId] = feature.SourceSpan }
        };
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value)));
        var report = new FirmamentPerforationReport(featureId, feature.SupportFace, feature.Layout, feature.Diameter, feature.Pitch,
            feature.Margin, feature.MinimumLigament, plan.Instances.Count, holes.Select(hole => hole.FeatureId!).ToArray(),
            body.Topology.Vertices.Count(), body.Topology.Edges.Count(), body.Topology.Faces.Count(), true, true, hash);
        return KernelResult<FirmamentStepExportResult>.Success(new FirmamentStepExportResult(step.Value, featureId, 0,
            "perforation", "circular-through", Perforation: report) { RuntimeBody = body, RuntimeCorrespondence = correspondence });
    }

    private static KernelResult<FirmamentStepExportResult>? TryExportV2SemanticHoleBody(FirmamentV2Document document)
    {
        if ((document.ModifyBlocks ?? []).Any(m => (m.EdgeFinishes?.Count ?? 0) > 0)) return null;
        if (document.ModifyBlocks is not { Count: > 0 })
        {
            return null;
        }

        var modifyTargets = document.ModifyBlocks.Select(m => m.TargetSolid).Distinct(StringComparer.Ordinal).ToArray();
        if (modifyTargets.Length != 1)
        {
            return null;
        }

        var targetSolid = document.Solids.SingleOrDefault(s => string.Equals(s.Name, modifyTargets[0], StringComparison.Ordinal));
        if (targetSolid?.Primitive is not FirmamentV2BoxRecord box || box.Size.Count != 3)
        {
            return null;
        }

        var semanticHoles = FirmamentV2SemanticHoleLowering.LowerSemanticHoles(document);
        if (semanticHoles.Count == 0)
        {
            return null;
        }

        var feature = semanticHoles[0];
        // The stock frame is authored by the Box, never inferred from ConceptIr presence.
        var host = FirmamentStockFrame.ForBox(box.Size[0], box.Size[1], box.Size[2]).CreateHoleHost();
        Aetheris.Kernel.Core.Brep.BrepBody? body;
        SemanticTopologyCorrespondence? runtimeCorrespondence = null;
        IReadOnlyList<string> diagnostics;
        if (semanticHoles.Count == 1)
        {
            var materialized = AirHoleSimpleShaftMaterializer.Execute(feature, host);
            body = materialized.Body;
            runtimeCorrespondence = materialized.Correspondence;
            diagnostics = materialized.Diagnostics;
            if (!materialized.Succeeded || body is null)
            {
                return SemanticHoleFailure(diagnostics);
            }
        }
        else
        {
            var materialized = AirHoleCompositeMaterializer.Execute(semanticHoles, host);
            body = materialized.Body;
            runtimeCorrespondence = materialized.Correspondence;
            diagnostics = materialized.Diagnostics;
            if (!materialized.Succeeded || body is null)
            {
                return SemanticHoleFailure(diagnostics);
            }
        }

        if (runtimeCorrespondence is not null)
        {
            var sourceSpans = new Dictionary<string, FirmamentV2SourceSpan>(StringComparer.Ordinal);
            if (targetSolid.SourceSpan is { } bodySpan) sourceSpans[modifyTargets[0]] = bodySpan;
            foreach (var modify in document.ModifyBlocks)
                foreach (var hole in modify.SemanticHoles)
                    if (hole.SourceSpan is { } holeSpan) sourceSpans[$"{modify.TargetSolid}.{hole.Name}"] = holeSpan;
            runtimeCorrespondence = runtimeCorrespondence with
            {
                SourceSpans = sourceSpans,
                Descendants = runtimeCorrespondence.Descendants.Select(descendant =>
                {
                    var owner = semanticHoles.FirstOrDefault(hole => descendant.SourceStableId == $"hole:{hole.FeatureId}");
                    return descendant with
                    {
                        FirmamentSelector = owner is null ? descendant.FirmamentSelector
                            : FirmamentV2HoleWallSelector.Format(descendant, owner.Name, owner.FeatureId) ?? descendant.FirmamentSelector
                    };
                }).ToArray()
            };
        }
        foreach (var pmi in document.BoundPmi?.Dimensions ?? [])
        {
            if (pmi.HoleWallTarget is not { } selector) continue;
            if (runtimeCorrespondence is null || body is null || selector.BodyName != runtimeCorrespondence.BodyStableId)
                return SemanticHoleFailure([$"firmament-v2-hole-wall-role-unavailable:{selector.HoleName}"]);
            var selectedFeature = semanticHoles.SingleOrDefault(hole => hole.Name == selector.HoleName);
            if (selectedFeature is null) return SemanticHoleFailure([$"firmament-v2-hole-wall-unknown-hole:{selector.HoleName}"]);
            var request = new SemanticSelectionRequest($"pmi:{pmi.Name}", pmi.Name, selector.BodyName,
                [$"hole:{selectedFeature.FeatureId}"], SemanticTopologyRole.HoleWallFace,
                SemanticSelectionRequirement.NonEmptyFaceSet, $"offset:{pmi.SourceSpan.Start}", "HoleDiameter");
            var resolution = SemanticTopologySelectionResolver.Resolve(body, runtimeCorrespondence, request);
            if (!resolution.Succeeded)
                return SemanticHoleFailure([$"firmament-v2-hole-wall-role-unavailable:{selector.HoleName}:{resolution.Failure}"]);
        }
        var semanticPmi = BuildV2SemanticPmi(document, semanticHoles, modifyTargets[0], correspondence: runtimeCorrespondence);
        // Semantic-hole/profile-stack and bounded-Boolean routes remain Audit until their
        // historical coincident/seam topology is remediated producer-by-producer.
        var step = Step242Exporter.ExportBody(body, semanticPmi);
        if (!step.IsSuccess)
        {
            return KernelResult<FirmamentStepExportResult>.Failure(step.Diagnostics);
        }

        var reimport = Step242Importer.ImportBody(step.Value);
        if (!reimport.IsSuccess || reimport.Value is null)
            return KernelResult<FirmamentStepExportResult>.Failure(reimport.Diagnostics);
        var stepHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(step.Value)));
        var surfaceKinds = body.Geometry.Surfaces.Select(s => s.Value.Kind).ToArray();

        var featureReports = semanticHoles.Select(h =>
        {
            var legacyPlacement = h.Placement as AirFaceLocalHolePlacement;
            var constructionPlacement = h.ConstructionPlanePlacement;
            return new FirmamentHoleFeatureReport(
            h.Name,
            "Hole",
            h.FeatureId,
            h.Shaft.Diameter,
            h.Placement.U,
            h.Placement.V,
            legacyPlacement?.ResolvedPoint3 is { } p ? new[] { p.X, p.Y, p.Z } : constructionPlacement is { } cp ? new[] { cp.WorldMouthCenter.X, cp.WorldMouthCenter.Y, cp.WorldMouthCenter.Z } : null,
            legacyPlacement?.ResolvedPoint3 is { } sourcePoint ? sourcePoint.Ordinal is { } ordinal ? $"{sourcePoint.SourceMember}[{ordinal}]" : sourcePoint.SourceMember : constructionPlacement?.SourceConceptPlaneId,
            legacyPlacement?.ResolvedPoint3?.StableId ?? constructionPlacement?.SourceConceptPlaneId,
            legacyPlacement?.ResolvedPoint3?.Ordinal,
            legacyPlacement?.ResolvedPoint3?.PlacementFace ?? constructionPlacement?.ConstructionPlaneId ?? legacyPlacement?.EntryFaceName ?? "unplaced",
            legacyPlacement?.ResolvedPoint3?.SourceSpan ?? constructionPlacement?.SourceSpan,
            semanticHoles.Count == 1 ? nameof(AirHoleSimpleShaftMaterializer) : nameof(AirHoleCompositeMaterializer),
            "HoleProfileStack",
            h.Stack.Kind.ToString(),
            string.Join(" -> ", h.Stack.Components.Select(component => component switch
            {
                AirHoleCountersinkComponent countersink => $"conical-entry(entryRadius={countersink.EntryRadius:R},angle={countersink.AngleDegrees:R})",
                AirHoleCounterboreComponent counterbore => $"counterbore(radius={counterbore.Radius:R},depth={counterbore.Depth:R})",
                AirHoleShaftComponent shaft => $"cylindrical-shaft(radius={shaft.Radius:R},{shaft.EndCondition.Kind})",
                _ => component.Kind.ToString(),
            })),
            surfaceKinds.Count(k => k == SurfaceGeometryKind.Cylinder),
            surfaceKinds.Count(k => k == SurfaceGeometryKind.Cone),
            surfaceKinds.Count(k => k == SurfaceGeometryKind.Plane),
            stepHash,
            true);
        }).ToArray();
        return KernelResult<FirmamentStepExportResult>.Success(
            new FirmamentStepExportResult(
                step.Value,
                feature.FeatureId,
                0,
                semanticHoles.Count == 1 ? nameof(AirHoleSimpleShaftMaterializer) : nameof(AirHoleCompositeMaterializer),
                semanticHoles.Count == 1 ? feature.Stack.Kind.ToString() : "CompositeSimpleShaft",
                DatumInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.DatumPlane).Select(p => new FirmamentPmiInspectionDatum(p.Name, "planar", p.Target)).ToArray() ?? [],
                DimensionInspection: document.Pmi?.Where(p => p.Kind == FirmamentV2PmiKind.HoleDiameter).Select(p => new FirmamentPmiInspectionDimension("Diameter", p.Target, null, p.Value ?? 0d, "explicit-v2-semantic-pmi", p.Name)).ToArray() ?? [],
                ConceptIr: document.ConceptIr,
                Features: featureReports)
            {
                RuntimeBody = runtimeCorrespondence is null ? null : body,
                RuntimeCorrespondence = runtimeCorrespondence
            });
    }

    private static KernelResult<bool> ValidateV2PmiExportSupport(FirmamentV2Document document)
    {
        var unsupported = document.PmiBlock?.Records.Where(r => r.Kind is not (FirmamentV2PmiKind.DatumPlane or FirmamentV2PmiKind.HoleDiameter)).ToArray() ?? [];
        if (unsupported.Length == 0)
        {
            return KernelResult<bool>.Success(true);
        }

        return KernelResult<bool>.Failure(unsupported.Select(r => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error,
            $"firmament-v2-pmi-export-deferred: AP242 export for PMI record '{r.Name}' ({r.Kind.ToString().ToLowerInvariant()}) is deferred in V2 Phase 1 P2; supported export records are datum and diameter.",
            "FirmamentV2.PmiExport")).ToArray());
    }

    private static IReadOnlyList<Step242SemanticPmi> BuildV2SemanticPmi(
        FirmamentV2Document document,
        IReadOnlyList<Core.Air.AirHoleFeature> semanticHoles,
        string targetSolid,
        IReadOnlyDictionary<string, string>? explicitFeatureIds = null,
        SemanticTopologyCorrespondence? correspondence = null)
    {
        if (document.Pmi is null || document.Pmi.Count == 0)
        {
            return [];
        }

        var holeByName = semanticHoles.SelectMany(h => new[] { new KeyValuePair<string, Core.Air.AirHoleFeature>(h.FeatureId, h), new KeyValuePair<string, Core.Air.AirHoleFeature>(h.Name, h) }).ToDictionary(kvp => kvp.Key, kvp => kvp.Value, StringComparer.Ordinal);
        var boundPmiByName = (document.BoundPmi?.Datums ?? []).Concat(document.BoundPmi?.Dimensions ?? []).Concat(document.BoundPmi?.Controls ?? []).ToDictionary(p => p.Name, StringComparer.Ordinal);
        var targetBinding = document.Solids.Single(s => string.Equals(s.Name, targetSolid, StringComparison.Ordinal));
        var result = new List<Step242SemanticPmi>();
        foreach (var pmi in document.Pmi)
        {
            if (pmi.Kind == FirmamentV2PmiKind.HoleDiameter && pmi.Value.HasValue)
            {
                boundPmiByName.TryGetValue(pmi.Name, out var boundPmi);
                var tolerancePlus = boundPmi?.DimensionTolerance?.Plus;
                var toleranceMinus = boundPmi?.DimensionTolerance?.Minus;
                if (boundPmi?.HoleWallTarget is { } wallTarget && holeByName.TryGetValue(wallTarget.HoleName, out var wallHole))
                {
                    result.Add(new Step242SemanticPmiHole(wallHole.FeatureId, pmi.Value.Value, null, "explicit_v2_hole_wall_diameter", tolerancePlus, toleranceMinus));
                }
                else if (holeByName.TryGetValue(pmi.Target, out var pmiHole))
                {
                    result.Add(new Step242SemanticPmiHole(pmiHole.FeatureId, pmi.Value.Value, null, "explicit_v2_semantic_hole_diameter", tolerancePlus, toleranceMinus));
                }
                else if (explicitFeatureIds is not null && explicitFeatureIds.TryGetValue(pmi.Target, out var featureId))
                {
                    result.Add(new Step242SemanticPmiHole(featureId, pmi.Value.Value, null, "explicit_v2_semantic_hole_diameter", tolerancePlus, toleranceMinus));
                }
                else if (TryResolveV2RecognizedRegionTarget(document, targetBinding, pmi.Target, out var importedTarget) || TryResolveV2ImportedFaceTarget(targetBinding, pmi.Target, out importedTarget))
                {
                    result.Add(new Step242SemanticPmiHole($"{targetSolid}.{pmi.Name}", pmi.Value.Value, null, $"imported_canonical_face:{importedTarget}", tolerancePlus, toleranceMinus));
                }
            }
            else if (pmi.Kind == FirmamentV2PmiKind.DatumPlane)
            {
                var selector = TryResolveV2RecognizedRegionTarget(document, targetBinding, pmi.Target, out var recognizedDatumTarget) ? recognizedDatumTarget : ResolveV2DatumTarget(targetBinding, pmi.Target);
                result.Add(new Step242SemanticPmiDatum(targetSolid, "plane", pmi.Name, selector));
            }
        }

        if (correspondence is null) return result;
        return result.Select(item => item with
        {
            GeometricFaceIds = correspondence.Descendants
                .Where(descendant => descendant.Face.HasValue
                    && (string.Equals(descendant.SourceStableId, item.FeatureId, StringComparison.Ordinal)
                        || string.Equals(descendant.ParentStableId, item.FeatureId, StringComparison.Ordinal)))
                .Select(descendant => descendant.Face!.Value.Value)
                .Distinct()
                .Order()
                .ToArray()
        }).ToArray();
    }


    private static bool TryResolveV2RecognizedRegionTarget(FirmamentV2Document document, FirmamentV2SolidBinding solid, string target, out string resolved)
    {
        resolved = string.Empty;
        const string marker = ".region(\"";
        if (solid.InlineStep is null || !target.StartsWith(solid.Name + marker, StringComparison.Ordinal) || !target.EndsWith("\")", StringComparison.Ordinal))
        {
            return false;
        }

        var regionName = target[(solid.Name.Length + marker.Length)..^2];
        var region = document.RecognizedRegions?.FirstOrDefault(r => string.Equals(r.BodyName, solid.Name, StringComparison.Ordinal) && string.Equals(r.RegionName, regionName, StringComparison.Ordinal));
        if (region is null || region.FaceRefs.Count == 0 || !solid.InlineStep.TopologyMap.TryResolveFaceEntity(region.FaceRefs[0], out var faceId))
        {
            return false;
        }

        resolved = $"{solid.Name}.{region.RegionName}.{faceId}:{region.FaceRefs[0]}";
        return true;
    }

    private static bool TryResolveV2ImportedFaceTarget(FirmamentV2SolidBinding solid, string target, out string resolved)
    {
        resolved = string.Empty;
        const string marker = ".face(\"";
        if (solid.InlineStep is null || !target.StartsWith(solid.Name + marker, StringComparison.Ordinal) || !target.EndsWith("\")", StringComparison.Ordinal))
        {
            return false;
        }

        var entity = target[(solid.Name.Length + marker.Length)..^2];
        if (!solid.InlineStep.TopologyMap.TryResolveFaceEntity(entity, out var faceId))
        {
            return false;
        }

        resolved = $"{solid.Name}.{faceId}:{entity}";
        return true;
    }

    private static string ResolveV2DatumTarget(FirmamentV2SolidBinding solid, string target)
    {
        if (TryResolveV2ImportedFaceTarget(solid, target, out var importedTarget))
        {
            return importedTarget;
        }

        if (target.StartsWith("face(", StringComparison.Ordinal))
        {
            return $"{solid.Name}.{FaceAxisToPort(target)}";
        }

        var exposure = solid.Box?.Exposures.FirstOrDefault(e => string.Equals(e.Alias, target, StringComparison.Ordinal));
        return exposure is null ? $"{solid.Name}.{target}" : $"{solid.Name}.{FaceAxisToPort(exposure.Selector)}";
    }

    private static string FaceAxisToPort(string selector) => selector switch
    {
        "face(+Z)" => "top_face",
        "face(-Z)" => "bottom_face",
        "face(+X)" => "plus_x_face",
        "face(-X)" => "minus_x_face",
        "face(+Y)" => "plus_y_face",
        "face(-Y)" => "minus_y_face",
        _ => selector
    };

    private static IReadOnlyList<FirmamentEngineeringFeatureReport> EngineeringFeatureReports(PrismaticProfileCompositionFeature feature) =>
        (feature.Bosses ?? []).Select(item => new FirmamentEngineeringFeatureReport(
            item.Name, "Boss", item.StableId, item.Host, item.SupportFace, item.ProfileReference,
            item.Height, "Height", "Add", MaterializationRoute: "PrismaticSectionStack/Add",
            SupportSpan: item.SupportSpan, ParentSupport: item.ParentSupport))
        .Concat((feature.Pockets ?? []).Select(item => new FirmamentEngineeringFeatureReport(
            item.Name, "Pocket", item.StableId, item.Host, item.SupportFace, item.ProfileReference,
            item.Depth, "Depth", "Remove", item.RemainingFloor, item.MinimumFloorThickness,
            item.MinimumFloorPolicySource, "PrismaticSectionStack/Remove", item.SupportSpan, item.ParentSupport)))
        .Concat((feature.MaterialOffsets ?? []).Select(item => new FirmamentEngineeringFeatureReport(
            item.Name, $"{item.OperationKind}Offset<{item.ToolFamily}>", item.StableId, item.Target, item.Support,
            item.ProfileReference, item.Extent, item.Termination, item.OperationKind,
            PolicySource: "BoundedMaterialOffsetX1",
            MaterializationRoute: $"MaterialOffsetAir/{item.ToolFamily}->PrismaticSectionStack/{item.OperationKind}",
            SupportSpan: item.SupportSpan, ParentSupport: item.ParentSupport,
            ToolFamily: item.ToolFamily, Direction: item.Direction, Termination: item.Termination,
            AuthorizedRegion: item.AuthorizedRegion)))
        .OrderBy(item => item.FeatureId, StringComparer.Ordinal)
        .ToArray();

    private static IReadOnlyList<FirmamentHoleFeatureReport> CompositionHoleReports(PrismaticProfileCompositionFeature feature) =>
        (feature.ShaftHoles ?? []).Select(item => new FirmamentHoleFeatureReport(
            item.Name, "Hole<Shaft>", item.StableId, item.Diameter, item.CenterX, item.CenterY,
            null, "ProfileCompose.Center", null, null, "+Z", item.SourceSpan,
            "PrismaticSectionStack/Remove", "SemanticShaftProfile", "ThroughAll",
            SupportSpan: item.SupportSpan, ParentSupport: item.ParentSupport, SupportBoundaryMargin: item.SupportBoundaryMargin))
        .Concat((feature.CounterboreHoles ?? []).Select(item => new FirmamentHoleFeatureReport(
            item.Name, "Hole<Counterbore>", item.StableId, item.Diameter, item.CenterX, item.CenterY,
            null, "ProfileCompose.Center", null, null, "+Z", item.SourceSpan,
            "PrismaticSectionStack/Remove", "SemanticCounterboreProfiles", "ThroughAll",
            SupportSpan: item.SupportSpan, ParentSupport: item.ParentSupport, SupportBoundaryMargin: item.SupportBoundaryMargin)))
        .OrderBy(item => item.FeatureId, StringComparer.Ordinal)
        .ToArray();

    /// <summary>
    /// The hole planners narrate their route as they go ("planner started", "plan created", "execution route: ...")
    /// and then state the one thing that stopped them. Reporting every line as an error buried that cause under the
    /// narration, so only lines that state a cause are errors; the narration is kept, as information, for provenance.
    /// </summary>
    private static KernelResult<FirmamentStepExportResult> SemanticHoleFailure(IEnumerable<string> diagnostics)
    {
        var lines = diagnostics.ToArray();
        var anyCause = lines.Any(IsSemanticHoleFailureCause);
        return KernelResult<FirmamentStepExportResult>.Failure(lines.Select(d => new Kernel.Core.Diagnostics.KernelDiagnostic(
            Kernel.Core.Diagnostics.KernelDiagnosticCode.ValidationFailed,
            !anyCause || IsSemanticHoleFailureCause(d) ? Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Error : Kernel.Core.Diagnostics.KernelDiagnosticSeverity.Info,
            d,
            "FirmamentV2.SemanticHoleBuild")).ToArray());
    }

    private static bool IsSemanticHoleFailureCause(string line) =>
        line.Contains("rejected", StringComparison.Ordinal)
        || line.Contains("failed", StringComparison.Ordinal)
        || line.Contains("Unsupported", StringComparison.Ordinal)
        || line.StartsWith("semantic diagnostic", StringComparison.Ordinal)
        || line.StartsWith("firmament-", StringComparison.Ordinal);

    private static string ResolveDefaultOutputPath(string fullSourcePath)
    {
        // A source file is the only project boundary Preview 1 needs. Keeping the
        // generated artifact adjacent to it is deterministic, discoverable, and
        // works identically from a checkout, a package, or a user directory.
        return Path.ChangeExtension(fullSourcePath, ".step");
    }

    private static string NormalizeLf(string value) =>
        value.Replace("\r\n", "\n", StringComparison.Ordinal).Replace("\r", "\n", StringComparison.Ordinal);
}
