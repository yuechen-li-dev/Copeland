using Aetheris.Kernel.Core.Step242;
using Aetheris.Kernel.Firmament.FirmamentV2;
using Aetheris.Kernel.Firmament.FirmamentV2.Syntax;

namespace Aetheris.Kernel.Firmament.Tests;

public sealed class FirmamentMechanicalFrontendMigrationTests
{
    [Theory]
    [InlineData("unknown-compose-statement", "Fillet")]
    [InlineData("unknown-boundary-field", "heigth")]
    public void LostIntent_RejectsInBothProductionPaths_AtOriginalToken(string fixture, string token)
    {
        var source = Read("FrontendX0/" + fixture);
        var parsed = FirmamentV2Parser.Parse(source);
        var report = FirmamentBuildAdmissionValidation.Admit(FirmamentV2ValidationReportBuilder.Build(parsed, "intent.firmament"), source);
        Assert.False(parsed.IsSuccess);
        Assert.Equal("invalid", report.Status);
        Assert.False(FirmamentBuildAndExport.CompileSource(source).IsSuccess);
        var diagnostic = Assert.Single(report.Diagnostics.Where(d => d.Code.EndsWith(":" + token, StringComparison.Ordinal)));
        Assert.Equal(token, source.Substring(diagnostic.SourceSpan!.Start, diagnostic.SourceSpan.Length));
        Assert.Equal("intent.firmament", diagnostic.SourceFile);
    }

    [Theory]
    [InlineData("Box Body { Size: [40mm,20mm,6mm]; heigth: 8mm }", "Box:heigth")]
    [InlineData("Box Body { Size: [40mm,20mm,6mm] } Modify Body { Fillet Lost { Radius: 1mm } }", "Modify:Fillet")]
    [InlineData("Box Body { Size: [40mm,20mm,6mm]; Size: [4mm,2mm,1mm] }", "field-duplicate:Box:Size")]
    public void AstOwner_RejectsUnknownOrContradictoryIntent(string body, string expected)
    {
        var source = "Model Test { Units: mm " + body + " }";
        var parsed = FirmamentV2Parser.Parse(source);
        Assert.False(parsed.IsSuccess);
        Assert.Contains(parsed.Diagnostics, d => d.Contains(expected, StringComparison.Ordinal));
        Assert.False(FirmamentBuildAndExport.CompileSource(source).IsSuccess);
    }

    [Theory]
    [InlineData("Static unused = 4mm")]
    [InlineData("Profile unused { Loop Outer { Missing |> Close } }")]
    [InlineData("Slot2 unused { center: [0mm,0mm]; length: 12mm; width: 3mm }")]
    public void UnusedConstruction_CannotSelectAnotherMechanicalGrammar(string unused)
    {
        const string stock = "Model Test { Units: mm Box Body { Size: [40mm,20mm,6mm] } }";
        var changed = stock.Insert(stock.LastIndexOf('}'), unused);
        var before = FirmamentBuildAndExport.CompileSource(stock);
        var after = FirmamentBuildAndExport.CompileSource(changed);
        Assert.True(before.IsSuccess);
        Assert.True(after.IsSuccess, string.Join("; ", after.Diagnostics.Select(d => d.Message)));
        Assert.Equal(before.Value.StepText, after.Value.StepText);
        Assert.Equal("UnifiedMechanical", FirmamentV2Parser.Parse(changed).ParserRoute);
        var body = Step242Importer.ImportBody(after.Value.StepText);
        Assert.True(body.IsSuccess);
        Assert.Equal(6, body.Value.Topology.Faces.Count());
    }

    [Fact]
    public void ProfileSelections_RetainTheirAdmittedMemberSet_AndBuild()
    {
        var path = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,
            "../../../../fixtures/Regression/CanonicalGeometry/profile-chamfer-reflex-junction-top.firmament"));
        var source = File.ReadAllText(path);
        var parsed = FirmamentV2Parser.Parse(source);
        Assert.True(parsed.IsSuccess, string.Join("; ", parsed.Diagnostics));
        Assert.Equal("UnifiedMechanical", parsed.ParserRoute);
        var selection = Assert.Single(parsed.Document!.Selections!);
        Assert.Contains(".[", selection.Source, StringComparison.Ordinal);
        var report = FirmamentBuildAdmissionValidation.Admit(FirmamentV2ValidationReportBuilder.Build(parsed), source);
        Assert.Equal("valid", report.Status);
        Assert.Equal("Built", report.ValidationLevel);
        Assert.True(FirmamentBuildAndExport.CompileSource(source).IsSuccess);
    }

    [Fact]
    public void StructAndModelStock_UseTheSameAstBinderAndGeometry()
    {
        const string stock = "Model Test { Units: mm Box Body { Size: [40mm,20mm,6mm] } }";
        var alternative = stock.Replace("Model", "Struct", StringComparison.Ordinal);
        Assert.Equal("UnifiedMechanical", FirmamentV2Parser.Parse(alternative).ParserRoute);
        Assert.Equal(FirmamentBuildAndExport.CompileSource(stock).Value.StepText,
            FirmamentBuildAndExport.CompileSource(alternative).Value.StepText);
    }

    [Fact]
    public void SyntaxFailure_HasOriginalLocation_AfterComments()
    {
        const string source = "// retained provenance\nModel Test { Units: mm\nBox Body { Size: ; }\n}";
        var report = FirmamentV2ValidationReportBuilder.Build(FirmamentV2Parser.Parse(source), "broken.firmament");
        Assert.Equal("invalid", report.Status);
        var diagnostic = Assert.Single(report.Diagnostics, d => d.Code == "firmament-syntax-expression");
        Assert.Equal(3, diagnostic.Line);
        Assert.Equal(";", source.Substring(diagnostic.SourceSpan!.Start, diagnostic.SourceSpan.Length));
        Assert.Contains("expression", diagnostic.Message, StringComparison.Ordinal);
    }

    [Fact]
    public void ExistingStaticMatch_IsStructured_BeforeExistingSemanticEvaluation()
    {
        var syntax = FirmamentSyntaxParser.Parse(FirmamentV2StaticLogicTests.Source());
        Assert.True(syntax.IsSuccess, string.Join("; ", syntax.Diagnostics.Select(d => d.Message)));
        var design = Assert.Single(FirmamentSyntaxEvidence.Declarations(syntax.Document), d => d.Name?.Text == "BracketConcept");
        Assert.IsType<MatchSyntax>(Assert.Single(design.Body!.Statements.OfType<FieldSyntax>(), f => f.Name.Text == "ChamferDistance").Value);
        Assert.True(FirmamentV2Parser.Parse(FirmamentV2StaticLogicTests.Source()).IsSuccess);
    }

    private static string Read(string relative) => File.ReadAllText(Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,
        "../../../../fixtures/Regression", relative + ".firmament")));
}
